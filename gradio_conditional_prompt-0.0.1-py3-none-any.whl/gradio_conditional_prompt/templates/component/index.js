function gt() {
}
function F_(e) {
  return e();
}
function R_(e) {
  e.forEach(F_);
}
function U_(e) {
  return typeof e == "function";
}
function G_(e, t) {
  return e != e ? t == t : e !== t || e && typeof e == "object" || typeof e == "function";
}
function j_(e, ...t) {
  if (e == null) {
    for (const o of t)
      o(void 0);
    return gt;
  }
  const n = e.subscribe(...t);
  return n.unsubscribe ? () => n.unsubscribe() : n;
}
function Zi(e) {
  const t = typeof e == "string" && e.match(/^\s*(-?[\d.]+)([^\s]*)\s*$/);
  return t ? [parseFloat(t[1]), t[2] || "px"] : [
    /** @type {number} */
    e,
    "px"
  ];
}
const bs = typeof window < "u";
let Wi = bs ? () => window.performance.now() : () => Date.now(), Ss = bs ? (e) => requestAnimationFrame(e) : gt;
const Ot = /* @__PURE__ */ new Set();
function Cs(e) {
  Ot.forEach((t) => {
    t.c(e) || (Ot.delete(t), t.f());
  }), Ot.size !== 0 && Ss(Cs);
}
function V_(e) {
  let t;
  return Ot.size === 0 && Ss(Cs), {
    promise: new Promise((n) => {
      Ot.add(t = { c: e, f: n });
    }),
    abort() {
      Ot.delete(t);
    }
  };
}
function qs(e) {
  const t = e - 1;
  return t * t * t + 1;
}
function Ji(e, { delay: t = 0, duration: n = 400, easing: o = qs, x: i = 0, y: a = 0, opacity: s = 0 } = {}) {
  const _ = getComputedStyle(e), l = +_.opacity, r = _.transform === "none" ? "" : _.transform, u = l * (1 - s), [f, d] = Zi(i), [c, m] = Zi(a);
  return {
    delay: t,
    duration: n,
    easing: o,
    css: (w, b) => `
			transform: ${r} translate(${(1 - w) * f}${d}, ${(1 - w) * c}${m});
			opacity: ${l - u * b}`
  };
}
function Qi(e, { delay: t = 0, duration: n = 400, easing: o = qs, axis: i = "y" } = {}) {
  const a = getComputedStyle(e), s = +a.opacity, _ = i === "y" ? "height" : "width", l = parseFloat(a[_]), r = i === "y" ? ["top", "bottom"] : ["left", "right"], u = r.map(
    (v) => `${v[0].toUpperCase()}${v.slice(1)}`
  ), f = parseFloat(a[`padding${u[0]}`]), d = parseFloat(a[`padding${u[1]}`]), c = parseFloat(a[`margin${u[0]}`]), m = parseFloat(a[`margin${u[1]}`]), w = parseFloat(
    a[`border${u[0]}Width`]
  ), b = parseFloat(
    a[`border${u[1]}Width`]
  );
  return {
    delay: t,
    duration: n,
    easing: o,
    css: (v) => `overflow: hidden;opacity: ${Math.min(v * 20, 1) * s};${_}: ${v * l}px;padding-${r[0]}: ${v * f}px;padding-${r[1]}: ${v * d}px;margin-${r[0]}: ${v * c}px;margin-${r[1]}: ${v * m}px;border-${r[0]}-width: ${v * w}px;border-${r[1]}-width: ${v * b}px;`
  };
}
const bt = [];
function z_(e, t) {
  return {
    subscribe: Cn(e, t).subscribe
  };
}
function Cn(e, t = gt) {
  let n;
  const o = /* @__PURE__ */ new Set();
  function i(_) {
    if (G_(e, _) && (e = _, n)) {
      const l = !bt.length;
      for (const r of o)
        r[1](), bt.push(r, e);
      if (l) {
        for (let r = 0; r < bt.length; r += 2)
          bt[r][0](bt[r + 1]);
        bt.length = 0;
      }
    }
  }
  function a(_) {
    i(_(e));
  }
  function s(_, l = gt) {
    const r = [_, l];
    return o.add(r), o.size === 1 && (n = t(i, a) || gt), _(e), () => {
      o.delete(r), o.size === 0 && n && (n(), n = null);
    };
  }
  return { set: i, update: a, subscribe: s };
}
function Qt(e, t, n) {
  const o = !Array.isArray(e), i = o ? [e] : e;
  if (!i.every(Boolean))
    throw new Error("derived() expects stores as input, got a falsy value");
  const a = t.length < 2;
  return z_(n, (s, _) => {
    let l = !1;
    const r = [];
    let u = 0, f = gt;
    const d = () => {
      if (u)
        return;
      f();
      const m = t(o ? r[0] : r, s, _);
      a ? s(m) : f = U_(m) ? m : gt;
    }, c = i.map(
      (m, w) => j_(
        m,
        (b) => {
          r[w] = b, u &= ~(1 << w), l && d();
        },
        () => {
          u |= 1 << w;
        }
      )
    );
    return l = !0, d(), function() {
      R_(c), f(), l = !1;
    };
  });
}
function Yi(e) {
  return Object.prototype.toString.call(e) === "[object Date]";
}
function Ko(e, t, n, o) {
  if (typeof n == "number" || Yi(n)) {
    const i = o - n, a = (n - t) / (e.dt || 1 / 60), s = e.opts.stiffness * i, _ = e.opts.damping * a, l = (s - _) * e.inv_mass, r = (a + l) * e.dt;
    return Math.abs(r) < e.opts.precision && Math.abs(i) < e.opts.precision ? o : (e.settled = !1, Yi(n) ? new Date(n.getTime() + r) : n + r);
  } else {
    if (Array.isArray(n))
      return n.map(
        (i, a) => Ko(e, t[a], n[a], o[a])
      );
    if (typeof n == "object") {
      const i = {};
      for (const a in n)
        i[a] = Ko(e, t[a], n[a], o[a]);
      return i;
    } else
      throw new Error(`Cannot spring ${typeof n} values`);
  }
}
function Ut(e, t = {}) {
  const n = Cn(e), { stiffness: o = 0.15, damping: i = 0.8, precision: a = 0.01 } = t;
  let s, _, l, r = e, u = e, f = 1, d = 0, c = !1;
  function m(b, v = {}) {
    u = b;
    const g = l = {};
    return e == null || v.hard || w.stiffness >= 1 && w.damping >= 1 ? (c = !0, s = Wi(), r = b, n.set(e = u), Promise.resolve()) : (v.soft && (d = 1 / ((v.soft === !0 ? 0.5 : +v.soft) * 60), f = 0), _ || (s = Wi(), c = !1, _ = V_((p) => {
      if (c)
        return c = !1, _ = null, !1;
      f = Math.min(f + d, 1);
      const h = {
        inv_mass: f,
        opts: w,
        settled: !0,
        dt: (p - s) * 60 / 1e3
      }, S = Ko(h, r, e, u);
      return s = p, r = e, n.set(e = S), h.settled && (_ = null), !h.settled;
    })), new Promise((p) => {
      _.promise.then(() => {
        g === l && p();
      });
    }));
  }
  const w = {
    set: m,
    update: (b, v) => m(b(u, e), v),
    subscribe: n.subscribe,
    stiffness: o,
    damping: i,
    precision: a
  };
  return w;
}
function X_(e) {
  return !!e && typeof e == "object";
}
function Z_(e) {
  const t = Object.prototype.toString.call(e);
  return t === "[object RegExp]" || t === "[object Date]" || Q_(e);
}
const W_ = typeof Symbol == "function" && Symbol.for, J_ = W_ ? Symbol.for("react.element") : 60103;
function Q_(e) {
  return e && e.$$typeof === J_;
}
function Y_(e) {
  return X_(e) && !Z_(e);
}
function K_(e) {
  return Array.isArray(e) ? [] : {};
}
function mn(e, t) {
  return t.clone !== !1 && t.isMergeableObject(e) ? Gt(K_(e), e, t) : e;
}
function x_(e, t, n) {
  return e.concat(t).map((o) => mn(o, n));
}
function er(e, t) {
  if (!t.customMerge)
    return Gt;
  const n = t.customMerge(e);
  return typeof n == "function" ? n : Gt;
}
function tr(e) {
  return Object.getOwnPropertySymbols ? Object.getOwnPropertySymbols(e).filter((t) => Object.propertyIsEnumerable.call(e, t)) : [];
}
function Ki(e) {
  return Object.keys(e).concat(tr(e));
}
function ys(e, t) {
  try {
    return t in e;
  } catch {
    return !1;
  }
}
function nr(e, t) {
  return ys(e, t) && !(Object.hasOwnProperty.call(e, t) && Object.propertyIsEnumerable.call(e, t));
}
function or(e, t, n) {
  const o = {};
  return n.isMergeableObject(e) && Ki(e).forEach((i) => {
    o[i] = mn(e[i], n);
  }), Ki(t).forEach((i) => {
    nr(e, i) || (ys(e, i) && n.isMergeableObject(t[i]) ? o[i] = er(i, n)(
      e[i],
      t[i],
      n
    ) : o[i] = mn(t[i], n));
  }), o;
}
function Gt(e, t, n = {}) {
  n.arrayMerge = n.arrayMerge || x_, n.isMergeableObject = n.isMergeableObject || Y_, n.cloneUnlessOtherwiseSpecified = mn;
  const o = Array.isArray(t), i = Array.isArray(e);
  return o !== i ? mn(t, n) : o ? n.arrayMerge(e, t, n) : or(e, t, n);
}
Gt.all = function(t, n) {
  if (!Array.isArray(t))
    throw new Error("first argument should be an array");
  return t.reduce((o, i) => Gt(o, i, n), {});
};
var xo = function(e, t) {
  return xo = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(n, o) {
    n.__proto__ = o;
  } || function(n, o) {
    for (var i in o) Object.prototype.hasOwnProperty.call(o, i) && (n[i] = o[i]);
  }, xo(e, t);
};
function go(e, t) {
  if (typeof t != "function" && t !== null)
    throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
  xo(e, t);
  function n() {
    this.constructor = e;
  }
  e.prototype = t === null ? Object.create(t) : (n.prototype = t.prototype, new n());
}
var W = function() {
  return W = Object.assign || function(t) {
    for (var n, o = 1, i = arguments.length; o < i; o++) {
      n = arguments[o];
      for (var a in n) Object.prototype.hasOwnProperty.call(n, a) && (t[a] = n[a]);
    }
    return t;
  }, W.apply(this, arguments);
};
function To(e, t, n) {
  if (n || arguments.length === 2) for (var o = 0, i = t.length, a; o < i; o++)
    (a || !(o in t)) && (a || (a = Array.prototype.slice.call(t, 0, o)), a[o] = t[o]);
  return e.concat(a || Array.prototype.slice.call(t));
}
var G;
(function(e) {
  e[e.EXPECT_ARGUMENT_CLOSING_BRACE = 1] = "EXPECT_ARGUMENT_CLOSING_BRACE", e[e.EMPTY_ARGUMENT = 2] = "EMPTY_ARGUMENT", e[e.MALFORMED_ARGUMENT = 3] = "MALFORMED_ARGUMENT", e[e.EXPECT_ARGUMENT_TYPE = 4] = "EXPECT_ARGUMENT_TYPE", e[e.INVALID_ARGUMENT_TYPE = 5] = "INVALID_ARGUMENT_TYPE", e[e.EXPECT_ARGUMENT_STYLE = 6] = "EXPECT_ARGUMENT_STYLE", e[e.INVALID_NUMBER_SKELETON = 7] = "INVALID_NUMBER_SKELETON", e[e.INVALID_DATE_TIME_SKELETON = 8] = "INVALID_DATE_TIME_SKELETON", e[e.EXPECT_NUMBER_SKELETON = 9] = "EXPECT_NUMBER_SKELETON", e[e.EXPECT_DATE_TIME_SKELETON = 10] = "EXPECT_DATE_TIME_SKELETON", e[e.UNCLOSED_QUOTE_IN_ARGUMENT_STYLE = 11] = "UNCLOSED_QUOTE_IN_ARGUMENT_STYLE", e[e.EXPECT_SELECT_ARGUMENT_OPTIONS = 12] = "EXPECT_SELECT_ARGUMENT_OPTIONS", e[e.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE = 13] = "EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE", e[e.INVALID_PLURAL_ARGUMENT_OFFSET_VALUE = 14] = "INVALID_PLURAL_ARGUMENT_OFFSET_VALUE", e[e.EXPECT_SELECT_ARGUMENT_SELECTOR = 15] = "EXPECT_SELECT_ARGUMENT_SELECTOR", e[e.EXPECT_PLURAL_ARGUMENT_SELECTOR = 16] = "EXPECT_PLURAL_ARGUMENT_SELECTOR", e[e.EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT = 17] = "EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT", e[e.EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT = 18] = "EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT", e[e.INVALID_PLURAL_ARGUMENT_SELECTOR = 19] = "INVALID_PLURAL_ARGUMENT_SELECTOR", e[e.DUPLICATE_PLURAL_ARGUMENT_SELECTOR = 20] = "DUPLICATE_PLURAL_ARGUMENT_SELECTOR", e[e.DUPLICATE_SELECT_ARGUMENT_SELECTOR = 21] = "DUPLICATE_SELECT_ARGUMENT_SELECTOR", e[e.MISSING_OTHER_CLAUSE = 22] = "MISSING_OTHER_CLAUSE", e[e.INVALID_TAG = 23] = "INVALID_TAG", e[e.INVALID_TAG_NAME = 25] = "INVALID_TAG_NAME", e[e.UNMATCHED_CLOSING_TAG = 26] = "UNMATCHED_CLOSING_TAG", e[e.UNCLOSED_TAG = 27] = "UNCLOSED_TAG";
})(G || (G = {}));
var K;
(function(e) {
  e[e.literal = 0] = "literal", e[e.argument = 1] = "argument", e[e.number = 2] = "number", e[e.date = 3] = "date", e[e.time = 4] = "time", e[e.select = 5] = "select", e[e.plural = 6] = "plural", e[e.pound = 7] = "pound", e[e.tag = 8] = "tag";
})(K || (K = {}));
var jt;
(function(e) {
  e[e.number = 0] = "number", e[e.dateTime = 1] = "dateTime";
})(jt || (jt = {}));
function xi(e) {
  return e.type === K.literal;
}
function ir(e) {
  return e.type === K.argument;
}
function ks(e) {
  return e.type === K.number;
}
function Es(e) {
  return e.type === K.date;
}
function Ts(e) {
  return e.type === K.time;
}
function Bs(e) {
  return e.type === K.select;
}
function Hs(e) {
  return e.type === K.plural;
}
function ar(e) {
  return e.type === K.pound;
}
function As(e) {
  return e.type === K.tag;
}
function Ns(e) {
  return !!(e && typeof e == "object" && e.type === jt.number);
}
function ei(e) {
  return !!(e && typeof e == "object" && e.type === jt.dateTime);
}
var Ps = /[ \xA0\u1680\u2000-\u200A\u202F\u205F\u3000]/, lr = /(?:[Eec]{1,6}|G{1,5}|[Qq]{1,5}|(?:[yYur]+|U{1,5})|[ML]{1,5}|d{1,2}|D{1,3}|F{1}|[abB]{1,5}|[hkHK]{1,2}|w{1,2}|W{1}|m{1,2}|s{1,2}|[zZOvVxX]{1,4})(?=([^']*'[^']*')*[^']*$)/g;
function sr(e) {
  var t = {};
  return e.replace(lr, function(n) {
    var o = n.length;
    switch (n[0]) {
      case "G":
        t.era = o === 4 ? "long" : o === 5 ? "narrow" : "short";
        break;
      case "y":
        t.year = o === 2 ? "2-digit" : "numeric";
        break;
      case "Y":
      case "u":
      case "U":
      case "r":
        throw new RangeError("`Y/u/U/r` (year) patterns are not supported, use `y` instead");
      case "q":
      case "Q":
        throw new RangeError("`q/Q` (quarter) patterns are not supported");
      case "M":
      case "L":
        t.month = ["numeric", "2-digit", "short", "long", "narrow"][o - 1];
        break;
      case "w":
      case "W":
        throw new RangeError("`w/W` (week) patterns are not supported");
      case "d":
        t.day = ["numeric", "2-digit"][o - 1];
        break;
      case "D":
      case "F":
      case "g":
        throw new RangeError("`D/F/g` (day) patterns are not supported, use `d` instead");
      case "E":
        t.weekday = o === 4 ? "short" : o === 5 ? "narrow" : "short";
        break;
      case "e":
        if (o < 4)
          throw new RangeError("`e..eee` (weekday) patterns are not supported");
        t.weekday = ["short", "long", "narrow", "short"][o - 4];
        break;
      case "c":
        if (o < 4)
          throw new RangeError("`c..ccc` (weekday) patterns are not supported");
        t.weekday = ["short", "long", "narrow", "short"][o - 4];
        break;
      case "a":
        t.hour12 = !0;
        break;
      case "b":
      case "B":
        throw new RangeError("`b/B` (period) patterns are not supported, use `a` instead");
      case "h":
        t.hourCycle = "h12", t.hour = ["numeric", "2-digit"][o - 1];
        break;
      case "H":
        t.hourCycle = "h23", t.hour = ["numeric", "2-digit"][o - 1];
        break;
      case "K":
        t.hourCycle = "h11", t.hour = ["numeric", "2-digit"][o - 1];
        break;
      case "k":
        t.hourCycle = "h24", t.hour = ["numeric", "2-digit"][o - 1];
        break;
      case "j":
      case "J":
      case "C":
        throw new RangeError("`j/J/C` (hour) patterns are not supported, use `h/H/K/k` instead");
      case "m":
        t.minute = ["numeric", "2-digit"][o - 1];
        break;
      case "s":
        t.second = ["numeric", "2-digit"][o - 1];
        break;
      case "S":
      case "A":
        throw new RangeError("`S/A` (second) patterns are not supported, use `s` instead");
      case "z":
        t.timeZoneName = o < 4 ? "short" : "long";
        break;
      case "Z":
      case "O":
      case "v":
      case "V":
      case "X":
      case "x":
        throw new RangeError("`Z/O/v/V/X/x` (timeZone) patterns are not supported, use `z` instead");
    }
    return "";
  }), t;
}
var _r = /[\t-\r \x85\u200E\u200F\u2028\u2029]/i;
function rr(e) {
  if (e.length === 0)
    throw new Error("Number skeleton cannot be empty");
  for (var t = e.split(_r).filter(function(d) {
    return d.length > 0;
  }), n = [], o = 0, i = t; o < i.length; o++) {
    var a = i[o], s = a.split("/");
    if (s.length === 0)
      throw new Error("Invalid number skeleton");
    for (var _ = s[0], l = s.slice(1), r = 0, u = l; r < u.length; r++) {
      var f = u[r];
      if (f.length === 0)
        throw new Error("Invalid number skeleton");
    }
    n.push({ stem: _, options: l });
  }
  return n;
}
function ur(e) {
  return e.replace(/^(.*?)-/, "");
}
var ea = /^\.(?:(0+)(\*)?|(#+)|(0+)(#+))$/g, Ls = /^(@+)?(\+|#+)?[rs]?$/g, fr = /(\*)(0+)|(#+)(0+)|(0+)/g, Is = /^(0+)$/;
function ta(e) {
  var t = {};
  return e[e.length - 1] === "r" ? t.roundingPriority = "morePrecision" : e[e.length - 1] === "s" && (t.roundingPriority = "lessPrecision"), e.replace(Ls, function(n, o, i) {
    return typeof i != "string" ? (t.minimumSignificantDigits = o.length, t.maximumSignificantDigits = o.length) : i === "+" ? t.minimumSignificantDigits = o.length : o[0] === "#" ? t.maximumSignificantDigits = o.length : (t.minimumSignificantDigits = o.length, t.maximumSignificantDigits = o.length + (typeof i == "string" ? i.length : 0)), "";
  }), t;
}
function Ms(e) {
  switch (e) {
    case "sign-auto":
      return {
        signDisplay: "auto"
      };
    case "sign-accounting":
    case "()":
      return {
        currencySign: "accounting"
      };
    case "sign-always":
    case "+!":
      return {
        signDisplay: "always"
      };
    case "sign-accounting-always":
    case "()!":
      return {
        signDisplay: "always",
        currencySign: "accounting"
      };
    case "sign-except-zero":
    case "+?":
      return {
        signDisplay: "exceptZero"
      };
    case "sign-accounting-except-zero":
    case "()?":
      return {
        signDisplay: "exceptZero",
        currencySign: "accounting"
      };
    case "sign-never":
    case "+_":
      return {
        signDisplay: "never"
      };
  }
}
function dr(e) {
  var t;
  if (e[0] === "E" && e[1] === "E" ? (t = {
    notation: "engineering"
  }, e = e.slice(2)) : e[0] === "E" && (t = {
    notation: "scientific"
  }, e = e.slice(1)), t) {
    var n = e.slice(0, 2);
    if (n === "+!" ? (t.signDisplay = "always", e = e.slice(2)) : n === "+?" && (t.signDisplay = "exceptZero", e = e.slice(2)), !Is.test(e))
      throw new Error("Malformed concise eng/scientific notation");
    t.minimumIntegerDigits = e.length;
  }
  return t;
}
function na(e) {
  var t = {}, n = Ms(e);
  return n || t;
}
function cr(e) {
  for (var t = {}, n = 0, o = e; n < o.length; n++) {
    var i = o[n];
    switch (i.stem) {
      case "percent":
      case "%":
        t.style = "percent";
        continue;
      case "%x100":
        t.style = "percent", t.scale = 100;
        continue;
      case "currency":
        t.style = "currency", t.currency = i.options[0];
        continue;
      case "group-off":
      case ",_":
        t.useGrouping = !1;
        continue;
      case "precision-integer":
      case ".":
        t.maximumFractionDigits = 0;
        continue;
      case "measure-unit":
      case "unit":
        t.style = "unit", t.unit = ur(i.options[0]);
        continue;
      case "compact-short":
      case "K":
        t.notation = "compact", t.compactDisplay = "short";
        continue;
      case "compact-long":
      case "KK":
        t.notation = "compact", t.compactDisplay = "long";
        continue;
      case "scientific":
        t = W(W(W({}, t), { notation: "scientific" }), i.options.reduce(function(l, r) {
          return W(W({}, l), na(r));
        }, {}));
        continue;
      case "engineering":
        t = W(W(W({}, t), { notation: "engineering" }), i.options.reduce(function(l, r) {
          return W(W({}, l), na(r));
        }, {}));
        continue;
      case "notation-simple":
        t.notation = "standard";
        continue;
      case "unit-width-narrow":
        t.currencyDisplay = "narrowSymbol", t.unitDisplay = "narrow";
        continue;
      case "unit-width-short":
        t.currencyDisplay = "code", t.unitDisplay = "short";
        continue;
      case "unit-width-full-name":
        t.currencyDisplay = "name", t.unitDisplay = "long";
        continue;
      case "unit-width-iso-code":
        t.currencyDisplay = "symbol";
        continue;
      case "scale":
        t.scale = parseFloat(i.options[0]);
        continue;
      case "integer-width":
        if (i.options.length > 1)
          throw new RangeError("integer-width stems only accept a single optional option");
        i.options[0].replace(fr, function(l, r, u, f, d, c) {
          if (r)
            t.minimumIntegerDigits = u.length;
          else {
            if (f && d)
              throw new Error("We currently do not support maximum integer digits");
            if (c)
              throw new Error("We currently do not support exact integer digits");
          }
          return "";
        });
        continue;
    }
    if (Is.test(i.stem)) {
      t.minimumIntegerDigits = i.stem.length;
      continue;
    }
    if (ea.test(i.stem)) {
      if (i.options.length > 1)
        throw new RangeError("Fraction-precision stems only accept a single optional option");
      i.stem.replace(ea, function(l, r, u, f, d, c) {
        return u === "*" ? t.minimumFractionDigits = r.length : f && f[0] === "#" ? t.maximumFractionDigits = f.length : d && c ? (t.minimumFractionDigits = d.length, t.maximumFractionDigits = d.length + c.length) : (t.minimumFractionDigits = r.length, t.maximumFractionDigits = r.length), "";
      });
      var a = i.options[0];
      a === "w" ? t = W(W({}, t), { trailingZeroDisplay: "stripIfInteger" }) : a && (t = W(W({}, t), ta(a)));
      continue;
    }
    if (Ls.test(i.stem)) {
      t = W(W({}, t), ta(i.stem));
      continue;
    }
    var s = Ms(i.stem);
    s && (t = W(W({}, t), s));
    var _ = dr(i.stem);
    _ && (t = W(W({}, t), _));
  }
  return t;
}
var kn = {
  AX: [
    "H"
  ],
  BQ: [
    "H"
  ],
  CP: [
    "H"
  ],
  CZ: [
    "H"
  ],
  DK: [
    "H"
  ],
  FI: [
    "H"
  ],
  ID: [
    "H"
  ],
  IS: [
    "H"
  ],
  ML: [
    "H"
  ],
  NE: [
    "H"
  ],
  RU: [
    "H"
  ],
  SE: [
    "H"
  ],
  SJ: [
    "H"
  ],
  SK: [
    "H"
  ],
  AS: [
    "h",
    "H"
  ],
  BT: [
    "h",
    "H"
  ],
  DJ: [
    "h",
    "H"
  ],
  ER: [
    "h",
    "H"
  ],
  GH: [
    "h",
    "H"
  ],
  IN: [
    "h",
    "H"
  ],
  LS: [
    "h",
    "H"
  ],
  PG: [
    "h",
    "H"
  ],
  PW: [
    "h",
    "H"
  ],
  SO: [
    "h",
    "H"
  ],
  TO: [
    "h",
    "H"
  ],
  VU: [
    "h",
    "H"
  ],
  WS: [
    "h",
    "H"
  ],
  "001": [
    "H",
    "h"
  ],
  AL: [
    "h",
    "H",
    "hB"
  ],
  TD: [
    "h",
    "H",
    "hB"
  ],
  "ca-ES": [
    "H",
    "h",
    "hB"
  ],
  CF: [
    "H",
    "h",
    "hB"
  ],
  CM: [
    "H",
    "h",
    "hB"
  ],
  "fr-CA": [
    "H",
    "h",
    "hB"
  ],
  "gl-ES": [
    "H",
    "h",
    "hB"
  ],
  "it-CH": [
    "H",
    "h",
    "hB"
  ],
  "it-IT": [
    "H",
    "h",
    "hB"
  ],
  LU: [
    "H",
    "h",
    "hB"
  ],
  NP: [
    "H",
    "h",
    "hB"
  ],
  PF: [
    "H",
    "h",
    "hB"
  ],
  SC: [
    "H",
    "h",
    "hB"
  ],
  SM: [
    "H",
    "h",
    "hB"
  ],
  SN: [
    "H",
    "h",
    "hB"
  ],
  TF: [
    "H",
    "h",
    "hB"
  ],
  VA: [
    "H",
    "h",
    "hB"
  ],
  CY: [
    "h",
    "H",
    "hb",
    "hB"
  ],
  GR: [
    "h",
    "H",
    "hb",
    "hB"
  ],
  CO: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  DO: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  KP: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  KR: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  NA: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  PA: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  PR: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  VE: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  AC: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  AI: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  BW: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  BZ: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CC: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CX: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  DG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  FK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GB: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GI: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IE: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IM: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IO: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  JE: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  LT: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  MK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  MN: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  MS: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NF: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NR: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NU: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  PN: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  SH: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  SX: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  TA: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  ZA: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  "af-ZA": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  AR: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  CL: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  CR: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  CU: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  EA: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-BO": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-BR": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-EC": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-ES": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-GQ": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-PE": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  GT: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  HN: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  IC: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  KG: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  KM: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  LK: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  MA: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  MX: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  NI: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  PY: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  SV: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  UY: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  JP: [
    "H",
    "h",
    "K"
  ],
  AD: [
    "H",
    "hB"
  ],
  AM: [
    "H",
    "hB"
  ],
  AO: [
    "H",
    "hB"
  ],
  AT: [
    "H",
    "hB"
  ],
  AW: [
    "H",
    "hB"
  ],
  BE: [
    "H",
    "hB"
  ],
  BF: [
    "H",
    "hB"
  ],
  BJ: [
    "H",
    "hB"
  ],
  BL: [
    "H",
    "hB"
  ],
  BR: [
    "H",
    "hB"
  ],
  CG: [
    "H",
    "hB"
  ],
  CI: [
    "H",
    "hB"
  ],
  CV: [
    "H",
    "hB"
  ],
  DE: [
    "H",
    "hB"
  ],
  EE: [
    "H",
    "hB"
  ],
  FR: [
    "H",
    "hB"
  ],
  GA: [
    "H",
    "hB"
  ],
  GF: [
    "H",
    "hB"
  ],
  GN: [
    "H",
    "hB"
  ],
  GP: [
    "H",
    "hB"
  ],
  GW: [
    "H",
    "hB"
  ],
  HR: [
    "H",
    "hB"
  ],
  IL: [
    "H",
    "hB"
  ],
  IT: [
    "H",
    "hB"
  ],
  KZ: [
    "H",
    "hB"
  ],
  MC: [
    "H",
    "hB"
  ],
  MD: [
    "H",
    "hB"
  ],
  MF: [
    "H",
    "hB"
  ],
  MQ: [
    "H",
    "hB"
  ],
  MZ: [
    "H",
    "hB"
  ],
  NC: [
    "H",
    "hB"
  ],
  NL: [
    "H",
    "hB"
  ],
  PM: [
    "H",
    "hB"
  ],
  PT: [
    "H",
    "hB"
  ],
  RE: [
    "H",
    "hB"
  ],
  RO: [
    "H",
    "hB"
  ],
  SI: [
    "H",
    "hB"
  ],
  SR: [
    "H",
    "hB"
  ],
  ST: [
    "H",
    "hB"
  ],
  TG: [
    "H",
    "hB"
  ],
  TR: [
    "H",
    "hB"
  ],
  WF: [
    "H",
    "hB"
  ],
  YT: [
    "H",
    "hB"
  ],
  BD: [
    "h",
    "hB",
    "H"
  ],
  PK: [
    "h",
    "hB",
    "H"
  ],
  AZ: [
    "H",
    "hB",
    "h"
  ],
  BA: [
    "H",
    "hB",
    "h"
  ],
  BG: [
    "H",
    "hB",
    "h"
  ],
  CH: [
    "H",
    "hB",
    "h"
  ],
  GE: [
    "H",
    "hB",
    "h"
  ],
  LI: [
    "H",
    "hB",
    "h"
  ],
  ME: [
    "H",
    "hB",
    "h"
  ],
  RS: [
    "H",
    "hB",
    "h"
  ],
  UA: [
    "H",
    "hB",
    "h"
  ],
  UZ: [
    "H",
    "hB",
    "h"
  ],
  XK: [
    "H",
    "hB",
    "h"
  ],
  AG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  AU: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BB: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BS: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  CA: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  DM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  "en-001": [
    "h",
    "hb",
    "H",
    "hB"
  ],
  FJ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  FM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GD: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GU: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GY: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  JM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KI: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KN: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KY: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  LC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  LR: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MH: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MP: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MW: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  NZ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SB: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SL: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SS: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SZ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  TC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  TT: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  UM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  US: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VI: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  ZM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BO: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  EC: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  ES: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  GQ: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  PE: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  AE: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  "ar-001": [
    "h",
    "hB",
    "hb",
    "H"
  ],
  BH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  DZ: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  EG: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  EH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  HK: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  IQ: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  JO: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  KW: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  LB: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  LY: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  MO: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  MR: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  OM: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  PH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  PS: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  QA: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SA: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SD: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SY: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  TN: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  YE: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  AF: [
    "H",
    "hb",
    "hB",
    "h"
  ],
  LA: [
    "H",
    "hb",
    "hB",
    "h"
  ],
  CN: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  LV: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  TL: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  "zu-ZA": [
    "H",
    "hB",
    "hb",
    "h"
  ],
  CD: [
    "hB",
    "H"
  ],
  IR: [
    "hB",
    "H"
  ],
  "hi-IN": [
    "hB",
    "h",
    "H"
  ],
  "kn-IN": [
    "hB",
    "h",
    "H"
  ],
  "ml-IN": [
    "hB",
    "h",
    "H"
  ],
  "te-IN": [
    "hB",
    "h",
    "H"
  ],
  KH: [
    "hB",
    "h",
    "H",
    "hb"
  ],
  "ta-IN": [
    "hB",
    "h",
    "hb",
    "H"
  ],
  BN: [
    "hb",
    "hB",
    "h",
    "H"
  ],
  MY: [
    "hb",
    "hB",
    "h",
    "H"
  ],
  ET: [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "gu-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "mr-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "pa-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  TW: [
    "hB",
    "hb",
    "h",
    "H"
  ],
  KE: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  MM: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  TZ: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  UG: [
    "hB",
    "hb",
    "H",
    "h"
  ]
};
function pr(e, t) {
  for (var n = "", o = 0; o < e.length; o++) {
    var i = e.charAt(o);
    if (i === "j") {
      for (var a = 0; o + 1 < e.length && e.charAt(o + 1) === i; )
        a++, o++;
      var s = 1 + (a & 1), _ = a < 2 ? 1 : 3 + (a >> 1), l = "a", r = mr(t);
      for ((r == "H" || r == "k") && (_ = 0); _-- > 0; )
        n += l;
      for (; s-- > 0; )
        n = r + n;
    } else i === "J" ? n += "H" : n += i;
  }
  return n;
}
function mr(e) {
  var t = e.hourCycle;
  if (t === void 0 && // @ts-ignore hourCycle(s) is not identified yet
  e.hourCycles && // @ts-ignore
  e.hourCycles.length && (t = e.hourCycles[0]), t)
    switch (t) {
      case "h24":
        return "k";
      case "h23":
        return "H";
      case "h12":
        return "h";
      case "h11":
        return "K";
      default:
        throw new Error("Invalid hourCycle");
    }
  var n = e.language, o;
  n !== "root" && (o = e.maximize().region);
  var i = kn[o || ""] || kn[n || ""] || kn["".concat(n, "-001")] || kn["001"];
  return i[0];
}
var Bo, hr = new RegExp("^".concat(Ps.source, "*")), $r = new RegExp("".concat(Ps.source, "*$"));
function j(e, t) {
  return { start: e, end: t };
}
var vr = !!String.prototype.startsWith, gr = !!String.fromCodePoint, wr = !!Object.fromEntries, br = !!String.prototype.codePointAt, Sr = !!String.prototype.trimStart, Cr = !!String.prototype.trimEnd, qr = !!Number.isSafeInteger, yr = qr ? Number.isSafeInteger : function(e) {
  return typeof e == "number" && isFinite(e) && Math.floor(e) === e && Math.abs(e) <= 9007199254740991;
}, ti = !0;
try {
  var kr = Ds("([^\\p{White_Space}\\p{Pattern_Syntax}]*)", "yu");
  ti = ((Bo = kr.exec("a")) === null || Bo === void 0 ? void 0 : Bo[0]) === "a";
} catch {
  ti = !1;
}
var oa = vr ? (
  // Native
  function(t, n, o) {
    return t.startsWith(n, o);
  }
) : (
  // For IE11
  function(t, n, o) {
    return t.slice(o, o + n.length) === n;
  }
), ni = gr ? String.fromCodePoint : (
  // IE11
  function() {
    for (var t = [], n = 0; n < arguments.length; n++)
      t[n] = arguments[n];
    for (var o = "", i = t.length, a = 0, s; i > a; ) {
      if (s = t[a++], s > 1114111)
        throw RangeError(s + " is not a valid code point");
      o += s < 65536 ? String.fromCharCode(s) : String.fromCharCode(((s -= 65536) >> 10) + 55296, s % 1024 + 56320);
    }
    return o;
  }
), ia = (
  // native
  wr ? Object.fromEntries : (
    // Ponyfill
    function(t) {
      for (var n = {}, o = 0, i = t; o < i.length; o++) {
        var a = i[o], s = a[0], _ = a[1];
        n[s] = _;
      }
      return n;
    }
  )
), Os = br ? (
  // Native
  function(t, n) {
    return t.codePointAt(n);
  }
) : (
  // IE 11
  function(t, n) {
    var o = t.length;
    if (!(n < 0 || n >= o)) {
      var i = t.charCodeAt(n), a;
      return i < 55296 || i > 56319 || n + 1 === o || (a = t.charCodeAt(n + 1)) < 56320 || a > 57343 ? i : (i - 55296 << 10) + (a - 56320) + 65536;
    }
  }
), Er = Sr ? (
  // Native
  function(t) {
    return t.trimStart();
  }
) : (
  // Ponyfill
  function(t) {
    return t.replace(hr, "");
  }
), Tr = Cr ? (
  // Native
  function(t) {
    return t.trimEnd();
  }
) : (
  // Ponyfill
  function(t) {
    return t.replace($r, "");
  }
);
function Ds(e, t) {
  return new RegExp(e, t);
}
var oi;
if (ti) {
  var aa = Ds("([^\\p{White_Space}\\p{Pattern_Syntax}]*)", "yu");
  oi = function(t, n) {
    var o;
    aa.lastIndex = n;
    var i = aa.exec(t);
    return (o = i[1]) !== null && o !== void 0 ? o : "";
  };
} else
  oi = function(t, n) {
    for (var o = []; ; ) {
      var i = Os(t, n);
      if (i === void 0 || Fs(i) || Nr(i))
        break;
      o.push(i), n += i >= 65536 ? 2 : 1;
    }
    return ni.apply(void 0, o);
  };
var Br = (
  /** @class */
  function() {
    function e(t, n) {
      n === void 0 && (n = {}), this.message = t, this.position = { offset: 0, line: 1, column: 1 }, this.ignoreTag = !!n.ignoreTag, this.locale = n.locale, this.requiresOtherClause = !!n.requiresOtherClause, this.shouldParseSkeletons = !!n.shouldParseSkeletons;
    }
    return e.prototype.parse = function() {
      if (this.offset() !== 0)
        throw Error("parser can only be used once");
      return this.parseMessage(0, "", !1);
    }, e.prototype.parseMessage = function(t, n, o) {
      for (var i = []; !this.isEOF(); ) {
        var a = this.char();
        if (a === 123) {
          var s = this.parseArgument(t, o);
          if (s.err)
            return s;
          i.push(s.val);
        } else {
          if (a === 125 && t > 0)
            break;
          if (a === 35 && (n === "plural" || n === "selectordinal")) {
            var _ = this.clonePosition();
            this.bump(), i.push({
              type: K.pound,
              location: j(_, this.clonePosition())
            });
          } else if (a === 60 && !this.ignoreTag && this.peek() === 47) {
            if (o)
              break;
            return this.error(G.UNMATCHED_CLOSING_TAG, j(this.clonePosition(), this.clonePosition()));
          } else if (a === 60 && !this.ignoreTag && ii(this.peek() || 0)) {
            var s = this.parseTag(t, n);
            if (s.err)
              return s;
            i.push(s.val);
          } else {
            var s = this.parseLiteral(t, n);
            if (s.err)
              return s;
            i.push(s.val);
          }
        }
      }
      return { val: i, err: null };
    }, e.prototype.parseTag = function(t, n) {
      var o = this.clonePosition();
      this.bump();
      var i = this.parseTagName();
      if (this.bumpSpace(), this.bumpIf("/>"))
        return {
          val: {
            type: K.literal,
            value: "<".concat(i, "/>"),
            location: j(o, this.clonePosition())
          },
          err: null
        };
      if (this.bumpIf(">")) {
        var a = this.parseMessage(t + 1, n, !0);
        if (a.err)
          return a;
        var s = a.val, _ = this.clonePosition();
        if (this.bumpIf("</")) {
          if (this.isEOF() || !ii(this.char()))
            return this.error(G.INVALID_TAG, j(_, this.clonePosition()));
          var l = this.clonePosition(), r = this.parseTagName();
          return i !== r ? this.error(G.UNMATCHED_CLOSING_TAG, j(l, this.clonePosition())) : (this.bumpSpace(), this.bumpIf(">") ? {
            val: {
              type: K.tag,
              value: i,
              children: s,
              location: j(o, this.clonePosition())
            },
            err: null
          } : this.error(G.INVALID_TAG, j(_, this.clonePosition())));
        } else
          return this.error(G.UNCLOSED_TAG, j(o, this.clonePosition()));
      } else
        return this.error(G.INVALID_TAG, j(o, this.clonePosition()));
    }, e.prototype.parseTagName = function() {
      var t = this.offset();
      for (this.bump(); !this.isEOF() && Ar(this.char()); )
        this.bump();
      return this.message.slice(t, this.offset());
    }, e.prototype.parseLiteral = function(t, n) {
      for (var o = this.clonePosition(), i = ""; ; ) {
        var a = this.tryParseQuote(n);
        if (a) {
          i += a;
          continue;
        }
        var s = this.tryParseUnquoted(t, n);
        if (s) {
          i += s;
          continue;
        }
        var _ = this.tryParseLeftAngleBracket();
        if (_) {
          i += _;
          continue;
        }
        break;
      }
      var l = j(o, this.clonePosition());
      return {
        val: { type: K.literal, value: i, location: l },
        err: null
      };
    }, e.prototype.tryParseLeftAngleBracket = function() {
      return !this.isEOF() && this.char() === 60 && (this.ignoreTag || // If at the opening tag or closing tag position, bail.
      !Hr(this.peek() || 0)) ? (this.bump(), "<") : null;
    }, e.prototype.tryParseQuote = function(t) {
      if (this.isEOF() || this.char() !== 39)
        return null;
      switch (this.peek()) {
        case 39:
          return this.bump(), this.bump(), "'";
        case 123:
        case 60:
        case 62:
        case 125:
          break;
        case 35:
          if (t === "plural" || t === "selectordinal")
            break;
          return null;
        default:
          return null;
      }
      this.bump();
      var n = [this.char()];
      for (this.bump(); !this.isEOF(); ) {
        var o = this.char();
        if (o === 39)
          if (this.peek() === 39)
            n.push(39), this.bump();
          else {
            this.bump();
            break;
          }
        else
          n.push(o);
        this.bump();
      }
      return ni.apply(void 0, n);
    }, e.prototype.tryParseUnquoted = function(t, n) {
      if (this.isEOF())
        return null;
      var o = this.char();
      return o === 60 || o === 123 || o === 35 && (n === "plural" || n === "selectordinal") || o === 125 && t > 0 ? null : (this.bump(), ni(o));
    }, e.prototype.parseArgument = function(t, n) {
      var o = this.clonePosition();
      if (this.bump(), this.bumpSpace(), this.isEOF())
        return this.error(G.EXPECT_ARGUMENT_CLOSING_BRACE, j(o, this.clonePosition()));
      if (this.char() === 125)
        return this.bump(), this.error(G.EMPTY_ARGUMENT, j(o, this.clonePosition()));
      var i = this.parseIdentifierIfPossible().value;
      if (!i)
        return this.error(G.MALFORMED_ARGUMENT, j(o, this.clonePosition()));
      if (this.bumpSpace(), this.isEOF())
        return this.error(G.EXPECT_ARGUMENT_CLOSING_BRACE, j(o, this.clonePosition()));
      switch (this.char()) {
        case 125:
          return this.bump(), {
            val: {
              type: K.argument,
              // value does not include the opening and closing braces.
              value: i,
              location: j(o, this.clonePosition())
            },
            err: null
          };
        case 44:
          return this.bump(), this.bumpSpace(), this.isEOF() ? this.error(G.EXPECT_ARGUMENT_CLOSING_BRACE, j(o, this.clonePosition())) : this.parseArgumentOptions(t, n, i, o);
        default:
          return this.error(G.MALFORMED_ARGUMENT, j(o, this.clonePosition()));
      }
    }, e.prototype.parseIdentifierIfPossible = function() {
      var t = this.clonePosition(), n = this.offset(), o = oi(this.message, n), i = n + o.length;
      this.bumpTo(i);
      var a = this.clonePosition(), s = j(t, a);
      return { value: o, location: s };
    }, e.prototype.parseArgumentOptions = function(t, n, o, i) {
      var a, s = this.clonePosition(), _ = this.parseIdentifierIfPossible().value, l = this.clonePosition();
      switch (_) {
        case "":
          return this.error(G.EXPECT_ARGUMENT_TYPE, j(s, l));
        case "number":
        case "date":
        case "time": {
          this.bumpSpace();
          var r = null;
          if (this.bumpIf(",")) {
            this.bumpSpace();
            var u = this.clonePosition(), f = this.parseSimpleArgStyleIfPossible();
            if (f.err)
              return f;
            var d = Tr(f.val);
            if (d.length === 0)
              return this.error(G.EXPECT_ARGUMENT_STYLE, j(this.clonePosition(), this.clonePosition()));
            var c = j(u, this.clonePosition());
            r = { style: d, styleLocation: c };
          }
          var m = this.tryParseArgumentClose(i);
          if (m.err)
            return m;
          var w = j(i, this.clonePosition());
          if (r && oa(r == null ? void 0 : r.style, "::", 0)) {
            var b = Er(r.style.slice(2));
            if (_ === "number") {
              var f = this.parseNumberSkeletonFromString(b, r.styleLocation);
              return f.err ? f : {
                val: { type: K.number, value: o, location: w, style: f.val },
                err: null
              };
            } else {
              if (b.length === 0)
                return this.error(G.EXPECT_DATE_TIME_SKELETON, w);
              var v = b;
              this.locale && (v = pr(b, this.locale));
              var d = {
                type: jt.dateTime,
                pattern: v,
                location: r.styleLocation,
                parsedOptions: this.shouldParseSkeletons ? sr(v) : {}
              }, g = _ === "date" ? K.date : K.time;
              return {
                val: { type: g, value: o, location: w, style: d },
                err: null
              };
            }
          }
          return {
            val: {
              type: _ === "number" ? K.number : _ === "date" ? K.date : K.time,
              value: o,
              location: w,
              style: (a = r == null ? void 0 : r.style) !== null && a !== void 0 ? a : null
            },
            err: null
          };
        }
        case "plural":
        case "selectordinal":
        case "select": {
          var p = this.clonePosition();
          if (this.bumpSpace(), !this.bumpIf(","))
            return this.error(G.EXPECT_SELECT_ARGUMENT_OPTIONS, j(p, W({}, p)));
          this.bumpSpace();
          var h = this.parseIdentifierIfPossible(), S = 0;
          if (_ !== "select" && h.value === "offset") {
            if (!this.bumpIf(":"))
              return this.error(G.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE, j(this.clonePosition(), this.clonePosition()));
            this.bumpSpace();
            var f = this.tryParseDecimalInteger(G.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE, G.INVALID_PLURAL_ARGUMENT_OFFSET_VALUE);
            if (f.err)
              return f;
            this.bumpSpace(), h = this.parseIdentifierIfPossible(), S = f.val;
          }
          var $ = this.tryParsePluralOrSelectOptions(t, _, n, h);
          if ($.err)
            return $;
          var m = this.tryParseArgumentClose(i);
          if (m.err)
            return m;
          var y = j(i, this.clonePosition());
          return _ === "select" ? {
            val: {
              type: K.select,
              value: o,
              options: ia($.val),
              location: y
            },
            err: null
          } : {
            val: {
              type: K.plural,
              value: o,
              options: ia($.val),
              offset: S,
              pluralType: _ === "plural" ? "cardinal" : "ordinal",
              location: y
            },
            err: null
          };
        }
        default:
          return this.error(G.INVALID_ARGUMENT_TYPE, j(s, l));
      }
    }, e.prototype.tryParseArgumentClose = function(t) {
      return this.isEOF() || this.char() !== 125 ? this.error(G.EXPECT_ARGUMENT_CLOSING_BRACE, j(t, this.clonePosition())) : (this.bump(), { val: !0, err: null });
    }, e.prototype.parseSimpleArgStyleIfPossible = function() {
      for (var t = 0, n = this.clonePosition(); !this.isEOF(); ) {
        var o = this.char();
        switch (o) {
          case 39: {
            this.bump();
            var i = this.clonePosition();
            if (!this.bumpUntil("'"))
              return this.error(G.UNCLOSED_QUOTE_IN_ARGUMENT_STYLE, j(i, this.clonePosition()));
            this.bump();
            break;
          }
          case 123: {
            t += 1, this.bump();
            break;
          }
          case 125: {
            if (t > 0)
              t -= 1;
            else
              return {
                val: this.message.slice(n.offset, this.offset()),
                err: null
              };
            break;
          }
          default:
            this.bump();
            break;
        }
      }
      return {
        val: this.message.slice(n.offset, this.offset()),
        err: null
      };
    }, e.prototype.parseNumberSkeletonFromString = function(t, n) {
      var o = [];
      try {
        o = rr(t);
      } catch {
        return this.error(G.INVALID_NUMBER_SKELETON, n);
      }
      return {
        val: {
          type: jt.number,
          tokens: o,
          location: n,
          parsedOptions: this.shouldParseSkeletons ? cr(o) : {}
        },
        err: null
      };
    }, e.prototype.tryParsePluralOrSelectOptions = function(t, n, o, i) {
      for (var a, s = !1, _ = [], l = /* @__PURE__ */ new Set(), r = i.value, u = i.location; ; ) {
        if (r.length === 0) {
          var f = this.clonePosition();
          if (n !== "select" && this.bumpIf("=")) {
            var d = this.tryParseDecimalInteger(G.EXPECT_PLURAL_ARGUMENT_SELECTOR, G.INVALID_PLURAL_ARGUMENT_SELECTOR);
            if (d.err)
              return d;
            u = j(f, this.clonePosition()), r = this.message.slice(f.offset, this.offset());
          } else
            break;
        }
        if (l.has(r))
          return this.error(n === "select" ? G.DUPLICATE_SELECT_ARGUMENT_SELECTOR : G.DUPLICATE_PLURAL_ARGUMENT_SELECTOR, u);
        r === "other" && (s = !0), this.bumpSpace();
        var c = this.clonePosition();
        if (!this.bumpIf("{"))
          return this.error(n === "select" ? G.EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT : G.EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT, j(this.clonePosition(), this.clonePosition()));
        var m = this.parseMessage(t + 1, n, o);
        if (m.err)
          return m;
        var w = this.tryParseArgumentClose(c);
        if (w.err)
          return w;
        _.push([
          r,
          {
            value: m.val,
            location: j(c, this.clonePosition())
          }
        ]), l.add(r), this.bumpSpace(), a = this.parseIdentifierIfPossible(), r = a.value, u = a.location;
      }
      return _.length === 0 ? this.error(n === "select" ? G.EXPECT_SELECT_ARGUMENT_SELECTOR : G.EXPECT_PLURAL_ARGUMENT_SELECTOR, j(this.clonePosition(), this.clonePosition())) : this.requiresOtherClause && !s ? this.error(G.MISSING_OTHER_CLAUSE, j(this.clonePosition(), this.clonePosition())) : { val: _, err: null };
    }, e.prototype.tryParseDecimalInteger = function(t, n) {
      var o = 1, i = this.clonePosition();
      this.bumpIf("+") || this.bumpIf("-") && (o = -1);
      for (var a = !1, s = 0; !this.isEOF(); ) {
        var _ = this.char();
        if (_ >= 48 && _ <= 57)
          a = !0, s = s * 10 + (_ - 48), this.bump();
        else
          break;
      }
      var l = j(i, this.clonePosition());
      return a ? (s *= o, yr(s) ? { val: s, err: null } : this.error(n, l)) : this.error(t, l);
    }, e.prototype.offset = function() {
      return this.position.offset;
    }, e.prototype.isEOF = function() {
      return this.offset() === this.message.length;
    }, e.prototype.clonePosition = function() {
      return {
        offset: this.position.offset,
        line: this.position.line,
        column: this.position.column
      };
    }, e.prototype.char = function() {
      var t = this.position.offset;
      if (t >= this.message.length)
        throw Error("out of bound");
      var n = Os(this.message, t);
      if (n === void 0)
        throw Error("Offset ".concat(t, " is at invalid UTF-16 code unit boundary"));
      return n;
    }, e.prototype.error = function(t, n) {
      return {
        val: null,
        err: {
          kind: t,
          message: this.message,
          location: n
        }
      };
    }, e.prototype.bump = function() {
      if (!this.isEOF()) {
        var t = this.char();
        t === 10 ? (this.position.line += 1, this.position.column = 1, this.position.offset += 1) : (this.position.column += 1, this.position.offset += t < 65536 ? 1 : 2);
      }
    }, e.prototype.bumpIf = function(t) {
      if (oa(this.message, t, this.offset())) {
        for (var n = 0; n < t.length; n++)
          this.bump();
        return !0;
      }
      return !1;
    }, e.prototype.bumpUntil = function(t) {
      var n = this.offset(), o = this.message.indexOf(t, n);
      return o >= 0 ? (this.bumpTo(o), !0) : (this.bumpTo(this.message.length), !1);
    }, e.prototype.bumpTo = function(t) {
      if (this.offset() > t)
        throw Error("targetOffset ".concat(t, " must be greater than or equal to the current offset ").concat(this.offset()));
      for (t = Math.min(t, this.message.length); ; ) {
        var n = this.offset();
        if (n === t)
          break;
        if (n > t)
          throw Error("targetOffset ".concat(t, " is at invalid UTF-16 code unit boundary"));
        if (this.bump(), this.isEOF())
          break;
      }
    }, e.prototype.bumpSpace = function() {
      for (; !this.isEOF() && Fs(this.char()); )
        this.bump();
    }, e.prototype.peek = function() {
      if (this.isEOF())
        return null;
      var t = this.char(), n = this.offset(), o = this.message.charCodeAt(n + (t >= 65536 ? 2 : 1));
      return o ?? null;
    }, e;
  }()
);
function ii(e) {
  return e >= 97 && e <= 122 || e >= 65 && e <= 90;
}
function Hr(e) {
  return ii(e) || e === 47;
}
function Ar(e) {
  return e === 45 || e === 46 || e >= 48 && e <= 57 || e === 95 || e >= 97 && e <= 122 || e >= 65 && e <= 90 || e == 183 || e >= 192 && e <= 214 || e >= 216 && e <= 246 || e >= 248 && e <= 893 || e >= 895 && e <= 8191 || e >= 8204 && e <= 8205 || e >= 8255 && e <= 8256 || e >= 8304 && e <= 8591 || e >= 11264 && e <= 12271 || e >= 12289 && e <= 55295 || e >= 63744 && e <= 64975 || e >= 65008 && e <= 65533 || e >= 65536 && e <= 983039;
}
function Fs(e) {
  return e >= 9 && e <= 13 || e === 32 || e === 133 || e >= 8206 && e <= 8207 || e === 8232 || e === 8233;
}
function Nr(e) {
  return e >= 33 && e <= 35 || e === 36 || e >= 37 && e <= 39 || e === 40 || e === 41 || e === 42 || e === 43 || e === 44 || e === 45 || e >= 46 && e <= 47 || e >= 58 && e <= 59 || e >= 60 && e <= 62 || e >= 63 && e <= 64 || e === 91 || e === 92 || e === 93 || e === 94 || e === 96 || e === 123 || e === 124 || e === 125 || e === 126 || e === 161 || e >= 162 && e <= 165 || e === 166 || e === 167 || e === 169 || e === 171 || e === 172 || e === 174 || e === 176 || e === 177 || e === 182 || e === 187 || e === 191 || e === 215 || e === 247 || e >= 8208 && e <= 8213 || e >= 8214 && e <= 8215 || e === 8216 || e === 8217 || e === 8218 || e >= 8219 && e <= 8220 || e === 8221 || e === 8222 || e === 8223 || e >= 8224 && e <= 8231 || e >= 8240 && e <= 8248 || e === 8249 || e === 8250 || e >= 8251 && e <= 8254 || e >= 8257 && e <= 8259 || e === 8260 || e === 8261 || e === 8262 || e >= 8263 && e <= 8273 || e === 8274 || e === 8275 || e >= 8277 && e <= 8286 || e >= 8592 && e <= 8596 || e >= 8597 && e <= 8601 || e >= 8602 && e <= 8603 || e >= 8604 && e <= 8607 || e === 8608 || e >= 8609 && e <= 8610 || e === 8611 || e >= 8612 && e <= 8613 || e === 8614 || e >= 8615 && e <= 8621 || e === 8622 || e >= 8623 && e <= 8653 || e >= 8654 && e <= 8655 || e >= 8656 && e <= 8657 || e === 8658 || e === 8659 || e === 8660 || e >= 8661 && e <= 8691 || e >= 8692 && e <= 8959 || e >= 8960 && e <= 8967 || e === 8968 || e === 8969 || e === 8970 || e === 8971 || e >= 8972 && e <= 8991 || e >= 8992 && e <= 8993 || e >= 8994 && e <= 9e3 || e === 9001 || e === 9002 || e >= 9003 && e <= 9083 || e === 9084 || e >= 9085 && e <= 9114 || e >= 9115 && e <= 9139 || e >= 9140 && e <= 9179 || e >= 9180 && e <= 9185 || e >= 9186 && e <= 9254 || e >= 9255 && e <= 9279 || e >= 9280 && e <= 9290 || e >= 9291 && e <= 9311 || e >= 9472 && e <= 9654 || e === 9655 || e >= 9656 && e <= 9664 || e === 9665 || e >= 9666 && e <= 9719 || e >= 9720 && e <= 9727 || e >= 9728 && e <= 9838 || e === 9839 || e >= 9840 && e <= 10087 || e === 10088 || e === 10089 || e === 10090 || e === 10091 || e === 10092 || e === 10093 || e === 10094 || e === 10095 || e === 10096 || e === 10097 || e === 10098 || e === 10099 || e === 10100 || e === 10101 || e >= 10132 && e <= 10175 || e >= 10176 && e <= 10180 || e === 10181 || e === 10182 || e >= 10183 && e <= 10213 || e === 10214 || e === 10215 || e === 10216 || e === 10217 || e === 10218 || e === 10219 || e === 10220 || e === 10221 || e === 10222 || e === 10223 || e >= 10224 && e <= 10239 || e >= 10240 && e <= 10495 || e >= 10496 && e <= 10626 || e === 10627 || e === 10628 || e === 10629 || e === 10630 || e === 10631 || e === 10632 || e === 10633 || e === 10634 || e === 10635 || e === 10636 || e === 10637 || e === 10638 || e === 10639 || e === 10640 || e === 10641 || e === 10642 || e === 10643 || e === 10644 || e === 10645 || e === 10646 || e === 10647 || e === 10648 || e >= 10649 && e <= 10711 || e === 10712 || e === 10713 || e === 10714 || e === 10715 || e >= 10716 && e <= 10747 || e === 10748 || e === 10749 || e >= 10750 && e <= 11007 || e >= 11008 && e <= 11055 || e >= 11056 && e <= 11076 || e >= 11077 && e <= 11078 || e >= 11079 && e <= 11084 || e >= 11085 && e <= 11123 || e >= 11124 && e <= 11125 || e >= 11126 && e <= 11157 || e === 11158 || e >= 11159 && e <= 11263 || e >= 11776 && e <= 11777 || e === 11778 || e === 11779 || e === 11780 || e === 11781 || e >= 11782 && e <= 11784 || e === 11785 || e === 11786 || e === 11787 || e === 11788 || e === 11789 || e >= 11790 && e <= 11798 || e === 11799 || e >= 11800 && e <= 11801 || e === 11802 || e === 11803 || e === 11804 || e === 11805 || e >= 11806 && e <= 11807 || e === 11808 || e === 11809 || e === 11810 || e === 11811 || e === 11812 || e === 11813 || e === 11814 || e === 11815 || e === 11816 || e === 11817 || e >= 11818 && e <= 11822 || e === 11823 || e >= 11824 && e <= 11833 || e >= 11834 && e <= 11835 || e >= 11836 && e <= 11839 || e === 11840 || e === 11841 || e === 11842 || e >= 11843 && e <= 11855 || e >= 11856 && e <= 11857 || e === 11858 || e >= 11859 && e <= 11903 || e >= 12289 && e <= 12291 || e === 12296 || e === 12297 || e === 12298 || e === 12299 || e === 12300 || e === 12301 || e === 12302 || e === 12303 || e === 12304 || e === 12305 || e >= 12306 && e <= 12307 || e === 12308 || e === 12309 || e === 12310 || e === 12311 || e === 12312 || e === 12313 || e === 12314 || e === 12315 || e === 12316 || e === 12317 || e >= 12318 && e <= 12319 || e === 12320 || e === 12336 || e === 64830 || e === 64831 || e >= 65093 && e <= 65094;
}
function ai(e) {
  e.forEach(function(t) {
    if (delete t.location, Bs(t) || Hs(t))
      for (var n in t.options)
        delete t.options[n].location, ai(t.options[n].value);
    else ks(t) && Ns(t.style) || (Es(t) || Ts(t)) && ei(t.style) ? delete t.style.location : As(t) && ai(t.children);
  });
}
function Pr(e, t) {
  t === void 0 && (t = {}), t = W({ shouldParseSkeletons: !0, requiresOtherClause: !0 }, t);
  var n = new Br(e, t).parse();
  if (n.err) {
    var o = SyntaxError(G[n.err.kind]);
    throw o.location = n.err.location, o.originalMessage = n.err.message, o;
  }
  return t != null && t.captureLocation || ai(n.val), n.val;
}
function Ho(e, t) {
  var n = t && t.cache ? t.cache : Fr, o = t && t.serializer ? t.serializer : Dr, i = t && t.strategy ? t.strategy : Mr;
  return i(e, {
    cache: n,
    serializer: o
  });
}
function Lr(e) {
  return e == null || typeof e == "number" || typeof e == "boolean";
}
function Ir(e, t, n, o) {
  var i = Lr(o) ? o : n(o), a = t.get(i);
  return typeof a > "u" && (a = e.call(this, o), t.set(i, a)), a;
}
function Rs(e, t, n) {
  var o = Array.prototype.slice.call(arguments, 3), i = n(o), a = t.get(i);
  return typeof a > "u" && (a = e.apply(this, o), t.set(i, a)), a;
}
function Us(e, t, n, o, i) {
  return n.bind(t, e, o, i);
}
function Mr(e, t) {
  var n = e.length === 1 ? Ir : Rs;
  return Us(e, this, n, t.cache.create(), t.serializer);
}
function Or(e, t) {
  return Us(e, this, Rs, t.cache.create(), t.serializer);
}
var Dr = function() {
  return JSON.stringify(arguments);
};
function Pi() {
  this.cache = /* @__PURE__ */ Object.create(null);
}
Pi.prototype.get = function(e) {
  return this.cache[e];
};
Pi.prototype.set = function(e, t) {
  this.cache[e] = t;
};
var Fr = {
  create: function() {
    return new Pi();
  }
}, Ao = {
  variadic: Or
}, Vt;
(function(e) {
  e.MISSING_VALUE = "MISSING_VALUE", e.INVALID_VALUE = "INVALID_VALUE", e.MISSING_INTL_API = "MISSING_INTL_API";
})(Vt || (Vt = {}));
var wo = (
  /** @class */
  function(e) {
    go(t, e);
    function t(n, o, i) {
      var a = e.call(this, n) || this;
      return a.code = o, a.originalMessage = i, a;
    }
    return t.prototype.toString = function() {
      return "[formatjs Error: ".concat(this.code, "] ").concat(this.message);
    }, t;
  }(Error)
), la = (
  /** @class */
  function(e) {
    go(t, e);
    function t(n, o, i, a) {
      return e.call(this, 'Invalid values for "'.concat(n, '": "').concat(o, '". Options are "').concat(Object.keys(i).join('", "'), '"'), Vt.INVALID_VALUE, a) || this;
    }
    return t;
  }(wo)
), Rr = (
  /** @class */
  function(e) {
    go(t, e);
    function t(n, o, i) {
      return e.call(this, 'Value for "'.concat(n, '" must be of type ').concat(o), Vt.INVALID_VALUE, i) || this;
    }
    return t;
  }(wo)
), Ur = (
  /** @class */
  function(e) {
    go(t, e);
    function t(n, o) {
      return e.call(this, 'The intl string context variable "'.concat(n, '" was not provided to the string "').concat(o, '"'), Vt.MISSING_VALUE, o) || this;
    }
    return t;
  }(wo)
), _e;
(function(e) {
  e[e.literal = 0] = "literal", e[e.object = 1] = "object";
})(_e || (_e = {}));
function Gr(e) {
  return e.length < 2 ? e : e.reduce(function(t, n) {
    var o = t[t.length - 1];
    return !o || o.type !== _e.literal || n.type !== _e.literal ? t.push(n) : o.value += n.value, t;
  }, []);
}
function jr(e) {
  return typeof e == "function";
}
function jn(e, t, n, o, i, a, s) {
  if (e.length === 1 && xi(e[0]))
    return [
      {
        type: _e.literal,
        value: e[0].value
      }
    ];
  for (var _ = [], l = 0, r = e; l < r.length; l++) {
    var u = r[l];
    if (xi(u)) {
      _.push({
        type: _e.literal,
        value: u.value
      });
      continue;
    }
    if (ar(u)) {
      typeof a == "number" && _.push({
        type: _e.literal,
        value: n.getNumberFormat(t).format(a)
      });
      continue;
    }
    var f = u.value;
    if (!(i && f in i))
      throw new Ur(f, s);
    var d = i[f];
    if (ir(u)) {
      (!d || typeof d == "string" || typeof d == "number") && (d = typeof d == "string" || typeof d == "number" ? String(d) : ""), _.push({
        type: typeof d == "string" ? _e.literal : _e.object,
        value: d
      });
      continue;
    }
    if (Es(u)) {
      var c = typeof u.style == "string" ? o.date[u.style] : ei(u.style) ? u.style.parsedOptions : void 0;
      _.push({
        type: _e.literal,
        value: n.getDateTimeFormat(t, c).format(d)
      });
      continue;
    }
    if (Ts(u)) {
      var c = typeof u.style == "string" ? o.time[u.style] : ei(u.style) ? u.style.parsedOptions : o.time.medium;
      _.push({
        type: _e.literal,
        value: n.getDateTimeFormat(t, c).format(d)
      });
      continue;
    }
    if (ks(u)) {
      var c = typeof u.style == "string" ? o.number[u.style] : Ns(u.style) ? u.style.parsedOptions : void 0;
      c && c.scale && (d = d * (c.scale || 1)), _.push({
        type: _e.literal,
        value: n.getNumberFormat(t, c).format(d)
      });
      continue;
    }
    if (As(u)) {
      var m = u.children, w = u.value, b = i[w];
      if (!jr(b))
        throw new Rr(w, "function", s);
      var v = jn(m, t, n, o, i, a), g = b(v.map(function(S) {
        return S.value;
      }));
      Array.isArray(g) || (g = [g]), _.push.apply(_, g.map(function(S) {
        return {
          type: typeof S == "string" ? _e.literal : _e.object,
          value: S
        };
      }));
    }
    if (Bs(u)) {
      var p = u.options[d] || u.options.other;
      if (!p)
        throw new la(u.value, d, Object.keys(u.options), s);
      _.push.apply(_, jn(p.value, t, n, o, i));
      continue;
    }
    if (Hs(u)) {
      var p = u.options["=".concat(d)];
      if (!p) {
        if (!Intl.PluralRules)
          throw new wo(`Intl.PluralRules is not available in this environment.
Try polyfilling it using "@formatjs/intl-pluralrules"
`, Vt.MISSING_INTL_API, s);
        var h = n.getPluralRules(t, { type: u.pluralType }).select(d - (u.offset || 0));
        p = u.options[h] || u.options.other;
      }
      if (!p)
        throw new la(u.value, d, Object.keys(u.options), s);
      _.push.apply(_, jn(p.value, t, n, o, i, d - (u.offset || 0)));
      continue;
    }
  }
  return Gr(_);
}
function Vr(e, t) {
  return t ? W(W(W({}, e || {}), t || {}), Object.keys(e).reduce(function(n, o) {
    return n[o] = W(W({}, e[o]), t[o] || {}), n;
  }, {})) : e;
}
function zr(e, t) {
  return t ? Object.keys(e).reduce(function(n, o) {
    return n[o] = Vr(e[o], t[o]), n;
  }, W({}, e)) : e;
}
function No(e) {
  return {
    create: function() {
      return {
        get: function(t) {
          return e[t];
        },
        set: function(t, n) {
          e[t] = n;
        }
      };
    }
  };
}
function Xr(e) {
  return e === void 0 && (e = {
    number: {},
    dateTime: {},
    pluralRules: {}
  }), {
    getNumberFormat: Ho(function() {
      for (var t, n = [], o = 0; o < arguments.length; o++)
        n[o] = arguments[o];
      return new ((t = Intl.NumberFormat).bind.apply(t, To([void 0], n, !1)))();
    }, {
      cache: No(e.number),
      strategy: Ao.variadic
    }),
    getDateTimeFormat: Ho(function() {
      for (var t, n = [], o = 0; o < arguments.length; o++)
        n[o] = arguments[o];
      return new ((t = Intl.DateTimeFormat).bind.apply(t, To([void 0], n, !1)))();
    }, {
      cache: No(e.dateTime),
      strategy: Ao.variadic
    }),
    getPluralRules: Ho(function() {
      for (var t, n = [], o = 0; o < arguments.length; o++)
        n[o] = arguments[o];
      return new ((t = Intl.PluralRules).bind.apply(t, To([void 0], n, !1)))();
    }, {
      cache: No(e.pluralRules),
      strategy: Ao.variadic
    })
  };
}
var Zr = (
  /** @class */
  function() {
    function e(t, n, o, i) {
      var a = this;
      if (n === void 0 && (n = e.defaultLocale), this.formatterCache = {
        number: {},
        dateTime: {},
        pluralRules: {}
      }, this.format = function(s) {
        var _ = a.formatToParts(s);
        if (_.length === 1)
          return _[0].value;
        var l = _.reduce(function(r, u) {
          return !r.length || u.type !== _e.literal || typeof r[r.length - 1] != "string" ? r.push(u.value) : r[r.length - 1] += u.value, r;
        }, []);
        return l.length <= 1 ? l[0] || "" : l;
      }, this.formatToParts = function(s) {
        return jn(a.ast, a.locales, a.formatters, a.formats, s, void 0, a.message);
      }, this.resolvedOptions = function() {
        return {
          locale: a.resolvedLocale.toString()
        };
      }, this.getAst = function() {
        return a.ast;
      }, this.locales = n, this.resolvedLocale = e.resolveLocale(n), typeof t == "string") {
        if (this.message = t, !e.__parse)
          throw new TypeError("IntlMessageFormat.__parse must be set to process `message` of type `string`");
        this.ast = e.__parse(t, {
          ignoreTag: i == null ? void 0 : i.ignoreTag,
          locale: this.resolvedLocale
        });
      } else
        this.ast = t;
      if (!Array.isArray(this.ast))
        throw new TypeError("A message must be provided as a String or AST.");
      this.formats = zr(e.formats, o), this.formatters = i && i.formatters || Xr(this.formatterCache);
    }
    return Object.defineProperty(e, "defaultLocale", {
      get: function() {
        return e.memoizedDefaultLocale || (e.memoizedDefaultLocale = new Intl.NumberFormat().resolvedOptions().locale), e.memoizedDefaultLocale;
      },
      enumerable: !1,
      configurable: !0
    }), e.memoizedDefaultLocale = null, e.resolveLocale = function(t) {
      var n = Intl.NumberFormat.supportedLocalesOf(t);
      return n.length > 0 ? new Intl.Locale(n[0]) : new Intl.Locale(typeof t == "string" ? t : t[0]);
    }, e.__parse = Pr, e.formats = {
      number: {
        integer: {
          maximumFractionDigits: 0
        },
        currency: {
          style: "currency"
        },
        percent: {
          style: "percent"
        }
      },
      date: {
        short: {
          month: "numeric",
          day: "numeric",
          year: "2-digit"
        },
        medium: {
          month: "short",
          day: "numeric",
          year: "numeric"
        },
        long: {
          month: "long",
          day: "numeric",
          year: "numeric"
        },
        full: {
          weekday: "long",
          month: "long",
          day: "numeric",
          year: "numeric"
        }
      },
      time: {
        short: {
          hour: "numeric",
          minute: "numeric"
        },
        medium: {
          hour: "numeric",
          minute: "numeric",
          second: "numeric"
        },
        long: {
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
          timeZoneName: "short"
        },
        full: {
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
          timeZoneName: "short"
        }
      }
    }, e;
  }()
);
function Wr(e, t) {
  if (t == null)
    return;
  if (t in e)
    return e[t];
  const n = t.split(".");
  let o = e;
  for (let i = 0; i < n.length; i++)
    if (typeof o == "object") {
      if (i > 0) {
        const a = n.slice(i, n.length).join(".");
        if (a in o) {
          o = o[a];
          break;
        }
      }
      o = o[n[i]];
    } else
      o = void 0;
  return o;
}
const ot = {}, Jr = (e, t, n) => n && (t in ot || (ot[t] = {}), e in ot[t] || (ot[t][e] = n), n), Gs = (e, t) => {
  if (t == null)
    return;
  if (t in ot && e in ot[t])
    return ot[t][e];
  const n = bo(t);
  for (let o = 0; o < n.length; o++) {
    const i = n[o], a = Yr(i, e);
    if (a)
      return Jr(e, t, a);
  }
};
let Li;
const qn = Cn({});
function Qr(e) {
  return Li[e] || null;
}
function js(e) {
  return e in Li;
}
function Yr(e, t) {
  if (!js(e))
    return null;
  const n = Qr(e);
  return Wr(n, t);
}
function Kr(e) {
  if (e == null)
    return;
  const t = bo(e);
  for (let n = 0; n < t.length; n++) {
    const o = t[n];
    if (js(o))
      return o;
  }
}
function xr(e, ...t) {
  delete ot[e], qn.update((n) => (n[e] = Gt.all([n[e] || {}, ...t]), n));
}
Qt(
  [qn],
  ([e]) => Object.keys(e)
);
qn.subscribe((e) => Li = e);
const Vn = {};
function eu(e, t) {
  Vn[e].delete(t), Vn[e].size === 0 && delete Vn[e];
}
function Vs(e) {
  return Vn[e];
}
function tu(e) {
  return bo(e).map((t) => {
    const n = Vs(t);
    return [t, n ? [...n] : []];
  }).filter(([, t]) => t.length > 0);
}
function li(e) {
  return e == null ? !1 : bo(e).some(
    (t) => {
      var n;
      return (n = Vs(t)) == null ? void 0 : n.size;
    }
  );
}
function nu(e, t) {
  return Promise.all(
    t.map((o) => (eu(e, o), o().then((i) => i.default || i)))
  ).then((o) => xr(e, ...o));
}
const tn = {};
function zs(e) {
  if (!li(e))
    return e in tn ? tn[e] : Promise.resolve();
  const t = tu(e);
  return tn[e] = Promise.all(
    t.map(
      ([n, o]) => nu(n, o)
    )
  ).then(() => {
    if (li(e))
      return zs(e);
    delete tn[e];
  }), tn[e];
}
const ou = {
  number: {
    scientific: { notation: "scientific" },
    engineering: { notation: "engineering" },
    compactLong: { notation: "compact", compactDisplay: "long" },
    compactShort: { notation: "compact", compactDisplay: "short" }
  },
  date: {
    short: { month: "numeric", day: "numeric", year: "2-digit" },
    medium: { month: "short", day: "numeric", year: "numeric" },
    long: { month: "long", day: "numeric", year: "numeric" },
    full: { weekday: "long", month: "long", day: "numeric", year: "numeric" }
  },
  time: {
    short: { hour: "numeric", minute: "numeric" },
    medium: { hour: "numeric", minute: "numeric", second: "numeric" },
    long: {
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
      timeZoneName: "short"
    },
    full: {
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
      timeZoneName: "short"
    }
  }
}, iu = {
  fallbackLocale: null,
  loadingDelay: 200,
  formats: ou,
  warnOnMissingMessages: !0,
  handleMissingMessage: void 0,
  ignoreTag: !0
}, au = iu;
function zt() {
  return au;
}
const Po = Cn(!1);
var lu = Object.defineProperty, su = Object.defineProperties, _u = Object.getOwnPropertyDescriptors, sa = Object.getOwnPropertySymbols, ru = Object.prototype.hasOwnProperty, uu = Object.prototype.propertyIsEnumerable, _a = (e, t, n) => t in e ? lu(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, fu = (e, t) => {
  for (var n in t || (t = {}))
    ru.call(t, n) && _a(e, n, t[n]);
  if (sa)
    for (var n of sa(t))
      uu.call(t, n) && _a(e, n, t[n]);
  return e;
}, du = (e, t) => su(e, _u(t));
let si;
const Yn = Cn(null);
function ra(e) {
  return e.split("-").map((t, n, o) => o.slice(0, n + 1).join("-")).reverse();
}
function bo(e, t = zt().fallbackLocale) {
  const n = ra(e);
  return t ? [.../* @__PURE__ */ new Set([...n, ...ra(t)])] : n;
}
function wt() {
  return si ?? void 0;
}
Yn.subscribe((e) => {
  si = e ?? void 0, typeof window < "u" && e != null && document.documentElement.setAttribute("lang", e);
});
const cu = (e) => {
  if (e && Kr(e) && li(e)) {
    const { loadingDelay: t } = zt();
    let n;
    return typeof window < "u" && wt() != null && t ? n = window.setTimeout(
      () => Po.set(!0),
      t
    ) : Po.set(!0), zs(e).then(() => {
      Yn.set(e);
    }).finally(() => {
      clearTimeout(n), Po.set(!1);
    });
  }
  return Yn.set(e);
}, yn = du(fu({}, Yn), {
  set: cu
}), So = (e) => {
  const t = /* @__PURE__ */ Object.create(null);
  return (o) => {
    const i = JSON.stringify(o);
    return i in t ? t[i] : t[i] = e(o);
  };
};
var pu = Object.defineProperty, Kn = Object.getOwnPropertySymbols, Xs = Object.prototype.hasOwnProperty, Zs = Object.prototype.propertyIsEnumerable, ua = (e, t, n) => t in e ? pu(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, Ii = (e, t) => {
  for (var n in t || (t = {}))
    Xs.call(t, n) && ua(e, n, t[n]);
  if (Kn)
    for (var n of Kn(t))
      Zs.call(t, n) && ua(e, n, t[n]);
  return e;
}, Yt = (e, t) => {
  var n = {};
  for (var o in e)
    Xs.call(e, o) && t.indexOf(o) < 0 && (n[o] = e[o]);
  if (e != null && Kn)
    for (var o of Kn(e))
      t.indexOf(o) < 0 && Zs.call(e, o) && (n[o] = e[o]);
  return n;
};
const hn = (e, t) => {
  const { formats: n } = zt();
  if (e in n && t in n[e])
    return n[e][t];
  throw new Error(`[svelte-i18n] Unknown "${t}" ${e} format.`);
}, mu = So(
  (e) => {
    var t = e, { locale: n, format: o } = t, i = Yt(t, ["locale", "format"]);
    if (n == null)
      throw new Error('[svelte-i18n] A "locale" must be set to format numbers');
    return o && (i = hn("number", o)), new Intl.NumberFormat(n, i);
  }
), hu = So(
  (e) => {
    var t = e, { locale: n, format: o } = t, i = Yt(t, ["locale", "format"]);
    if (n == null)
      throw new Error('[svelte-i18n] A "locale" must be set to format dates');
    return o ? i = hn("date", o) : Object.keys(i).length === 0 && (i = hn("date", "short")), new Intl.DateTimeFormat(n, i);
  }
), $u = So(
  (e) => {
    var t = e, { locale: n, format: o } = t, i = Yt(t, ["locale", "format"]);
    if (n == null)
      throw new Error(
        '[svelte-i18n] A "locale" must be set to format time values'
      );
    return o ? i = hn("time", o) : Object.keys(i).length === 0 && (i = hn("time", "short")), new Intl.DateTimeFormat(n, i);
  }
), vu = (e = {}) => {
  var t = e, {
    locale: n = wt()
  } = t, o = Yt(t, [
    "locale"
  ]);
  return mu(Ii({ locale: n }, o));
}, gu = (e = {}) => {
  var t = e, {
    locale: n = wt()
  } = t, o = Yt(t, [
    "locale"
  ]);
  return hu(Ii({ locale: n }, o));
}, wu = (e = {}) => {
  var t = e, {
    locale: n = wt()
  } = t, o = Yt(t, [
    "locale"
  ]);
  return $u(Ii({ locale: n }, o));
}, bu = So(
  // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
  (e, t = wt()) => new Zr(e, t, zt().formats, {
    ignoreTag: zt().ignoreTag
  })
), Su = (e, t = {}) => {
  var n, o, i, a;
  let s = t;
  typeof e == "object" && (s = e, e = s.id);
  const {
    values: _,
    locale: l = wt(),
    default: r
  } = s;
  if (l == null)
    throw new Error(
      "[svelte-i18n] Cannot format a message without first setting the initial locale."
    );
  let u = Gs(e, l);
  if (!u)
    u = (a = (i = (o = (n = zt()).handleMissingMessage) == null ? void 0 : o.call(n, { locale: l, id: e, defaultValue: r })) != null ? i : r) != null ? a : e;
  else if (typeof u != "string")
    return console.warn(
      `[svelte-i18n] Message with id "${e}" must be of type "string", found: "${typeof u}". Gettin its value through the "$format" method is deprecated; use the "json" method instead.`
    ), u;
  if (!_)
    return u;
  let f = u;
  try {
    f = bu(u, l).format(_);
  } catch (d) {
    d instanceof Error && console.warn(
      `[svelte-i18n] Message "${e}" has syntax error:`,
      d.message
    );
  }
  return f;
}, Cu = (e, t) => wu(t).format(e), qu = (e, t) => gu(t).format(e), yu = (e, t) => vu(t).format(e), ku = (e, t = wt()) => Gs(e, t);
Qt([yn, qn], () => Su);
Qt([yn], () => Cu);
Qt([yn], () => qu);
Qt([yn], () => yu);
Qt([yn, qn], () => ku);
const {
  SvelteComponent: Eu,
  assign: Tu,
  create_slot: Bu,
  detach: Hu,
  element: Au,
  get_all_dirty_from_scope: Nu,
  get_slot_changes: Pu,
  get_spread_update: Lu,
  init: Iu,
  insert: Mu,
  safe_not_equal: Ou,
  set_dynamic_element_data: fa,
  set_style: fe,
  toggle_class: xe,
  transition_in: Ws,
  transition_out: Js,
  update_slot_base: Du
} = window.__gradio__svelte__internal;
function Fu(e) {
  let t, n, o;
  const i = (
    /*#slots*/
    e[17].default
  ), a = Bu(
    i,
    e,
    /*$$scope*/
    e[16],
    null
  );
  let s = [
    { "data-testid": (
      /*test_id*/
      e[7]
    ) },
    { id: (
      /*elem_id*/
      e[2]
    ) },
    {
      class: n = "block " + /*elem_classes*/
      e[3].join(" ") + " svelte-1t38q2d"
    }
  ], _ = {};
  for (let l = 0; l < s.length; l += 1)
    _ = Tu(_, s[l]);
  return {
    c() {
      t = Au(
        /*tag*/
        e[14]
      ), a && a.c(), fa(
        /*tag*/
        e[14]
      )(t, _), xe(
        t,
        "hidden",
        /*visible*/
        e[10] === !1
      ), xe(
        t,
        "padded",
        /*padding*/
        e[6]
      ), xe(
        t,
        "border_focus",
        /*border_mode*/
        e[5] === "focus"
      ), xe(t, "hide-container", !/*explicit_call*/
      e[8] && !/*container*/
      e[9]), fe(t, "height", typeof /*height*/
      e[0] == "number" ? (
        /*height*/
        e[0] + "px"
      ) : void 0), fe(t, "width", typeof /*width*/
      e[1] == "number" ? `calc(min(${/*width*/
      e[1]}px, 100%))` : void 0), fe(
        t,
        "border-style",
        /*variant*/
        e[4]
      ), fe(
        t,
        "overflow",
        /*allow_overflow*/
        e[11] ? "visible" : "hidden"
      ), fe(
        t,
        "flex-grow",
        /*scale*/
        e[12]
      ), fe(t, "min-width", `calc(min(${/*min_width*/
      e[13]}px, 100%))`), fe(t, "border-width", "var(--block-border-width)");
    },
    m(l, r) {
      Mu(l, t, r), a && a.m(t, null), o = !0;
    },
    p(l, r) {
      a && a.p && (!o || r & /*$$scope*/
      65536) && Du(
        a,
        i,
        l,
        /*$$scope*/
        l[16],
        o ? Pu(
          i,
          /*$$scope*/
          l[16],
          r,
          null
        ) : Nu(
          /*$$scope*/
          l[16]
        ),
        null
      ), fa(
        /*tag*/
        l[14]
      )(t, _ = Lu(s, [
        (!o || r & /*test_id*/
        128) && { "data-testid": (
          /*test_id*/
          l[7]
        ) },
        (!o || r & /*elem_id*/
        4) && { id: (
          /*elem_id*/
          l[2]
        ) },
        (!o || r & /*elem_classes*/
        8 && n !== (n = "block " + /*elem_classes*/
        l[3].join(" ") + " svelte-1t38q2d")) && { class: n }
      ])), xe(
        t,
        "hidden",
        /*visible*/
        l[10] === !1
      ), xe(
        t,
        "padded",
        /*padding*/
        l[6]
      ), xe(
        t,
        "border_focus",
        /*border_mode*/
        l[5] === "focus"
      ), xe(t, "hide-container", !/*explicit_call*/
      l[8] && !/*container*/
      l[9]), r & /*height*/
      1 && fe(t, "height", typeof /*height*/
      l[0] == "number" ? (
        /*height*/
        l[0] + "px"
      ) : void 0), r & /*width*/
      2 && fe(t, "width", typeof /*width*/
      l[1] == "number" ? `calc(min(${/*width*/
      l[1]}px, 100%))` : void 0), r & /*variant*/
      16 && fe(
        t,
        "border-style",
        /*variant*/
        l[4]
      ), r & /*allow_overflow*/
      2048 && fe(
        t,
        "overflow",
        /*allow_overflow*/
        l[11] ? "visible" : "hidden"
      ), r & /*scale*/
      4096 && fe(
        t,
        "flex-grow",
        /*scale*/
        l[12]
      ), r & /*min_width*/
      8192 && fe(t, "min-width", `calc(min(${/*min_width*/
      l[13]}px, 100%))`);
    },
    i(l) {
      o || (Ws(a, l), o = !0);
    },
    o(l) {
      Js(a, l), o = !1;
    },
    d(l) {
      l && Hu(t), a && a.d(l);
    }
  };
}
function Ru(e) {
  let t, n = (
    /*tag*/
    e[14] && Fu(e)
  );
  return {
    c() {
      n && n.c();
    },
    m(o, i) {
      n && n.m(o, i), t = !0;
    },
    p(o, [i]) {
      /*tag*/
      o[14] && n.p(o, i);
    },
    i(o) {
      t || (Ws(n, o), t = !0);
    },
    o(o) {
      Js(n, o), t = !1;
    },
    d(o) {
      n && n.d(o);
    }
  };
}
function Uu(e, t, n) {
  let { $$slots: o = {}, $$scope: i } = t, { height: a = void 0 } = t, { width: s = void 0 } = t, { elem_id: _ = "" } = t, { elem_classes: l = [] } = t, { variant: r = "solid" } = t, { border_mode: u = "base" } = t, { padding: f = !0 } = t, { type: d = "normal" } = t, { test_id: c = void 0 } = t, { explicit_call: m = !1 } = t, { container: w = !0 } = t, { visible: b = !0 } = t, { allow_overflow: v = !0 } = t, { scale: g = null } = t, { min_width: p = 0 } = t, h = d === "fieldset" ? "fieldset" : "div";
  return e.$$set = (S) => {
    "height" in S && n(0, a = S.height), "width" in S && n(1, s = S.width), "elem_id" in S && n(2, _ = S.elem_id), "elem_classes" in S && n(3, l = S.elem_classes), "variant" in S && n(4, r = S.variant), "border_mode" in S && n(5, u = S.border_mode), "padding" in S && n(6, f = S.padding), "type" in S && n(15, d = S.type), "test_id" in S && n(7, c = S.test_id), "explicit_call" in S && n(8, m = S.explicit_call), "container" in S && n(9, w = S.container), "visible" in S && n(10, b = S.visible), "allow_overflow" in S && n(11, v = S.allow_overflow), "scale" in S && n(12, g = S.scale), "min_width" in S && n(13, p = S.min_width), "$$scope" in S && n(16, i = S.$$scope);
  }, [
    a,
    s,
    _,
    l,
    r,
    u,
    f,
    c,
    m,
    w,
    b,
    v,
    g,
    p,
    h,
    d,
    i,
    o
  ];
}
let Gu = class extends Eu {
  constructor(t) {
    super(), Iu(this, t, Uu, Ru, Ou, {
      height: 0,
      width: 1,
      elem_id: 2,
      elem_classes: 3,
      variant: 4,
      border_mode: 5,
      padding: 6,
      type: 15,
      test_id: 7,
      explicit_call: 8,
      container: 9,
      visible: 10,
      allow_overflow: 11,
      scale: 12,
      min_width: 13
    });
  }
};
const {
  SvelteComponent: ju,
  attr: Vu,
  create_slot: zu,
  detach: Xu,
  element: Zu,
  get_all_dirty_from_scope: Wu,
  get_slot_changes: Ju,
  init: Qu,
  insert: Yu,
  safe_not_equal: Ku,
  transition_in: xu,
  transition_out: ef,
  update_slot_base: tf
} = window.__gradio__svelte__internal;
function nf(e) {
  let t, n;
  const o = (
    /*#slots*/
    e[1].default
  ), i = zu(
    o,
    e,
    /*$$scope*/
    e[0],
    null
  );
  return {
    c() {
      t = Zu("div"), i && i.c(), Vu(t, "class", "svelte-1hnfib2");
    },
    m(a, s) {
      Yu(a, t, s), i && i.m(t, null), n = !0;
    },
    p(a, [s]) {
      i && i.p && (!n || s & /*$$scope*/
      1) && tf(
        i,
        o,
        a,
        /*$$scope*/
        a[0],
        n ? Ju(
          o,
          /*$$scope*/
          a[0],
          s,
          null
        ) : Wu(
          /*$$scope*/
          a[0]
        ),
        null
      );
    },
    i(a) {
      n || (xu(i, a), n = !0);
    },
    o(a) {
      ef(i, a), n = !1;
    },
    d(a) {
      a && Xu(t), i && i.d(a);
    }
  };
}
function of(e, t, n) {
  let { $$slots: o = {}, $$scope: i } = t;
  return e.$$set = (a) => {
    "$$scope" in a && n(0, i = a.$$scope);
  }, [i, o];
}
let af = class extends ju {
  constructor(t) {
    super(), Qu(this, t, of, nf, Ku, {});
  }
};
const {
  SvelteComponent: lf,
  attr: da,
  check_outros: sf,
  create_component: _f,
  create_slot: rf,
  destroy_component: uf,
  detach: zn,
  element: ff,
  empty: df,
  get_all_dirty_from_scope: cf,
  get_slot_changes: pf,
  group_outros: mf,
  init: hf,
  insert: Xn,
  mount_component: $f,
  safe_not_equal: vf,
  set_data: gf,
  space: wf,
  text: bf,
  toggle_class: St,
  transition_in: an,
  transition_out: Zn,
  update_slot_base: Sf
} = window.__gradio__svelte__internal;
function ca(e) {
  let t, n;
  return t = new af({
    props: {
      $$slots: { default: [Cf] },
      $$scope: { ctx: e }
    }
  }), {
    c() {
      _f(t.$$.fragment);
    },
    m(o, i) {
      $f(t, o, i), n = !0;
    },
    p(o, i) {
      const a = {};
      i & /*$$scope, info*/
      10 && (a.$$scope = { dirty: i, ctx: o }), t.$set(a);
    },
    i(o) {
      n || (an(t.$$.fragment, o), n = !0);
    },
    o(o) {
      Zn(t.$$.fragment, o), n = !1;
    },
    d(o) {
      uf(t, o);
    }
  };
}
function Cf(e) {
  let t;
  return {
    c() {
      t = bf(
        /*info*/
        e[1]
      );
    },
    m(n, o) {
      Xn(n, t, o);
    },
    p(n, o) {
      o & /*info*/
      2 && gf(
        t,
        /*info*/
        n[1]
      );
    },
    d(n) {
      n && zn(t);
    }
  };
}
function qf(e) {
  let t, n, o, i;
  const a = (
    /*#slots*/
    e[2].default
  ), s = rf(
    a,
    e,
    /*$$scope*/
    e[3],
    null
  );
  let _ = (
    /*info*/
    e[1] && ca(e)
  );
  return {
    c() {
      t = ff("span"), s && s.c(), n = wf(), _ && _.c(), o = df(), da(t, "data-testid", "block-info"), da(t, "class", "svelte-22c38v"), St(t, "sr-only", !/*show_label*/
      e[0]), St(t, "hide", !/*show_label*/
      e[0]), St(
        t,
        "has-info",
        /*info*/
        e[1] != null
      );
    },
    m(l, r) {
      Xn(l, t, r), s && s.m(t, null), Xn(l, n, r), _ && _.m(l, r), Xn(l, o, r), i = !0;
    },
    p(l, [r]) {
      s && s.p && (!i || r & /*$$scope*/
      8) && Sf(
        s,
        a,
        l,
        /*$$scope*/
        l[3],
        i ? pf(
          a,
          /*$$scope*/
          l[3],
          r,
          null
        ) : cf(
          /*$$scope*/
          l[3]
        ),
        null
      ), (!i || r & /*show_label*/
      1) && St(t, "sr-only", !/*show_label*/
      l[0]), (!i || r & /*show_label*/
      1) && St(t, "hide", !/*show_label*/
      l[0]), (!i || r & /*info*/
      2) && St(
        t,
        "has-info",
        /*info*/
        l[1] != null
      ), /*info*/
      l[1] ? _ ? (_.p(l, r), r & /*info*/
      2 && an(_, 1)) : (_ = ca(l), _.c(), an(_, 1), _.m(o.parentNode, o)) : _ && (mf(), Zn(_, 1, 1, () => {
        _ = null;
      }), sf());
    },
    i(l) {
      i || (an(s, l), an(_), i = !0);
    },
    o(l) {
      Zn(s, l), Zn(_), i = !1;
    },
    d(l) {
      l && (zn(t), zn(n), zn(o)), s && s.d(l), _ && _.d(l);
    }
  };
}
function yf(e, t, n) {
  let { $$slots: o = {}, $$scope: i } = t, { show_label: a = !0 } = t, { info: s = void 0 } = t;
  return e.$$set = (_) => {
    "show_label" in _ && n(0, a = _.show_label), "info" in _ && n(1, s = _.info), "$$scope" in _ && n(3, i = _.$$scope);
  }, [a, s, o, i];
}
let Qs = class extends lf {
  constructor(t) {
    super(), hf(this, t, yf, qf, vf, { show_label: 0, info: 1 });
  }
};
const {
  SvelteComponent: t$,
  append: n$,
  attr: o$,
  create_component: i$,
  destroy_component: a$,
  detach: l$,
  element: s$,
  init: _$,
  insert: r$,
  mount_component: u$,
  safe_not_equal: f$,
  set_data: d$,
  space: c$,
  text: p$,
  toggle_class: m$,
  transition_in: h$,
  transition_out: $$
} = window.__gradio__svelte__internal, {
  SvelteComponent: v$,
  append: g$,
  attr: w$,
  bubble: b$,
  create_component: S$,
  destroy_component: C$,
  detach: q$,
  element: y$,
  init: k$,
  insert: E$,
  listen: T$,
  mount_component: B$,
  safe_not_equal: H$,
  set_data: A$,
  set_style: N$,
  space: P$,
  text: L$,
  toggle_class: I$,
  transition_in: M$,
  transition_out: O$
} = window.__gradio__svelte__internal, {
  SvelteComponent: D$,
  append: F$,
  attr: R$,
  binding_callbacks: U$,
  create_slot: G$,
  detach: j$,
  element: V$,
  get_all_dirty_from_scope: z$,
  get_slot_changes: X$,
  init: Z$,
  insert: W$,
  safe_not_equal: J$,
  toggle_class: Q$,
  transition_in: Y$,
  transition_out: K$,
  update_slot_base: x$
} = window.__gradio__svelte__internal, {
  SvelteComponent: ev,
  append: tv,
  attr: nv,
  detach: ov,
  init: iv,
  insert: av,
  noop: lv,
  safe_not_equal: sv,
  svg_element: _v
} = window.__gradio__svelte__internal, {
  SvelteComponent: rv,
  append: uv,
  attr: fv,
  detach: dv,
  init: cv,
  insert: pv,
  noop: mv,
  safe_not_equal: hv,
  svg_element: $v
} = window.__gradio__svelte__internal, {
  SvelteComponent: vv,
  append: gv,
  attr: wv,
  detach: bv,
  init: Sv,
  insert: Cv,
  noop: qv,
  safe_not_equal: yv,
  svg_element: kv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ev,
  append: Tv,
  attr: Bv,
  detach: Hv,
  init: Av,
  insert: Nv,
  noop: Pv,
  safe_not_equal: Lv,
  svg_element: Iv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Mv,
  append: Ov,
  attr: Dv,
  detach: Fv,
  init: Rv,
  insert: Uv,
  noop: Gv,
  safe_not_equal: jv,
  svg_element: Vv
} = window.__gradio__svelte__internal, {
  SvelteComponent: zv,
  append: Xv,
  attr: Zv,
  detach: Wv,
  init: Jv,
  insert: Qv,
  noop: Yv,
  safe_not_equal: Kv,
  svg_element: xv
} = window.__gradio__svelte__internal, {
  SvelteComponent: eg,
  append: tg,
  attr: ng,
  detach: og,
  init: ig,
  insert: ag,
  noop: lg,
  safe_not_equal: sg,
  svg_element: _g
} = window.__gradio__svelte__internal, {
  SvelteComponent: rg,
  append: ug,
  attr: fg,
  detach: dg,
  init: cg,
  insert: pg,
  noop: mg,
  safe_not_equal: hg,
  svg_element: $g
} = window.__gradio__svelte__internal, {
  SvelteComponent: vg,
  append: gg,
  attr: wg,
  detach: bg,
  init: Sg,
  insert: Cg,
  noop: qg,
  safe_not_equal: yg,
  set_style: kg,
  svg_element: Eg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Tg,
  append: Bg,
  attr: Hg,
  detach: Ag,
  init: Ng,
  insert: Pg,
  noop: Lg,
  safe_not_equal: Ig,
  svg_element: Mg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Og,
  append: Dg,
  attr: Fg,
  detach: Rg,
  init: Ug,
  insert: Gg,
  noop: jg,
  safe_not_equal: Vg,
  svg_element: zg
} = window.__gradio__svelte__internal, {
  SvelteComponent: Xg,
  append: Zg,
  attr: Wg,
  detach: Jg,
  init: Qg,
  insert: Yg,
  noop: Kg,
  safe_not_equal: xg,
  svg_element: e2
} = window.__gradio__svelte__internal, {
  SvelteComponent: t2,
  append: n2,
  attr: o2,
  detach: i2,
  init: a2,
  insert: l2,
  noop: s2,
  safe_not_equal: _2,
  svg_element: r2
} = window.__gradio__svelte__internal, {
  SvelteComponent: u2,
  append: f2,
  attr: d2,
  detach: c2,
  init: p2,
  insert: m2,
  noop: h2,
  safe_not_equal: $2,
  svg_element: v2
} = window.__gradio__svelte__internal, {
  SvelteComponent: g2,
  append: w2,
  attr: b2,
  detach: S2,
  init: C2,
  insert: q2,
  noop: y2,
  safe_not_equal: k2,
  svg_element: E2
} = window.__gradio__svelte__internal, {
  SvelteComponent: T2,
  append: B2,
  attr: H2,
  detach: A2,
  init: N2,
  insert: P2,
  noop: L2,
  safe_not_equal: I2,
  svg_element: M2
} = window.__gradio__svelte__internal, {
  SvelteComponent: kf,
  append: Ef,
  attr: Ct,
  detach: Tf,
  init: Bf,
  insert: Hf,
  noop: Lo,
  safe_not_equal: Af,
  svg_element: pa
} = window.__gradio__svelte__internal;
function Nf(e) {
  let t, n;
  return {
    c() {
      t = pa("svg"), n = pa("path"), Ct(n, "d", "M5 8l4 4 4-4z"), Ct(t, "class", "dropdown-arrow svelte-145leq6"), Ct(t, "xmlns", "http://www.w3.org/2000/svg"), Ct(t, "width", "100%"), Ct(t, "height", "100%"), Ct(t, "viewBox", "0 0 18 18");
    },
    m(o, i) {
      Hf(o, t, i), Ef(t, n);
    },
    p: Lo,
    i: Lo,
    o: Lo,
    d(o) {
      o && Tf(t);
    }
  };
}
class Ys extends kf {
  constructor(t) {
    super(), Bf(this, t, null, Nf, Af, {});
  }
}
const {
  SvelteComponent: O2,
  append: D2,
  attr: F2,
  detach: R2,
  init: U2,
  insert: G2,
  noop: j2,
  safe_not_equal: V2,
  svg_element: z2
} = window.__gradio__svelte__internal, {
  SvelteComponent: X2,
  append: Z2,
  attr: W2,
  detach: J2,
  init: Q2,
  insert: Y2,
  noop: K2,
  safe_not_equal: x2,
  svg_element: ew
} = window.__gradio__svelte__internal, {
  SvelteComponent: tw,
  append: nw,
  attr: ow,
  detach: iw,
  init: aw,
  insert: lw,
  noop: sw,
  safe_not_equal: _w,
  svg_element: rw
} = window.__gradio__svelte__internal, {
  SvelteComponent: uw,
  append: fw,
  attr: dw,
  detach: cw,
  init: pw,
  insert: mw,
  noop: hw,
  safe_not_equal: $w,
  svg_element: vw
} = window.__gradio__svelte__internal, {
  SvelteComponent: gw,
  append: ww,
  attr: bw,
  detach: Sw,
  init: Cw,
  insert: qw,
  noop: yw,
  safe_not_equal: kw,
  svg_element: Ew
} = window.__gradio__svelte__internal, {
  SvelteComponent: Tw,
  append: Bw,
  attr: Hw,
  detach: Aw,
  init: Nw,
  insert: Pw,
  noop: Lw,
  safe_not_equal: Iw,
  svg_element: Mw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ow,
  append: Dw,
  attr: Fw,
  detach: Rw,
  init: Uw,
  insert: Gw,
  noop: jw,
  safe_not_equal: Vw,
  svg_element: zw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Xw,
  append: Zw,
  attr: Ww,
  detach: Jw,
  init: Qw,
  insert: Yw,
  noop: Kw,
  safe_not_equal: xw,
  svg_element: eb
} = window.__gradio__svelte__internal, {
  SvelteComponent: tb,
  append: nb,
  attr: ob,
  detach: ib,
  init: ab,
  insert: lb,
  noop: sb,
  safe_not_equal: _b,
  svg_element: rb
} = window.__gradio__svelte__internal, {
  SvelteComponent: ub,
  append: fb,
  attr: db,
  detach: cb,
  init: pb,
  insert: mb,
  noop: hb,
  safe_not_equal: $b,
  svg_element: vb
} = window.__gradio__svelte__internal, {
  SvelteComponent: gb,
  append: wb,
  attr: bb,
  detach: Sb,
  init: Cb,
  insert: qb,
  noop: yb,
  safe_not_equal: kb,
  svg_element: Eb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Tb,
  append: Bb,
  attr: Hb,
  detach: Ab,
  init: Nb,
  insert: Pb,
  noop: Lb,
  safe_not_equal: Ib,
  svg_element: Mb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ob,
  append: Db,
  attr: Fb,
  detach: Rb,
  init: Ub,
  insert: Gb,
  noop: jb,
  safe_not_equal: Vb,
  svg_element: zb
} = window.__gradio__svelte__internal, {
  SvelteComponent: Xb,
  append: Zb,
  attr: Wb,
  detach: Jb,
  init: Qb,
  insert: Yb,
  noop: Kb,
  safe_not_equal: xb,
  svg_element: e4
} = window.__gradio__svelte__internal, {
  SvelteComponent: t4,
  append: n4,
  attr: o4,
  detach: i4,
  init: a4,
  insert: l4,
  noop: s4,
  safe_not_equal: _4,
  svg_element: r4
} = window.__gradio__svelte__internal, {
  SvelteComponent: u4,
  append: f4,
  attr: d4,
  detach: c4,
  init: p4,
  insert: m4,
  noop: h4,
  safe_not_equal: $4,
  svg_element: v4
} = window.__gradio__svelte__internal, {
  SvelteComponent: g4,
  append: w4,
  attr: b4,
  detach: S4,
  init: C4,
  insert: q4,
  noop: y4,
  safe_not_equal: k4,
  svg_element: E4
} = window.__gradio__svelte__internal, {
  SvelteComponent: T4,
  append: B4,
  attr: H4,
  detach: A4,
  init: N4,
  insert: P4,
  noop: L4,
  safe_not_equal: I4,
  svg_element: M4
} = window.__gradio__svelte__internal, {
  SvelteComponent: O4,
  append: D4,
  attr: F4,
  detach: R4,
  init: U4,
  insert: G4,
  noop: j4,
  safe_not_equal: V4,
  svg_element: z4
} = window.__gradio__svelte__internal, {
  SvelteComponent: X4,
  append: Z4,
  attr: W4,
  detach: J4,
  init: Q4,
  insert: Y4,
  noop: K4,
  safe_not_equal: x4,
  set_style: e3,
  svg_element: t3
} = window.__gradio__svelte__internal, {
  SvelteComponent: Pf,
  append: Lf,
  attr: Io,
  detach: If,
  init: Mf,
  insert: Of,
  noop: Mo,
  safe_not_equal: Df,
  svg_element: ma
} = window.__gradio__svelte__internal;
function Ff(e) {
  let t, n;
  return {
    c() {
      t = ma("svg"), n = ma("path"), Io(n, "d", "M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"), Io(t, "xmlns", "http://www.w3.org/2000/svg"), Io(t, "viewBox", "0 0 24 24");
    },
    m(o, i) {
      Of(o, t, i), Lf(t, n);
    },
    p: Mo,
    i: Mo,
    o: Mo,
    d(o) {
      o && If(t);
    }
  };
}
class Ks extends Pf {
  constructor(t) {
    super(), Mf(this, t, null, Ff, Df, {});
  }
}
const {
  SvelteComponent: n3,
  append: o3,
  attr: i3,
  detach: a3,
  init: l3,
  insert: s3,
  noop: _3,
  safe_not_equal: r3,
  svg_element: u3
} = window.__gradio__svelte__internal, {
  SvelteComponent: f3,
  append: d3,
  attr: c3,
  detach: p3,
  init: m3,
  insert: h3,
  noop: $3,
  safe_not_equal: v3,
  svg_element: g3
} = window.__gradio__svelte__internal, {
  SvelteComponent: w3,
  append: b3,
  attr: S3,
  detach: C3,
  init: q3,
  insert: y3,
  noop: k3,
  safe_not_equal: E3,
  svg_element: T3
} = window.__gradio__svelte__internal, {
  SvelteComponent: B3,
  append: H3,
  attr: A3,
  detach: N3,
  init: P3,
  insert: L3,
  noop: I3,
  safe_not_equal: M3,
  svg_element: O3
} = window.__gradio__svelte__internal, {
  SvelteComponent: D3,
  append: F3,
  attr: R3,
  detach: U3,
  init: G3,
  insert: j3,
  noop: V3,
  safe_not_equal: z3,
  svg_element: X3
} = window.__gradio__svelte__internal, {
  SvelteComponent: Z3,
  append: W3,
  attr: J3,
  detach: Q3,
  init: Y3,
  insert: K3,
  noop: x3,
  safe_not_equal: e5,
  svg_element: t5
} = window.__gradio__svelte__internal, {
  SvelteComponent: n5,
  append: o5,
  attr: i5,
  detach: a5,
  init: l5,
  insert: s5,
  noop: _5,
  safe_not_equal: r5,
  svg_element: u5
} = window.__gradio__svelte__internal, {
  SvelteComponent: f5,
  append: d5,
  attr: c5,
  detach: p5,
  init: m5,
  insert: h5,
  noop: $5,
  safe_not_equal: v5,
  svg_element: g5,
  text: w5
} = window.__gradio__svelte__internal, {
  SvelteComponent: b5,
  append: S5,
  attr: C5,
  detach: q5,
  init: y5,
  insert: k5,
  noop: E5,
  safe_not_equal: T5,
  svg_element: B5
} = window.__gradio__svelte__internal, {
  SvelteComponent: H5,
  append: A5,
  attr: N5,
  detach: P5,
  init: L5,
  insert: I5,
  noop: M5,
  safe_not_equal: O5,
  svg_element: D5
} = window.__gradio__svelte__internal, {
  SvelteComponent: F5,
  append: R5,
  attr: U5,
  detach: G5,
  init: j5,
  insert: V5,
  noop: z5,
  safe_not_equal: X5,
  svg_element: Z5
} = window.__gradio__svelte__internal, {
  SvelteComponent: W5,
  append: J5,
  attr: Q5,
  detach: Y5,
  init: K5,
  insert: x5,
  noop: eS,
  safe_not_equal: tS,
  svg_element: nS
} = window.__gradio__svelte__internal, {
  SvelteComponent: oS,
  append: iS,
  attr: aS,
  detach: lS,
  init: sS,
  insert: _S,
  noop: rS,
  safe_not_equal: uS,
  svg_element: fS
} = window.__gradio__svelte__internal, {
  SvelteComponent: dS,
  append: cS,
  attr: pS,
  detach: mS,
  init: hS,
  insert: $S,
  noop: vS,
  safe_not_equal: gS,
  svg_element: wS,
  text: bS
} = window.__gradio__svelte__internal, {
  SvelteComponent: SS,
  append: CS,
  attr: qS,
  detach: yS,
  init: kS,
  insert: ES,
  noop: TS,
  safe_not_equal: BS,
  svg_element: HS,
  text: AS
} = window.__gradio__svelte__internal, {
  SvelteComponent: NS,
  append: PS,
  attr: LS,
  detach: IS,
  init: MS,
  insert: OS,
  noop: DS,
  safe_not_equal: FS,
  svg_element: RS,
  text: US
} = window.__gradio__svelte__internal, {
  SvelteComponent: GS,
  append: jS,
  attr: VS,
  detach: zS,
  init: XS,
  insert: ZS,
  noop: WS,
  safe_not_equal: JS,
  svg_element: QS
} = window.__gradio__svelte__internal, {
  SvelteComponent: YS,
  append: KS,
  attr: xS,
  detach: eC,
  init: tC,
  insert: nC,
  noop: oC,
  safe_not_equal: iC,
  svg_element: aC
} = window.__gradio__svelte__internal, Rf = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], ha = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
Rf.reduce(
  (e, { color: t, primary: n, secondary: o }) => ({
    ...e,
    [t]: {
      primary: ha[t][n],
      secondary: ha[t][o]
    }
  }),
  {}
);
const {
  SvelteComponent: lC,
  create_component: sC,
  destroy_component: _C,
  init: rC,
  mount_component: uC,
  safe_not_equal: fC,
  transition_in: dC,
  transition_out: cC
} = window.__gradio__svelte__internal, { createEventDispatcher: pC } = window.__gradio__svelte__internal, {
  SvelteComponent: mC,
  append: hC,
  attr: $C,
  create_component: vC,
  destroy_component: gC,
  detach: wC,
  element: bC,
  init: SC,
  insert: CC,
  mount_component: qC,
  safe_not_equal: yC,
  set_data: kC,
  space: EC,
  text: TC,
  toggle_class: BC,
  transition_in: HC,
  transition_out: AC
} = window.__gradio__svelte__internal, {
  SvelteComponent: NC,
  attr: PC,
  create_slot: LC,
  detach: IC,
  element: MC,
  get_all_dirty_from_scope: OC,
  get_slot_changes: DC,
  init: FC,
  insert: RC,
  safe_not_equal: UC,
  toggle_class: GC,
  transition_in: jC,
  transition_out: VC,
  update_slot_base: zC
} = window.__gradio__svelte__internal, {
  SvelteComponent: XC,
  append: ZC,
  attr: WC,
  check_outros: JC,
  create_component: QC,
  destroy_component: YC,
  detach: KC,
  element: xC,
  empty: eq,
  group_outros: tq,
  init: nq,
  insert: oq,
  listen: iq,
  mount_component: aq,
  safe_not_equal: lq,
  space: sq,
  toggle_class: _q,
  transition_in: rq,
  transition_out: uq
} = window.__gradio__svelte__internal, {
  SvelteComponent: Uf,
  add_render_callback: xs,
  append: En,
  attr: pe,
  binding_callbacks: $a,
  check_outros: Gf,
  create_bidirectional_transition: va,
  destroy_each: jf,
  detach: _n,
  element: xn,
  empty: Vf,
  ensure_array_like: ga,
  group_outros: zf,
  init: Xf,
  insert: rn,
  listen: _i,
  prevent_default: Zf,
  run_all: Wf,
  safe_not_equal: Jf,
  set_data: Qf,
  set_style: et,
  space: ri,
  text: Yf,
  toggle_class: Ie,
  transition_in: Oo,
  transition_out: wa
} = window.__gradio__svelte__internal, { createEventDispatcher: Kf } = window.__gradio__svelte__internal;
function ba(e, t, n) {
  const o = e.slice();
  return o[24] = t[n], o;
}
function Sa(e) {
  let t, n, o, i, a, s = ga(
    /*filtered_indices*/
    e[1]
  ), _ = [];
  for (let l = 0; l < s.length; l += 1)
    _[l] = Ca(ba(e, s, l));
  return {
    c() {
      t = xn("ul");
      for (let l = 0; l < _.length; l += 1)
        _[l].c();
      pe(t, "class", "options svelte-yuohum"), pe(t, "role", "listbox"), et(
        t,
        "top",
        /*top*/
        e[9]
      ), et(
        t,
        "bottom",
        /*bottom*/
        e[10]
      ), et(t, "max-height", `calc(${/*max_height*/
      e[11]}px - var(--window-padding))`), et(
        t,
        "width",
        /*input_width*/
        e[8] + "px"
      );
    },
    m(l, r) {
      rn(l, t, r);
      for (let u = 0; u < _.length; u += 1)
        _[u] && _[u].m(t, null);
      e[21](t), o = !0, i || (a = _i(t, "mousedown", Zf(
        /*mousedown_handler*/
        e[20]
      )), i = !0);
    },
    p(l, r) {
      if (r & /*filtered_indices, choices, selected_indices, active_index*/
      51) {
        s = ga(
          /*filtered_indices*/
          l[1]
        );
        let u;
        for (u = 0; u < s.length; u += 1) {
          const f = ba(l, s, u);
          _[u] ? _[u].p(f, r) : (_[u] = Ca(f), _[u].c(), _[u].m(t, null));
        }
        for (; u < _.length; u += 1)
          _[u].d(1);
        _.length = s.length;
      }
      r & /*top*/
      512 && et(
        t,
        "top",
        /*top*/
        l[9]
      ), r & /*bottom*/
      1024 && et(
        t,
        "bottom",
        /*bottom*/
        l[10]
      ), r & /*max_height*/
      2048 && et(t, "max-height", `calc(${/*max_height*/
      l[11]}px - var(--window-padding))`), r & /*input_width*/
      256 && et(
        t,
        "width",
        /*input_width*/
        l[8] + "px"
      );
    },
    i(l) {
      o || (l && xs(() => {
        o && (n || (n = va(t, Ji, { duration: 200, y: 5 }, !0)), n.run(1));
      }), o = !0);
    },
    o(l) {
      l && (n || (n = va(t, Ji, { duration: 200, y: 5 }, !1)), n.run(0)), o = !1;
    },
    d(l) {
      l && _n(t), jf(_, l), e[21](null), l && n && n.end(), i = !1, a();
    }
  };
}
function Ca(e) {
  let t, n, o, i = (
    /*choices*/
    e[0][
      /*index*/
      e[24]
    ][0] + ""
  ), a, s, _, l, r;
  return {
    c() {
      t = xn("li"), n = xn("span"), n.textContent = "✓", o = ri(), a = Yf(i), s = ri(), pe(n, "class", "inner-item svelte-yuohum"), Ie(n, "hide", !/*selected_indices*/
      e[4].includes(
        /*index*/
        e[24]
      )), pe(t, "class", "item svelte-yuohum"), pe(t, "data-index", _ = /*index*/
      e[24]), pe(t, "aria-label", l = /*choices*/
      e[0][
        /*index*/
        e[24]
      ][0]), pe(t, "data-testid", "dropdown-option"), pe(t, "role", "option"), pe(t, "aria-selected", r = /*selected_indices*/
      e[4].includes(
        /*index*/
        e[24]
      )), Ie(
        t,
        "selected",
        /*selected_indices*/
        e[4].includes(
          /*index*/
          e[24]
        )
      ), Ie(
        t,
        "active",
        /*index*/
        e[24] === /*active_index*/
        e[5]
      ), Ie(
        t,
        "bg-gray-100",
        /*index*/
        e[24] === /*active_index*/
        e[5]
      ), Ie(
        t,
        "dark:bg-gray-600",
        /*index*/
        e[24] === /*active_index*/
        e[5]
      );
    },
    m(u, f) {
      rn(u, t, f), En(t, n), En(t, o), En(t, a), En(t, s);
    },
    p(u, f) {
      f & /*selected_indices, filtered_indices*/
      18 && Ie(n, "hide", !/*selected_indices*/
      u[4].includes(
        /*index*/
        u[24]
      )), f & /*choices, filtered_indices*/
      3 && i !== (i = /*choices*/
      u[0][
        /*index*/
        u[24]
      ][0] + "") && Qf(a, i), f & /*filtered_indices*/
      2 && _ !== (_ = /*index*/
      u[24]) && pe(t, "data-index", _), f & /*choices, filtered_indices*/
      3 && l !== (l = /*choices*/
      u[0][
        /*index*/
        u[24]
      ][0]) && pe(t, "aria-label", l), f & /*selected_indices, filtered_indices*/
      18 && r !== (r = /*selected_indices*/
      u[4].includes(
        /*index*/
        u[24]
      )) && pe(t, "aria-selected", r), f & /*selected_indices, filtered_indices*/
      18 && Ie(
        t,
        "selected",
        /*selected_indices*/
        u[4].includes(
          /*index*/
          u[24]
        )
      ), f & /*filtered_indices, active_index*/
      34 && Ie(
        t,
        "active",
        /*index*/
        u[24] === /*active_index*/
        u[5]
      ), f & /*filtered_indices, active_index*/
      34 && Ie(
        t,
        "bg-gray-100",
        /*index*/
        u[24] === /*active_index*/
        u[5]
      ), f & /*filtered_indices, active_index*/
      34 && Ie(
        t,
        "dark:bg-gray-600",
        /*index*/
        u[24] === /*active_index*/
        u[5]
      );
    },
    d(u) {
      u && _n(t);
    }
  };
}
function xf(e) {
  let t, n, o, i, a;
  xs(
    /*onwindowresize*/
    e[18]
  );
  let s = (
    /*show_options*/
    e[2] && !/*disabled*/
    e[3] && Sa(e)
  );
  return {
    c() {
      t = xn("div"), n = ri(), s && s.c(), o = Vf(), pe(t, "class", "reference");
    },
    m(_, l) {
      rn(_, t, l), e[19](t), rn(_, n, l), s && s.m(_, l), rn(_, o, l), i || (a = [
        _i(
          window,
          "scroll",
          /*scroll_listener*/
          e[13]
        ),
        _i(
          window,
          "resize",
          /*onwindowresize*/
          e[18]
        )
      ], i = !0);
    },
    p(_, [l]) {
      /*show_options*/
      _[2] && !/*disabled*/
      _[3] ? s ? (s.p(_, l), l & /*show_options, disabled*/
      12 && Oo(s, 1)) : (s = Sa(_), s.c(), Oo(s, 1), s.m(o.parentNode, o)) : s && (zf(), wa(s, 1, 1, () => {
        s = null;
      }), Gf());
    },
    i(_) {
      Oo(s);
    },
    o(_) {
      wa(s);
    },
    d(_) {
      _ && (_n(t), _n(n), _n(o)), e[19](null), s && s.d(_), i = !1, Wf(a);
    }
  };
}
function ed(e, t, n) {
  let { choices: o } = t, { filtered_indices: i } = t, { show_options: a = !1 } = t, { disabled: s = !1 } = t, { selected_indices: _ = [] } = t, { active_index: l = null } = t, r, u, f, d, c, m, w, b, v, g;
  function p() {
    const { top: E, bottom: Y } = c.getBoundingClientRect();
    n(15, r = E), n(16, u = g - Y);
  }
  let h = null;
  function S() {
    a && (h !== null && clearTimeout(h), h = setTimeout(
      () => {
        p(), h = null;
      },
      10
    ));
  }
  const $ = Kf();
  function y() {
    n(12, g = window.innerHeight);
  }
  function C(E) {
    $a[E ? "unshift" : "push"](() => {
      c = E, n(6, c);
    });
  }
  const T = (E) => $("change", E);
  function P(E) {
    $a[E ? "unshift" : "push"](() => {
      m = E, n(7, m);
    });
  }
  return e.$$set = (E) => {
    "choices" in E && n(0, o = E.choices), "filtered_indices" in E && n(1, i = E.filtered_indices), "show_options" in E && n(2, a = E.show_options), "disabled" in E && n(3, s = E.disabled), "selected_indices" in E && n(4, _ = E.selected_indices), "active_index" in E && n(5, l = E.active_index);
  }, e.$$.update = () => {
    var E, Y;
    if (e.$$.dirty & /*show_options, refElement, listElement, selected_indices, distance_from_bottom, distance_from_top, input_height*/
    229588) {
      if (a && c) {
        if (m && _.length > 0) {
          let Z = m.querySelectorAll("li");
          for (const U of Array.from(Z))
            if (U.getAttribute("data-index") === _[0].toString()) {
              (E = m == null ? void 0 : m.scrollTo) == null || E.call(m, 0, U.offsetTop);
              break;
            }
        }
        p();
        const R = (Y = c.parentElement) == null ? void 0 : Y.getBoundingClientRect();
        n(17, f = (R == null ? void 0 : R.height) || 0), n(8, d = (R == null ? void 0 : R.width) || 0);
      }
      u > r ? (n(9, w = `${r}px`), n(11, v = u), n(10, b = null)) : (n(10, b = `${u + f}px`), n(11, v = r - f), n(9, w = null));
    }
  }, [
    o,
    i,
    a,
    s,
    _,
    l,
    c,
    m,
    d,
    w,
    b,
    v,
    g,
    S,
    $,
    r,
    u,
    f,
    y,
    C,
    T,
    P
  ];
}
class e_ extends Uf {
  constructor(t) {
    super(), Xf(this, t, ed, xf, Jf, {
      choices: 0,
      filtered_indices: 1,
      show_options: 2,
      disabled: 3,
      selected_indices: 4,
      active_index: 5
    });
  }
}
function td(e, t) {
  return (e % t + t) % t;
}
function t_(e, t) {
  return e.reduce((n, o, i) => ((!t || o[0].toLowerCase().includes(t.toLowerCase())) && n.push(i), n), []);
}
function n_(e, t, n) {
  e("change", t), n || e("input");
}
function o_(e, t, n) {
  if (e.key === "Escape")
    return [!1, t];
  if ((e.key === "ArrowDown" || e.key === "ArrowUp") && n.length >= 0)
    if (t === null)
      t = e.key === "ArrowDown" ? n[0] : n[n.length - 1];
    else {
      const o = n.indexOf(t), i = e.key === "ArrowUp" ? -1 : 1;
      t = n[td(o + i, n.length)];
    }
  return [!0, t];
}
const {
  SvelteComponent: nd,
  append: Fe,
  attr: ie,
  binding_callbacks: od,
  check_outros: eo,
  create_component: $n,
  destroy_component: vn,
  destroy_each: id,
  detach: Ye,
  element: Re,
  ensure_array_like: qa,
  group_outros: to,
  init: ad,
  insert: Ke,
  listen: it,
  mount_component: gn,
  prevent_default: ya,
  run_all: Mi,
  safe_not_equal: ld,
  set_data: Oi,
  set_input_value: ka,
  space: Nt,
  text: Di,
  toggle_class: qt,
  transition_in: se,
  transition_out: me
} = window.__gradio__svelte__internal, { afterUpdate: sd, createEventDispatcher: _d } = window.__gradio__svelte__internal;
function Ea(e, t, n) {
  const o = e.slice();
  return o[39] = t[n], o;
}
function rd(e) {
  let t;
  return {
    c() {
      t = Di(
        /*label*/
        e[0]
      );
    },
    m(n, o) {
      Ke(n, t, o);
    },
    p(n, o) {
      o[0] & /*label*/
      1 && Oi(
        t,
        /*label*/
        n[0]
      );
    },
    d(n) {
      n && Ye(t);
    }
  };
}
function ud(e) {
  let t = (
    /*s*/
    e[39] + ""
  ), n;
  return {
    c() {
      n = Di(t);
    },
    m(o, i) {
      Ke(o, n, i);
    },
    p(o, i) {
      i[0] & /*selected_indices*/
      4096 && t !== (t = /*s*/
      o[39] + "") && Oi(n, t);
    },
    d(o) {
      o && Ye(n);
    }
  };
}
function fd(e) {
  let t = (
    /*choices_names*/
    e[15][
      /*s*/
      e[39]
    ] + ""
  ), n;
  return {
    c() {
      n = Di(t);
    },
    m(o, i) {
      Ke(o, n, i);
    },
    p(o, i) {
      i[0] & /*choices_names, selected_indices*/
      36864 && t !== (t = /*choices_names*/
      o[15][
        /*s*/
        o[39]
      ] + "") && Oi(n, t);
    },
    d(o) {
      o && Ye(n);
    }
  };
}
function Ta(e) {
  let t, n, o, i, a, s;
  n = new Ks({});
  function _() {
    return (
      /*click_handler*/
      e[30](
        /*s*/
        e[39]
      )
    );
  }
  function l(...r) {
    return (
      /*keydown_handler*/
      e[31](
        /*s*/
        e[39],
        ...r
      )
    );
  }
  return {
    c() {
      t = Re("div"), $n(n.$$.fragment), ie(t, "class", "token-remove svelte-1j674pc"), ie(t, "role", "button"), ie(t, "tabindex", "0"), ie(t, "title", o = /*i18n*/
      e[9]("common.remove") + " " + /*s*/
      e[39]);
    },
    m(r, u) {
      Ke(r, t, u), gn(n, t, null), i = !0, a || (s = [
        it(t, "click", ya(_)),
        it(t, "keydown", ya(l))
      ], a = !0);
    },
    p(r, u) {
      e = r, (!i || u[0] & /*i18n, selected_indices*/
      4608 && o !== (o = /*i18n*/
      e[9]("common.remove") + " " + /*s*/
      e[39])) && ie(t, "title", o);
    },
    i(r) {
      i || (se(n.$$.fragment, r), i = !0);
    },
    o(r) {
      me(n.$$.fragment, r), i = !1;
    },
    d(r) {
      r && Ye(t), vn(n), a = !1, Mi(s);
    }
  };
}
function Ba(e) {
  let t, n, o, i;
  function a(r, u) {
    return typeof /*s*/
    r[39] == "number" ? fd : ud;
  }
  let s = a(e), _ = s(e), l = !/*disabled*/
  e[4] && Ta(e);
  return {
    c() {
      t = Re("div"), n = Re("span"), _.c(), o = Nt(), l && l.c(), ie(n, "class", "svelte-1j674pc"), ie(t, "class", "token svelte-1j674pc");
    },
    m(r, u) {
      Ke(r, t, u), Fe(t, n), _.m(n, null), Fe(t, o), l && l.m(t, null), i = !0;
    },
    p(r, u) {
      s === (s = a(r)) && _ ? _.p(r, u) : (_.d(1), _ = s(r), _ && (_.c(), _.m(n, null))), /*disabled*/
      r[4] ? l && (to(), me(l, 1, 1, () => {
        l = null;
      }), eo()) : l ? (l.p(r, u), u[0] & /*disabled*/
      16 && se(l, 1)) : (l = Ta(r), l.c(), se(l, 1), l.m(t, null));
    },
    i(r) {
      i || (se(l), i = !0);
    },
    o(r) {
      me(l), i = !1;
    },
    d(r) {
      r && Ye(t), _.d(), l && l.d();
    }
  };
}
function Ha(e) {
  let t, n, o, i, a = (
    /*selected_indices*/
    e[12].length > 0 && Aa(e)
  );
  return o = new Ys({}), {
    c() {
      a && a.c(), t = Nt(), n = Re("span"), $n(o.$$.fragment), ie(n, "class", "icon-wrap svelte-1j674pc");
    },
    m(s, _) {
      a && a.m(s, _), Ke(s, t, _), Ke(s, n, _), gn(o, n, null), i = !0;
    },
    p(s, _) {
      /*selected_indices*/
      s[12].length > 0 ? a ? (a.p(s, _), _[0] & /*selected_indices*/
      4096 && se(a, 1)) : (a = Aa(s), a.c(), se(a, 1), a.m(t.parentNode, t)) : a && (to(), me(a, 1, 1, () => {
        a = null;
      }), eo());
    },
    i(s) {
      i || (se(a), se(o.$$.fragment, s), i = !0);
    },
    o(s) {
      me(a), me(o.$$.fragment, s), i = !1;
    },
    d(s) {
      s && (Ye(t), Ye(n)), a && a.d(s), vn(o);
    }
  };
}
function Aa(e) {
  let t, n, o, i, a, s;
  return n = new Ks({}), {
    c() {
      t = Re("div"), $n(n.$$.fragment), ie(t, "role", "button"), ie(t, "tabindex", "0"), ie(t, "class", "token-remove remove-all svelte-1j674pc"), ie(t, "title", o = /*i18n*/
      e[9]("common.clear"));
    },
    m(_, l) {
      Ke(_, t, l), gn(n, t, null), i = !0, a || (s = [
        it(
          t,
          "click",
          /*remove_all*/
          e[20]
        ),
        it(
          t,
          "keydown",
          /*keydown_handler_1*/
          e[34]
        )
      ], a = !0);
    },
    p(_, l) {
      (!i || l[0] & /*i18n*/
      512 && o !== (o = /*i18n*/
      _[9]("common.clear"))) && ie(t, "title", o);
    },
    i(_) {
      i || (se(n.$$.fragment, _), i = !0);
    },
    o(_) {
      me(n.$$.fragment, _), i = !1;
    },
    d(_) {
      _ && Ye(t), vn(n), a = !1, Mi(s);
    }
  };
}
function dd(e) {
  let t, n, o, i, a, s, _, l, r, u, f, d, c, m, w;
  n = new Qs({
    props: {
      show_label: (
        /*show_label*/
        e[5]
      ),
      info: (
        /*info*/
        e[1]
      ),
      $$slots: { default: [rd] },
      $$scope: { ctx: e }
    }
  });
  let b = qa(
    /*selected_indices*/
    e[12]
  ), v = [];
  for (let h = 0; h < b.length; h += 1)
    v[h] = Ba(Ea(e, b, h));
  const g = (h) => me(v[h], 1, 1, () => {
    v[h] = null;
  });
  let p = !/*disabled*/
  e[4] && Ha(e);
  return d = new e_({
    props: {
      show_options: (
        /*show_options*/
        e[14]
      ),
      choices: (
        /*choices*/
        e[3]
      ),
      filtered_indices: (
        /*filtered_indices*/
        e[11]
      ),
      disabled: (
        /*disabled*/
        e[4]
      ),
      selected_indices: (
        /*selected_indices*/
        e[12]
      ),
      active_index: (
        /*active_index*/
        e[16]
      )
    }
  }), d.$on(
    "change",
    /*handle_option_selected*/
    e[19]
  ), {
    c() {
      t = Re("label"), $n(n.$$.fragment), o = Nt(), i = Re("div"), a = Re("div");
      for (let h = 0; h < v.length; h += 1)
        v[h].c();
      s = Nt(), _ = Re("div"), l = Re("input"), u = Nt(), p && p.c(), f = Nt(), $n(d.$$.fragment), ie(l, "class", "border-none svelte-1j674pc"), l.disabled = /*disabled*/
      e[4], ie(l, "autocomplete", "off"), l.readOnly = r = !/*filterable*/
      e[8], qt(l, "subdued", !/*choices_names*/
      e[15].includes(
        /*input_text*/
        e[10]
      ) && !/*allow_custom_value*/
      e[7] || /*selected_indices*/
      e[12].length === /*max_choices*/
      e[2]), ie(_, "class", "secondary-wrap svelte-1j674pc"), ie(a, "class", "wrap-inner svelte-1j674pc"), qt(
        a,
        "show_options",
        /*show_options*/
        e[14]
      ), ie(i, "class", "wrap svelte-1j674pc"), ie(t, "class", "svelte-1j674pc"), qt(
        t,
        "container",
        /*container*/
        e[6]
      );
    },
    m(h, S) {
      Ke(h, t, S), gn(n, t, null), Fe(t, o), Fe(t, i), Fe(i, a);
      for (let $ = 0; $ < v.length; $ += 1)
        v[$] && v[$].m(a, null);
      Fe(a, s), Fe(a, _), Fe(_, l), ka(
        l,
        /*input_text*/
        e[10]
      ), e[33](l), Fe(_, u), p && p.m(_, null), Fe(i, f), gn(d, i, null), c = !0, m || (w = [
        it(
          l,
          "input",
          /*input_input_handler*/
          e[32]
        ),
        it(
          l,
          "keydown",
          /*handle_key_down*/
          e[22]
        ),
        it(
          l,
          "blur",
          /*handle_blur*/
          e[17]
        ),
        it(
          l,
          "focus",
          /*handle_focus*/
          e[21]
        )
      ], m = !0);
    },
    p(h, S) {
      const $ = {};
      if (S[0] & /*show_label*/
      32 && ($.show_label = /*show_label*/
      h[5]), S[0] & /*info*/
      2 && ($.info = /*info*/
      h[1]), S[0] & /*label*/
      1 | S[1] & /*$$scope*/
      2048 && ($.$$scope = { dirty: S, ctx: h }), n.$set($), S[0] & /*i18n, selected_indices, remove_selected_choice, disabled, choices_names*/
      299536) {
        b = qa(
          /*selected_indices*/
          h[12]
        );
        let C;
        for (C = 0; C < b.length; C += 1) {
          const T = Ea(h, b, C);
          v[C] ? (v[C].p(T, S), se(v[C], 1)) : (v[C] = Ba(T), v[C].c(), se(v[C], 1), v[C].m(a, s));
        }
        for (to(), C = b.length; C < v.length; C += 1)
          g(C);
        eo();
      }
      (!c || S[0] & /*disabled*/
      16) && (l.disabled = /*disabled*/
      h[4]), (!c || S[0] & /*filterable*/
      256 && r !== (r = !/*filterable*/
      h[8])) && (l.readOnly = r), S[0] & /*input_text*/
      1024 && l.value !== /*input_text*/
      h[10] && ka(
        l,
        /*input_text*/
        h[10]
      ), (!c || S[0] & /*choices_names, input_text, allow_custom_value, selected_indices, max_choices*/
      38020) && qt(l, "subdued", !/*choices_names*/
      h[15].includes(
        /*input_text*/
        h[10]
      ) && !/*allow_custom_value*/
      h[7] || /*selected_indices*/
      h[12].length === /*max_choices*/
      h[2]), /*disabled*/
      h[4] ? p && (to(), me(p, 1, 1, () => {
        p = null;
      }), eo()) : p ? (p.p(h, S), S[0] & /*disabled*/
      16 && se(p, 1)) : (p = Ha(h), p.c(), se(p, 1), p.m(_, null)), (!c || S[0] & /*show_options*/
      16384) && qt(
        a,
        "show_options",
        /*show_options*/
        h[14]
      );
      const y = {};
      S[0] & /*show_options*/
      16384 && (y.show_options = /*show_options*/
      h[14]), S[0] & /*choices*/
      8 && (y.choices = /*choices*/
      h[3]), S[0] & /*filtered_indices*/
      2048 && (y.filtered_indices = /*filtered_indices*/
      h[11]), S[0] & /*disabled*/
      16 && (y.disabled = /*disabled*/
      h[4]), S[0] & /*selected_indices*/
      4096 && (y.selected_indices = /*selected_indices*/
      h[12]), S[0] & /*active_index*/
      65536 && (y.active_index = /*active_index*/
      h[16]), d.$set(y), (!c || S[0] & /*container*/
      64) && qt(
        t,
        "container",
        /*container*/
        h[6]
      );
    },
    i(h) {
      if (!c) {
        se(n.$$.fragment, h);
        for (let S = 0; S < b.length; S += 1)
          se(v[S]);
        se(p), se(d.$$.fragment, h), c = !0;
      }
    },
    o(h) {
      me(n.$$.fragment, h), v = v.filter(Boolean);
      for (let S = 0; S < v.length; S += 1)
        me(v[S]);
      me(p), me(d.$$.fragment, h), c = !1;
    },
    d(h) {
      h && Ye(t), vn(n), id(v, h), e[33](null), p && p.d(), vn(d), m = !1, Mi(w);
    }
  };
}
function cd(e, t, n) {
  let { label: o } = t, { info: i = void 0 } = t, { value: a = [] } = t, s = [], { value_is_output: _ = !1 } = t, { max_choices: l = null } = t, { choices: r } = t, u, { disabled: f = !1 } = t, { show_label: d } = t, { container: c = !0 } = t, { allow_custom_value: m = !1 } = t, { filterable: w = !0 } = t, { i18n: b } = t, v, g = "", p = "", h = !1, S, $, y = [], C = null, T = [], P = [];
  const E = _d();
  Array.isArray(a) && a.forEach((k) => {
    const he = r.map((Eo) => Eo[1]).indexOf(k);
    he !== -1 ? T.push(he) : T.push(k);
  });
  function Y() {
    m || n(10, g = ""), m && g !== "" && (Z(g), n(10, g = "")), n(14, h = !1), n(16, C = null), E("blur");
  }
  function R(k) {
    n(12, T = T.filter((he) => he !== k)), E("select", {
      index: typeof k == "number" ? k : -1,
      value: typeof k == "number" ? $[k] : k,
      selected: !1
    });
  }
  function Z(k) {
    (l === null || T.length < l) && (n(12, T = [...T, k]), E("select", {
      index: typeof k == "number" ? k : -1,
      value: typeof k == "number" ? $[k] : k,
      selected: !0
    })), T.length === l && (n(14, h = !1), n(16, C = null), v.blur());
  }
  function U(k) {
    const he = parseInt(k.detail.target.dataset.index);
    H(he);
  }
  function H(k) {
    T.includes(k) ? R(k) : Z(k), n(10, g = "");
  }
  function Q(k) {
    n(12, T = []), n(10, g = ""), k.preventDefault();
  }
  function A(k) {
    n(11, y = r.map((he, Eo) => Eo)), (l === null || T.length < l) && n(14, h = !0), E("focus");
  }
  function ae(k) {
    n(14, [h, C] = o_(k, C, y), h, (n(16, C), n(3, r), n(26, u), n(10, g), n(27, p), n(7, m), n(11, y))), k.key === "Enter" && (C !== null ? H(C) : m && (Z(g), n(10, g = ""))), k.key === "Backspace" && g === "" && n(12, T = [...T.slice(0, -1)]), T.length === l && (n(14, h = !1), n(16, C = null));
  }
  function B() {
    a === void 0 ? n(12, T = []) : Array.isArray(a) && n(12, T = a.map((k) => {
      const he = $.indexOf(k);
      if (he !== -1)
        return he;
      if (m)
        return k;
    }).filter((k) => k !== void 0));
  }
  sd(() => {
    n(24, _ = !1);
  });
  const Le = (k) => R(k), _t = (k, he) => {
    he.key === "Enter" && R(k);
  };
  function q() {
    g = this.value, n(10, g);
  }
  function ko(k) {
    od[k ? "unshift" : "push"](() => {
      v = k, n(13, v);
    });
  }
  const N = (k) => {
    k.key === "Enter" && Q(k);
  };
  return e.$$set = (k) => {
    "label" in k && n(0, o = k.label), "info" in k && n(1, i = k.info), "value" in k && n(23, a = k.value), "value_is_output" in k && n(24, _ = k.value_is_output), "max_choices" in k && n(2, l = k.max_choices), "choices" in k && n(3, r = k.choices), "disabled" in k && n(4, f = k.disabled), "show_label" in k && n(5, d = k.show_label), "container" in k && n(6, c = k.container), "allow_custom_value" in k && n(7, m = k.allow_custom_value), "filterable" in k && n(8, w = k.filterable), "i18n" in k && n(9, b = k.i18n);
  }, e.$$.update = () => {
    e.$$.dirty[0] & /*choices*/
    8 && (n(15, S = r.map((k) => k[0])), n(28, $ = r.map((k) => k[1]))), e.$$.dirty[0] & /*choices, old_choices, input_text, old_input_text, allow_custom_value, filtered_indices*/
    201329800 && (r !== u || g !== p) && (n(11, y = t_(r, g)), n(26, u = r), n(27, p = g), m || n(16, C = y[0])), e.$$.dirty[0] & /*selected_indices, old_selected_index, choices_values*/
    805310464 && JSON.stringify(T) != JSON.stringify(P) && (n(23, a = T.map((k) => typeof k == "number" ? $[k] : k)), n(29, P = T.slice())), e.$$.dirty[0] & /*value, old_value, value_is_output*/
    58720256 && JSON.stringify(a) != JSON.stringify(s) && (n_(E, a, _), n(25, s = Array.isArray(a) ? a.slice() : a)), e.$$.dirty[0] & /*value*/
    8388608 && B();
  }, [
    o,
    i,
    l,
    r,
    f,
    d,
    c,
    m,
    w,
    b,
    g,
    y,
    T,
    v,
    h,
    S,
    C,
    Y,
    R,
    U,
    Q,
    A,
    ae,
    a,
    _,
    s,
    u,
    p,
    $,
    P,
    Le,
    _t,
    q,
    ko,
    N
  ];
}
class pd extends nd {
  constructor(t) {
    super(), ad(
      this,
      t,
      cd,
      dd,
      ld,
      {
        label: 0,
        info: 1,
        value: 23,
        value_is_output: 24,
        max_choices: 2,
        choices: 3,
        disabled: 4,
        show_label: 5,
        container: 6,
        allow_custom_value: 7,
        filterable: 8,
        i18n: 9
      },
      null,
      [-1, -1]
    );
  }
}
const {
  SvelteComponent: md,
  append: rt,
  attr: dt,
  binding_callbacks: hd,
  check_outros: $d,
  create_component: ui,
  destroy_component: fi,
  detach: Fi,
  element: Ht,
  group_outros: vd,
  init: gd,
  insert: Ri,
  listen: Tn,
  mount_component: di,
  run_all: wd,
  safe_not_equal: bd,
  set_data: Sd,
  set_input_value: Na,
  space: Do,
  text: Cd,
  toggle_class: yt,
  transition_in: At,
  transition_out: ln
} = window.__gradio__svelte__internal, { createEventDispatcher: qd, afterUpdate: yd } = window.__gradio__svelte__internal;
function kd(e) {
  let t;
  return {
    c() {
      t = Cd(
        /*label*/
        e[0]
      );
    },
    m(n, o) {
      Ri(n, t, o);
    },
    p(n, o) {
      o[0] & /*label*/
      1 && Sd(
        t,
        /*label*/
        n[0]
      );
    },
    d(n) {
      n && Fi(t);
    }
  };
}
function Pa(e) {
  let t, n, o;
  return n = new Ys({}), {
    c() {
      t = Ht("div"), ui(n.$$.fragment), dt(t, "class", "icon-wrap svelte-etqaop");
    },
    m(i, a) {
      Ri(i, t, a), di(n, t, null), o = !0;
    },
    i(i) {
      o || (At(n.$$.fragment, i), o = !0);
    },
    o(i) {
      ln(n.$$.fragment, i), o = !1;
    },
    d(i) {
      i && Fi(t), fi(n);
    }
  };
}
function Ed(e) {
  let t, n, o, i, a, s, _, l, r, u, f, d, c, m;
  n = new Qs({
    props: {
      show_label: (
        /*show_label*/
        e[4]
      ),
      info: (
        /*info*/
        e[1]
      ),
      $$slots: { default: [kd] },
      $$scope: { ctx: e }
    }
  });
  let w = !/*disabled*/
  e[3] && Pa();
  return f = new e_({
    props: {
      show_options: (
        /*show_options*/
        e[12]
      ),
      choices: (
        /*choices*/
        e[2]
      ),
      filtered_indices: (
        /*filtered_indices*/
        e[9]
      ),
      disabled: (
        /*disabled*/
        e[3]
      ),
      selected_indices: (
        /*selected_index*/
        e[10] === null ? [] : [
          /*selected_index*/
          e[10]
        ]
      ),
      active_index: (
        /*active_index*/
        e[14]
      )
    }
  }), f.$on(
    "change",
    /*handle_option_selected*/
    e[15]
  ), {
    c() {
      t = Ht("label"), ui(n.$$.fragment), o = Do(), i = Ht("div"), a = Ht("div"), s = Ht("div"), _ = Ht("input"), r = Do(), w && w.c(), u = Do(), ui(f.$$.fragment), dt(_, "class", "border-none svelte-etqaop"), _.disabled = /*disabled*/
      e[3], dt(_, "autocomplete", "off"), _.readOnly = l = !/*filterable*/
      e[7], yt(_, "subdued", !/*choices_names*/
      e[13].includes(
        /*input_text*/
        e[8]
      ) && !/*allow_custom_value*/
      e[6]), dt(s, "class", "secondary-wrap svelte-etqaop"), dt(a, "class", "wrap-inner svelte-etqaop"), yt(
        a,
        "show_options",
        /*show_options*/
        e[12]
      ), dt(i, "class", "wrap svelte-etqaop"), dt(t, "class", "svelte-etqaop"), yt(
        t,
        "container",
        /*container*/
        e[5]
      );
    },
    m(b, v) {
      Ri(b, t, v), di(n, t, null), rt(t, o), rt(t, i), rt(i, a), rt(a, s), rt(s, _), Na(
        _,
        /*input_text*/
        e[8]
      ), e[28](_), rt(s, r), w && w.m(s, null), rt(i, u), di(f, i, null), d = !0, c || (m = [
        Tn(
          _,
          "input",
          /*input_input_handler*/
          e[27]
        ),
        Tn(
          _,
          "keydown",
          /*handle_key_down*/
          e[18]
        ),
        Tn(
          _,
          "blur",
          /*handle_blur*/
          e[17]
        ),
        Tn(
          _,
          "focus",
          /*handle_focus*/
          e[16]
        )
      ], c = !0);
    },
    p(b, v) {
      const g = {};
      v[0] & /*show_label*/
      16 && (g.show_label = /*show_label*/
      b[4]), v[0] & /*info*/
      2 && (g.info = /*info*/
      b[1]), v[0] & /*label*/
      1 | v[1] & /*$$scope*/
      1 && (g.$$scope = { dirty: v, ctx: b }), n.$set(g), (!d || v[0] & /*disabled*/
      8) && (_.disabled = /*disabled*/
      b[3]), (!d || v[0] & /*filterable*/
      128 && l !== (l = !/*filterable*/
      b[7])) && (_.readOnly = l), v[0] & /*input_text*/
      256 && _.value !== /*input_text*/
      b[8] && Na(
        _,
        /*input_text*/
        b[8]
      ), (!d || v[0] & /*choices_names, input_text, allow_custom_value*/
      8512) && yt(_, "subdued", !/*choices_names*/
      b[13].includes(
        /*input_text*/
        b[8]
      ) && !/*allow_custom_value*/
      b[6]), /*disabled*/
      b[3] ? w && (vd(), ln(w, 1, 1, () => {
        w = null;
      }), $d()) : w ? v[0] & /*disabled*/
      8 && At(w, 1) : (w = Pa(), w.c(), At(w, 1), w.m(s, null)), (!d || v[0] & /*show_options*/
      4096) && yt(
        a,
        "show_options",
        /*show_options*/
        b[12]
      );
      const p = {};
      v[0] & /*show_options*/
      4096 && (p.show_options = /*show_options*/
      b[12]), v[0] & /*choices*/
      4 && (p.choices = /*choices*/
      b[2]), v[0] & /*filtered_indices*/
      512 && (p.filtered_indices = /*filtered_indices*/
      b[9]), v[0] & /*disabled*/
      8 && (p.disabled = /*disabled*/
      b[3]), v[0] & /*selected_index*/
      1024 && (p.selected_indices = /*selected_index*/
      b[10] === null ? [] : [
        /*selected_index*/
        b[10]
      ]), v[0] & /*active_index*/
      16384 && (p.active_index = /*active_index*/
      b[14]), f.$set(p), (!d || v[0] & /*container*/
      32) && yt(
        t,
        "container",
        /*container*/
        b[5]
      );
    },
    i(b) {
      d || (At(n.$$.fragment, b), At(w), At(f.$$.fragment, b), d = !0);
    },
    o(b) {
      ln(n.$$.fragment, b), ln(w), ln(f.$$.fragment, b), d = !1;
    },
    d(b) {
      b && Fi(t), fi(n), e[28](null), w && w.d(), fi(f), c = !1, wd(m);
    }
  };
}
function Td(e, t, n) {
  let { label: o } = t, { info: i = void 0 } = t, { value: a = [] } = t, s = [], { value_is_output: _ = !1 } = t, { choices: l } = t, r, { disabled: u = !1 } = t, { show_label: f } = t, { container: d = !0 } = t, { allow_custom_value: c = !1 } = t, { filterable: m = !0 } = t, w, b = !1, v, g, p = "", h = "", S = !1, $ = [], y = null, C = null, T;
  const P = qd();
  a ? (T = l.map((A) => A[1]).indexOf(a), C = T, C === -1 ? (s = a, C = null) : ([p, s] = l[C], h = p)) : l.length > 0 && (T = 0, C = 0, [p, a] = l[C], s = a, h = p);
  function E() {
    a === void 0 ? (n(8, p = ""), n(10, C = null)) : g.includes(a) ? (n(8, p = v[g.indexOf(a)]), n(10, C = g.indexOf(a))) : c ? (n(8, p = a), n(10, C = null)) : (n(8, p = ""), n(10, C = null)), n(26, T = C);
  }
  function Y(A) {
    if (n(10, C = parseInt(A.detail.target.dataset.index)), isNaN(C)) {
      n(10, C = null);
      return;
    }
    n(12, b = !1), n(14, y = null), w.blur();
  }
  function R(A) {
    n(9, $ = l.map((ae, B) => B)), n(12, b = !0), P("focus");
  }
  function Z() {
    c || n(8, p = v[g.indexOf(a)]), n(19, a = p), n(12, b = !1), n(14, y = null), P("blur");
  }
  function U(A) {
    n(12, [b, y] = o_(A, y, $), b, (n(14, y), n(2, l), n(22, r), n(8, p), n(24, h), n(6, c), n(9, $), n(10, C), n(26, T), n(25, S), n(23, g))), A.key === "Enter" && (y !== null ? (n(10, C = y), n(12, b = !1), w.blur(), n(14, y = null)) : v.includes(p) ? (n(10, C = v.indexOf(p)), n(12, b = !1), n(14, y = null), w.blur()) : c && (n(19, a = p), n(10, C = null), n(12, b = !1), n(14, y = null), w.blur()));
  }
  yd(() => {
    n(20, _ = !1), n(25, S = !0);
  });
  function H() {
    p = this.value, n(8, p), n(10, C), n(26, T), n(25, S), n(2, l), n(23, g);
  }
  function Q(A) {
    hd[A ? "unshift" : "push"](() => {
      w = A, n(11, w);
    });
  }
  return e.$$set = (A) => {
    "label" in A && n(0, o = A.label), "info" in A && n(1, i = A.info), "value" in A && n(19, a = A.value), "value_is_output" in A && n(20, _ = A.value_is_output), "choices" in A && n(2, l = A.choices), "disabled" in A && n(3, u = A.disabled), "show_label" in A && n(4, f = A.show_label), "container" in A && n(5, d = A.container), "allow_custom_value" in A && n(6, c = A.allow_custom_value), "filterable" in A && n(7, m = A.filterable);
  }, e.$$.update = () => {
    e.$$.dirty[0] & /*choices*/
    4 && (n(13, v = l.map((A) => A[0])), n(23, g = l.map((A) => A[1]))), e.$$.dirty[0] & /*selected_index, old_selected_index, initialized, choices, choices_values*/
    109052932 && C !== T && C !== null && S && (n(8, [p, a] = l[C], p, (n(19, a), n(10, C), n(26, T), n(25, S), n(2, l), n(23, g))), n(26, T = C), P("select", {
      index: C,
      value: g[C],
      selected: !0
    })), e.$$.dirty[0] & /*value, old_value, value_is_output*/
    3670016 && a != s && (E(), n_(P, a, _), n(21, s = a)), e.$$.dirty[0] & /*choices, old_choices, input_text, old_input_text, allow_custom_value, filtered_indices*/
    20972356 && (l !== r || p !== h) && (n(9, $ = t_(l, p)), n(22, r = l), n(24, h = p), !c && $.length > 0 && n(14, y = $[0]));
  }, [
    o,
    i,
    l,
    u,
    f,
    d,
    c,
    m,
    p,
    $,
    C,
    w,
    b,
    v,
    y,
    Y,
    R,
    Z,
    U,
    a,
    _,
    s,
    r,
    g,
    h,
    S,
    T,
    H,
    Q
  ];
}
class Bd extends md {
  constructor(t) {
    super(), gd(
      this,
      t,
      Td,
      Ed,
      bd,
      {
        label: 0,
        info: 1,
        value: 19,
        value_is_output: 20,
        choices: 2,
        disabled: 3,
        show_label: 4,
        container: 5,
        allow_custom_value: 6,
        filterable: 7
      },
      null,
      [-1, -1]
    );
  }
}
function Pt(e) {
  let t = ["", "k", "M", "G", "T", "P", "E", "Z"], n = 0;
  for (; e > 1e3 && n < t.length - 1; )
    e /= 1e3, n++;
  let o = t[n];
  return (Number.isInteger(e) ? e : e.toFixed(1)) + o;
}
const {
  SvelteComponent: Hd,
  append: qe,
  attr: V,
  component_subscribe: La,
  detach: Ad,
  element: Nd,
  init: Pd,
  insert: Ld,
  noop: Ia,
  safe_not_equal: Id,
  set_style: Bn,
  svg_element: ye,
  toggle_class: Ma
} = window.__gradio__svelte__internal, { onMount: Md } = window.__gradio__svelte__internal;
function Od(e) {
  let t, n, o, i, a, s, _, l, r, u, f, d;
  return {
    c() {
      t = Nd("div"), n = ye("svg"), o = ye("g"), i = ye("path"), a = ye("path"), s = ye("path"), _ = ye("path"), l = ye("g"), r = ye("path"), u = ye("path"), f = ye("path"), d = ye("path"), V(i, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), V(i, "fill", "#FF7C00"), V(i, "fill-opacity", "0.4"), V(i, "class", "svelte-43sxxs"), V(a, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), V(a, "fill", "#FF7C00"), V(a, "class", "svelte-43sxxs"), V(s, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), V(s, "fill", "#FF7C00"), V(s, "fill-opacity", "0.4"), V(s, "class", "svelte-43sxxs"), V(_, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), V(_, "fill", "#FF7C00"), V(_, "class", "svelte-43sxxs"), Bn(o, "transform", "translate(" + /*$top*/
      e[1][0] + "px, " + /*$top*/
      e[1][1] + "px)"), V(r, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), V(r, "fill", "#FF7C00"), V(r, "fill-opacity", "0.4"), V(r, "class", "svelte-43sxxs"), V(u, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), V(u, "fill", "#FF7C00"), V(u, "class", "svelte-43sxxs"), V(f, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), V(f, "fill", "#FF7C00"), V(f, "fill-opacity", "0.4"), V(f, "class", "svelte-43sxxs"), V(d, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), V(d, "fill", "#FF7C00"), V(d, "class", "svelte-43sxxs"), Bn(l, "transform", "translate(" + /*$bottom*/
      e[2][0] + "px, " + /*$bottom*/
      e[2][1] + "px)"), V(n, "viewBox", "-1200 -1200 3000 3000"), V(n, "fill", "none"), V(n, "xmlns", "http://www.w3.org/2000/svg"), V(n, "class", "svelte-43sxxs"), V(t, "class", "svelte-43sxxs"), Ma(
        t,
        "margin",
        /*margin*/
        e[0]
      );
    },
    m(c, m) {
      Ld(c, t, m), qe(t, n), qe(n, o), qe(o, i), qe(o, a), qe(o, s), qe(o, _), qe(n, l), qe(l, r), qe(l, u), qe(l, f), qe(l, d);
    },
    p(c, [m]) {
      m & /*$top*/
      2 && Bn(o, "transform", "translate(" + /*$top*/
      c[1][0] + "px, " + /*$top*/
      c[1][1] + "px)"), m & /*$bottom*/
      4 && Bn(l, "transform", "translate(" + /*$bottom*/
      c[2][0] + "px, " + /*$bottom*/
      c[2][1] + "px)"), m & /*margin*/
      1 && Ma(
        t,
        "margin",
        /*margin*/
        c[0]
      );
    },
    i: Ia,
    o: Ia,
    d(c) {
      c && Ad(t);
    }
  };
}
function Dd(e, t, n) {
  let o, i, { margin: a = !0 } = t;
  const s = Ut([0, 0]);
  La(e, s, (d) => n(1, o = d));
  const _ = Ut([0, 0]);
  La(e, _, (d) => n(2, i = d));
  let l;
  async function r() {
    await Promise.all([s.set([125, 140]), _.set([-125, -140])]), await Promise.all([s.set([-125, 140]), _.set([125, -140])]), await Promise.all([s.set([-125, 0]), _.set([125, -0])]), await Promise.all([s.set([125, 0]), _.set([-125, 0])]);
  }
  async function u() {
    await r(), l || u();
  }
  async function f() {
    await Promise.all([s.set([125, 0]), _.set([-125, 0])]), u();
  }
  return Md(() => (f(), () => l = !0)), e.$$set = (d) => {
    "margin" in d && n(0, a = d.margin);
  }, [a, o, i, s, _];
}
let Fd = class extends Hd {
  constructor(t) {
    super(), Pd(this, t, Dd, Od, Id, { margin: 0 });
  }
};
const {
  SvelteComponent: Rd,
  append: mt,
  attr: Ue,
  binding_callbacks: Oa,
  check_outros: i_,
  create_component: Ud,
  create_slot: Gd,
  destroy_component: jd,
  destroy_each: a_,
  detach: M,
  element: Je,
  empty: Kt,
  ensure_array_like: no,
  get_all_dirty_from_scope: Vd,
  get_slot_changes: zd,
  group_outros: l_,
  init: Xd,
  insert: O,
  mount_component: Zd,
  noop: ci,
  safe_not_equal: Wd,
  set_data: be,
  set_style: at,
  space: Ge,
  text: x,
  toggle_class: $e,
  transition_in: Xt,
  transition_out: Zt,
  update_slot_base: Jd
} = window.__gradio__svelte__internal, { tick: Qd } = window.__gradio__svelte__internal, { onDestroy: Yd } = window.__gradio__svelte__internal, Kd = (e) => ({}), Da = (e) => ({});
function Fa(e, t, n) {
  const o = e.slice();
  return o[38] = t[n], o[40] = n, o;
}
function Ra(e, t, n) {
  const o = e.slice();
  return o[38] = t[n], o;
}
function xd(e) {
  let t, n = (
    /*i18n*/
    e[1]("common.error") + ""
  ), o, i, a;
  const s = (
    /*#slots*/
    e[29].error
  ), _ = Gd(
    s,
    e,
    /*$$scope*/
    e[28],
    Da
  );
  return {
    c() {
      t = Je("span"), o = x(n), i = Ge(), _ && _.c(), Ue(t, "class", "error svelte-1yserjw");
    },
    m(l, r) {
      O(l, t, r), mt(t, o), O(l, i, r), _ && _.m(l, r), a = !0;
    },
    p(l, r) {
      (!a || r[0] & /*i18n*/
      2) && n !== (n = /*i18n*/
      l[1]("common.error") + "") && be(o, n), _ && _.p && (!a || r[0] & /*$$scope*/
      268435456) && Jd(
        _,
        s,
        l,
        /*$$scope*/
        l[28],
        a ? zd(
          s,
          /*$$scope*/
          l[28],
          r,
          Kd
        ) : Vd(
          /*$$scope*/
          l[28]
        ),
        Da
      );
    },
    i(l) {
      a || (Xt(_, l), a = !0);
    },
    o(l) {
      Zt(_, l), a = !1;
    },
    d(l) {
      l && (M(t), M(i)), _ && _.d(l);
    }
  };
}
function ec(e) {
  let t, n, o, i, a, s, _, l, r, u = (
    /*variant*/
    e[8] === "default" && /*show_eta_bar*/
    e[18] && /*show_progress*/
    e[6] === "full" && Ua(e)
  );
  function f(p, h) {
    if (
      /*progress*/
      p[7]
    ) return oc;
    if (
      /*queue_position*/
      p[2] !== null && /*queue_size*/
      p[3] !== void 0 && /*queue_position*/
      p[2] >= 0
    ) return nc;
    if (
      /*queue_position*/
      p[2] === 0
    ) return tc;
  }
  let d = f(e), c = d && d(e), m = (
    /*timer*/
    e[5] && Va(e)
  );
  const w = [sc, lc], b = [];
  function v(p, h) {
    return (
      /*last_progress_level*/
      p[15] != null ? 0 : (
        /*show_progress*/
        p[6] === "full" ? 1 : -1
      )
    );
  }
  ~(a = v(e)) && (s = b[a] = w[a](e));
  let g = !/*timer*/
  e[5] && Ya(e);
  return {
    c() {
      u && u.c(), t = Ge(), n = Je("div"), c && c.c(), o = Ge(), m && m.c(), i = Ge(), s && s.c(), _ = Ge(), g && g.c(), l = Kt(), Ue(n, "class", "progress-text svelte-1yserjw"), $e(
        n,
        "meta-text-center",
        /*variant*/
        e[8] === "center"
      ), $e(
        n,
        "meta-text",
        /*variant*/
        e[8] === "default"
      );
    },
    m(p, h) {
      u && u.m(p, h), O(p, t, h), O(p, n, h), c && c.m(n, null), mt(n, o), m && m.m(n, null), O(p, i, h), ~a && b[a].m(p, h), O(p, _, h), g && g.m(p, h), O(p, l, h), r = !0;
    },
    p(p, h) {
      /*variant*/
      p[8] === "default" && /*show_eta_bar*/
      p[18] && /*show_progress*/
      p[6] === "full" ? u ? u.p(p, h) : (u = Ua(p), u.c(), u.m(t.parentNode, t)) : u && (u.d(1), u = null), d === (d = f(p)) && c ? c.p(p, h) : (c && c.d(1), c = d && d(p), c && (c.c(), c.m(n, o))), /*timer*/
      p[5] ? m ? m.p(p, h) : (m = Va(p), m.c(), m.m(n, null)) : m && (m.d(1), m = null), (!r || h[0] & /*variant*/
      256) && $e(
        n,
        "meta-text-center",
        /*variant*/
        p[8] === "center"
      ), (!r || h[0] & /*variant*/
      256) && $e(
        n,
        "meta-text",
        /*variant*/
        p[8] === "default"
      );
      let S = a;
      a = v(p), a === S ? ~a && b[a].p(p, h) : (s && (l_(), Zt(b[S], 1, 1, () => {
        b[S] = null;
      }), i_()), ~a ? (s = b[a], s ? s.p(p, h) : (s = b[a] = w[a](p), s.c()), Xt(s, 1), s.m(_.parentNode, _)) : s = null), /*timer*/
      p[5] ? g && (g.d(1), g = null) : g ? g.p(p, h) : (g = Ya(p), g.c(), g.m(l.parentNode, l));
    },
    i(p) {
      r || (Xt(s), r = !0);
    },
    o(p) {
      Zt(s), r = !1;
    },
    d(p) {
      p && (M(t), M(n), M(i), M(_), M(l)), u && u.d(p), c && c.d(), m && m.d(), ~a && b[a].d(p), g && g.d(p);
    }
  };
}
function Ua(e) {
  let t, n = `translateX(${/*eta_level*/
  (e[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      t = Je("div"), Ue(t, "class", "eta-bar svelte-1yserjw"), at(t, "transform", n);
    },
    m(o, i) {
      O(o, t, i);
    },
    p(o, i) {
      i[0] & /*eta_level*/
      131072 && n !== (n = `translateX(${/*eta_level*/
      (o[17] || 0) * 100 - 100}%)`) && at(t, "transform", n);
    },
    d(o) {
      o && M(t);
    }
  };
}
function tc(e) {
  let t;
  return {
    c() {
      t = x("processing |");
    },
    m(n, o) {
      O(n, t, o);
    },
    p: ci,
    d(n) {
      n && M(t);
    }
  };
}
function nc(e) {
  let t, n = (
    /*queue_position*/
    e[2] + 1 + ""
  ), o, i, a, s;
  return {
    c() {
      t = x("queue: "), o = x(n), i = x("/"), a = x(
        /*queue_size*/
        e[3]
      ), s = x(" |");
    },
    m(_, l) {
      O(_, t, l), O(_, o, l), O(_, i, l), O(_, a, l), O(_, s, l);
    },
    p(_, l) {
      l[0] & /*queue_position*/
      4 && n !== (n = /*queue_position*/
      _[2] + 1 + "") && be(o, n), l[0] & /*queue_size*/
      8 && be(
        a,
        /*queue_size*/
        _[3]
      );
    },
    d(_) {
      _ && (M(t), M(o), M(i), M(a), M(s));
    }
  };
}
function oc(e) {
  let t, n = no(
    /*progress*/
    e[7]
  ), o = [];
  for (let i = 0; i < n.length; i += 1)
    o[i] = ja(Ra(e, n, i));
  return {
    c() {
      for (let i = 0; i < o.length; i += 1)
        o[i].c();
      t = Kt();
    },
    m(i, a) {
      for (let s = 0; s < o.length; s += 1)
        o[s] && o[s].m(i, a);
      O(i, t, a);
    },
    p(i, a) {
      if (a[0] & /*progress*/
      128) {
        n = no(
          /*progress*/
          i[7]
        );
        let s;
        for (s = 0; s < n.length; s += 1) {
          const _ = Ra(i, n, s);
          o[s] ? o[s].p(_, a) : (o[s] = ja(_), o[s].c(), o[s].m(t.parentNode, t));
        }
        for (; s < o.length; s += 1)
          o[s].d(1);
        o.length = n.length;
      }
    },
    d(i) {
      i && M(t), a_(o, i);
    }
  };
}
function Ga(e) {
  let t, n = (
    /*p*/
    e[38].unit + ""
  ), o, i, a = " ", s;
  function _(u, f) {
    return (
      /*p*/
      u[38].length != null ? ac : ic
    );
  }
  let l = _(e), r = l(e);
  return {
    c() {
      r.c(), t = Ge(), o = x(n), i = x(" | "), s = x(a);
    },
    m(u, f) {
      r.m(u, f), O(u, t, f), O(u, o, f), O(u, i, f), O(u, s, f);
    },
    p(u, f) {
      l === (l = _(u)) && r ? r.p(u, f) : (r.d(1), r = l(u), r && (r.c(), r.m(t.parentNode, t))), f[0] & /*progress*/
      128 && n !== (n = /*p*/
      u[38].unit + "") && be(o, n);
    },
    d(u) {
      u && (M(t), M(o), M(i), M(s)), r.d(u);
    }
  };
}
function ic(e) {
  let t = Pt(
    /*p*/
    e[38].index || 0
  ) + "", n;
  return {
    c() {
      n = x(t);
    },
    m(o, i) {
      O(o, n, i);
    },
    p(o, i) {
      i[0] & /*progress*/
      128 && t !== (t = Pt(
        /*p*/
        o[38].index || 0
      ) + "") && be(n, t);
    },
    d(o) {
      o && M(n);
    }
  };
}
function ac(e) {
  let t = Pt(
    /*p*/
    e[38].index || 0
  ) + "", n, o, i = Pt(
    /*p*/
    e[38].length
  ) + "", a;
  return {
    c() {
      n = x(t), o = x("/"), a = x(i);
    },
    m(s, _) {
      O(s, n, _), O(s, o, _), O(s, a, _);
    },
    p(s, _) {
      _[0] & /*progress*/
      128 && t !== (t = Pt(
        /*p*/
        s[38].index || 0
      ) + "") && be(n, t), _[0] & /*progress*/
      128 && i !== (i = Pt(
        /*p*/
        s[38].length
      ) + "") && be(a, i);
    },
    d(s) {
      s && (M(n), M(o), M(a));
    }
  };
}
function ja(e) {
  let t, n = (
    /*p*/
    e[38].index != null && Ga(e)
  );
  return {
    c() {
      n && n.c(), t = Kt();
    },
    m(o, i) {
      n && n.m(o, i), O(o, t, i);
    },
    p(o, i) {
      /*p*/
      o[38].index != null ? n ? n.p(o, i) : (n = Ga(o), n.c(), n.m(t.parentNode, t)) : n && (n.d(1), n = null);
    },
    d(o) {
      o && M(t), n && n.d(o);
    }
  };
}
function Va(e) {
  let t, n = (
    /*eta*/
    e[0] ? `/${/*formatted_eta*/
    e[19]}` : ""
  ), o, i;
  return {
    c() {
      t = x(
        /*formatted_timer*/
        e[20]
      ), o = x(n), i = x("s");
    },
    m(a, s) {
      O(a, t, s), O(a, o, s), O(a, i, s);
    },
    p(a, s) {
      s[0] & /*formatted_timer*/
      1048576 && be(
        t,
        /*formatted_timer*/
        a[20]
      ), s[0] & /*eta, formatted_eta*/
      524289 && n !== (n = /*eta*/
      a[0] ? `/${/*formatted_eta*/
      a[19]}` : "") && be(o, n);
    },
    d(a) {
      a && (M(t), M(o), M(i));
    }
  };
}
function lc(e) {
  let t, n;
  return t = new Fd({
    props: { margin: (
      /*variant*/
      e[8] === "default"
    ) }
  }), {
    c() {
      Ud(t.$$.fragment);
    },
    m(o, i) {
      Zd(t, o, i), n = !0;
    },
    p(o, i) {
      const a = {};
      i[0] & /*variant*/
      256 && (a.margin = /*variant*/
      o[8] === "default"), t.$set(a);
    },
    i(o) {
      n || (Xt(t.$$.fragment, o), n = !0);
    },
    o(o) {
      Zt(t.$$.fragment, o), n = !1;
    },
    d(o) {
      jd(t, o);
    }
  };
}
function sc(e) {
  let t, n, o, i, a, s = `${/*last_progress_level*/
  e[15] * 100}%`, _ = (
    /*progress*/
    e[7] != null && za(e)
  );
  return {
    c() {
      t = Je("div"), n = Je("div"), _ && _.c(), o = Ge(), i = Je("div"), a = Je("div"), Ue(n, "class", "progress-level-inner svelte-1yserjw"), Ue(a, "class", "progress-bar svelte-1yserjw"), at(a, "width", s), Ue(i, "class", "progress-bar-wrap svelte-1yserjw"), Ue(t, "class", "progress-level svelte-1yserjw");
    },
    m(l, r) {
      O(l, t, r), mt(t, n), _ && _.m(n, null), mt(t, o), mt(t, i), mt(i, a), e[30](a);
    },
    p(l, r) {
      /*progress*/
      l[7] != null ? _ ? _.p(l, r) : (_ = za(l), _.c(), _.m(n, null)) : _ && (_.d(1), _ = null), r[0] & /*last_progress_level*/
      32768 && s !== (s = `${/*last_progress_level*/
      l[15] * 100}%`) && at(a, "width", s);
    },
    i: ci,
    o: ci,
    d(l) {
      l && M(t), _ && _.d(), e[30](null);
    }
  };
}
function za(e) {
  let t, n = no(
    /*progress*/
    e[7]
  ), o = [];
  for (let i = 0; i < n.length; i += 1)
    o[i] = Qa(Fa(e, n, i));
  return {
    c() {
      for (let i = 0; i < o.length; i += 1)
        o[i].c();
      t = Kt();
    },
    m(i, a) {
      for (let s = 0; s < o.length; s += 1)
        o[s] && o[s].m(i, a);
      O(i, t, a);
    },
    p(i, a) {
      if (a[0] & /*progress_level, progress*/
      16512) {
        n = no(
          /*progress*/
          i[7]
        );
        let s;
        for (s = 0; s < n.length; s += 1) {
          const _ = Fa(i, n, s);
          o[s] ? o[s].p(_, a) : (o[s] = Qa(_), o[s].c(), o[s].m(t.parentNode, t));
        }
        for (; s < o.length; s += 1)
          o[s].d(1);
        o.length = n.length;
      }
    },
    d(i) {
      i && M(t), a_(o, i);
    }
  };
}
function Xa(e) {
  let t, n, o, i, a = (
    /*i*/
    e[40] !== 0 && _c()
  ), s = (
    /*p*/
    e[38].desc != null && Za(e)
  ), _ = (
    /*p*/
    e[38].desc != null && /*progress_level*/
    e[14] && /*progress_level*/
    e[14][
      /*i*/
      e[40]
    ] != null && Wa()
  ), l = (
    /*progress_level*/
    e[14] != null && Ja(e)
  );
  return {
    c() {
      a && a.c(), t = Ge(), s && s.c(), n = Ge(), _ && _.c(), o = Ge(), l && l.c(), i = Kt();
    },
    m(r, u) {
      a && a.m(r, u), O(r, t, u), s && s.m(r, u), O(r, n, u), _ && _.m(r, u), O(r, o, u), l && l.m(r, u), O(r, i, u);
    },
    p(r, u) {
      /*p*/
      r[38].desc != null ? s ? s.p(r, u) : (s = Za(r), s.c(), s.m(n.parentNode, n)) : s && (s.d(1), s = null), /*p*/
      r[38].desc != null && /*progress_level*/
      r[14] && /*progress_level*/
      r[14][
        /*i*/
        r[40]
      ] != null ? _ || (_ = Wa(), _.c(), _.m(o.parentNode, o)) : _ && (_.d(1), _ = null), /*progress_level*/
      r[14] != null ? l ? l.p(r, u) : (l = Ja(r), l.c(), l.m(i.parentNode, i)) : l && (l.d(1), l = null);
    },
    d(r) {
      r && (M(t), M(n), M(o), M(i)), a && a.d(r), s && s.d(r), _ && _.d(r), l && l.d(r);
    }
  };
}
function _c(e) {
  let t;
  return {
    c() {
      t = x(" /");
    },
    m(n, o) {
      O(n, t, o);
    },
    d(n) {
      n && M(t);
    }
  };
}
function Za(e) {
  let t = (
    /*p*/
    e[38].desc + ""
  ), n;
  return {
    c() {
      n = x(t);
    },
    m(o, i) {
      O(o, n, i);
    },
    p(o, i) {
      i[0] & /*progress*/
      128 && t !== (t = /*p*/
      o[38].desc + "") && be(n, t);
    },
    d(o) {
      o && M(n);
    }
  };
}
function Wa(e) {
  let t;
  return {
    c() {
      t = x("-");
    },
    m(n, o) {
      O(n, t, o);
    },
    d(n) {
      n && M(t);
    }
  };
}
function Ja(e) {
  let t = (100 * /*progress_level*/
  (e[14][
    /*i*/
    e[40]
  ] || 0)).toFixed(1) + "", n, o;
  return {
    c() {
      n = x(t), o = x("%");
    },
    m(i, a) {
      O(i, n, a), O(i, o, a);
    },
    p(i, a) {
      a[0] & /*progress_level*/
      16384 && t !== (t = (100 * /*progress_level*/
      (i[14][
        /*i*/
        i[40]
      ] || 0)).toFixed(1) + "") && be(n, t);
    },
    d(i) {
      i && (M(n), M(o));
    }
  };
}
function Qa(e) {
  let t, n = (
    /*p*/
    (e[38].desc != null || /*progress_level*/
    e[14] && /*progress_level*/
    e[14][
      /*i*/
      e[40]
    ] != null) && Xa(e)
  );
  return {
    c() {
      n && n.c(), t = Kt();
    },
    m(o, i) {
      n && n.m(o, i), O(o, t, i);
    },
    p(o, i) {
      /*p*/
      o[38].desc != null || /*progress_level*/
      o[14] && /*progress_level*/
      o[14][
        /*i*/
        o[40]
      ] != null ? n ? n.p(o, i) : (n = Xa(o), n.c(), n.m(t.parentNode, t)) : n && (n.d(1), n = null);
    },
    d(o) {
      o && M(t), n && n.d(o);
    }
  };
}
function Ya(e) {
  let t, n;
  return {
    c() {
      t = Je("p"), n = x(
        /*loading_text*/
        e[9]
      ), Ue(t, "class", "loading svelte-1yserjw");
    },
    m(o, i) {
      O(o, t, i), mt(t, n);
    },
    p(o, i) {
      i[0] & /*loading_text*/
      512 && be(
        n,
        /*loading_text*/
        o[9]
      );
    },
    d(o) {
      o && M(t);
    }
  };
}
function rc(e) {
  let t, n, o, i, a;
  const s = [ec, xd], _ = [];
  function l(r, u) {
    return (
      /*status*/
      r[4] === "pending" ? 0 : (
        /*status*/
        r[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(n = l(e)) && (o = _[n] = s[n](e)), {
    c() {
      t = Je("div"), o && o.c(), Ue(t, "class", i = "wrap " + /*variant*/
      e[8] + " " + /*show_progress*/
      e[6] + " svelte-1yserjw"), $e(t, "hide", !/*status*/
      e[4] || /*status*/
      e[4] === "complete" || /*show_progress*/
      e[6] === "hidden"), $e(
        t,
        "translucent",
        /*variant*/
        e[8] === "center" && /*status*/
        (e[4] === "pending" || /*status*/
        e[4] === "error") || /*translucent*/
        e[11] || /*show_progress*/
        e[6] === "minimal"
      ), $e(
        t,
        "generating",
        /*status*/
        e[4] === "generating"
      ), $e(
        t,
        "border",
        /*border*/
        e[12]
      ), at(
        t,
        "position",
        /*absolute*/
        e[10] ? "absolute" : "static"
      ), at(
        t,
        "padding",
        /*absolute*/
        e[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(r, u) {
      O(r, t, u), ~n && _[n].m(t, null), e[31](t), a = !0;
    },
    p(r, u) {
      let f = n;
      n = l(r), n === f ? ~n && _[n].p(r, u) : (o && (l_(), Zt(_[f], 1, 1, () => {
        _[f] = null;
      }), i_()), ~n ? (o = _[n], o ? o.p(r, u) : (o = _[n] = s[n](r), o.c()), Xt(o, 1), o.m(t, null)) : o = null), (!a || u[0] & /*variant, show_progress*/
      320 && i !== (i = "wrap " + /*variant*/
      r[8] + " " + /*show_progress*/
      r[6] + " svelte-1yserjw")) && Ue(t, "class", i), (!a || u[0] & /*variant, show_progress, status, show_progress*/
      336) && $e(t, "hide", !/*status*/
      r[4] || /*status*/
      r[4] === "complete" || /*show_progress*/
      r[6] === "hidden"), (!a || u[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && $e(
        t,
        "translucent",
        /*variant*/
        r[8] === "center" && /*status*/
        (r[4] === "pending" || /*status*/
        r[4] === "error") || /*translucent*/
        r[11] || /*show_progress*/
        r[6] === "minimal"
      ), (!a || u[0] & /*variant, show_progress, status*/
      336) && $e(
        t,
        "generating",
        /*status*/
        r[4] === "generating"
      ), (!a || u[0] & /*variant, show_progress, border*/
      4416) && $e(
        t,
        "border",
        /*border*/
        r[12]
      ), u[0] & /*absolute*/
      1024 && at(
        t,
        "position",
        /*absolute*/
        r[10] ? "absolute" : "static"
      ), u[0] & /*absolute*/
      1024 && at(
        t,
        "padding",
        /*absolute*/
        r[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(r) {
      a || (Xt(o), a = !0);
    },
    o(r) {
      Zt(o), a = !1;
    },
    d(r) {
      r && M(t), ~n && _[n].d(), e[31](null);
    }
  };
}
let Hn = [], Fo = !1;
async function uc(e, t = !0) {
  if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && t !== !0)) {
    if (Hn.push(e), !Fo) Fo = !0;
    else return;
    await Qd(), requestAnimationFrame(() => {
      let n = [0, 0];
      for (let o = 0; o < Hn.length; o++) {
        const a = Hn[o].getBoundingClientRect();
        (o === 0 || a.top + window.scrollY <= n[0]) && (n[0] = a.top + window.scrollY, n[1] = o);
      }
      window.scrollTo({ top: n[0] - 20, behavior: "smooth" }), Fo = !1, Hn = [];
    });
  }
}
function fc(e, t, n) {
  let o, { $$slots: i = {}, $$scope: a } = t, { i18n: s } = t, { eta: _ = null } = t, { queue_position: l } = t, { queue_size: r } = t, { status: u } = t, { scroll_to_output: f = !1 } = t, { timer: d = !0 } = t, { show_progress: c = "full" } = t, { message: m = null } = t, { progress: w = null } = t, { variant: b = "default" } = t, { loading_text: v = "Loading..." } = t, { absolute: g = !0 } = t, { translucent: p = !1 } = t, { border: h = !1 } = t, { autoscroll: S } = t, $, y = !1, C = 0, T = 0, P = null, E = null, Y = 0, R = null, Z, U = null, H = !0;
  const Q = () => {
    n(0, _ = n(26, P = n(19, B = null))), n(24, C = performance.now()), n(25, T = 0), y = !0, A();
  };
  function A() {
    requestAnimationFrame(() => {
      n(25, T = (performance.now() - C) / 1e3), y && A();
    });
  }
  function ae() {
    n(25, T = 0), n(0, _ = n(26, P = n(19, B = null))), y && (y = !1);
  }
  Yd(() => {
    y && ae();
  });
  let B = null;
  function Le(q) {
    Oa[q ? "unshift" : "push"](() => {
      U = q, n(16, U), n(7, w), n(14, R), n(15, Z);
    });
  }
  function _t(q) {
    Oa[q ? "unshift" : "push"](() => {
      $ = q, n(13, $);
    });
  }
  return e.$$set = (q) => {
    "i18n" in q && n(1, s = q.i18n), "eta" in q && n(0, _ = q.eta), "queue_position" in q && n(2, l = q.queue_position), "queue_size" in q && n(3, r = q.queue_size), "status" in q && n(4, u = q.status), "scroll_to_output" in q && n(21, f = q.scroll_to_output), "timer" in q && n(5, d = q.timer), "show_progress" in q && n(6, c = q.show_progress), "message" in q && n(22, m = q.message), "progress" in q && n(7, w = q.progress), "variant" in q && n(8, b = q.variant), "loading_text" in q && n(9, v = q.loading_text), "absolute" in q && n(10, g = q.absolute), "translucent" in q && n(11, p = q.translucent), "border" in q && n(12, h = q.border), "autoscroll" in q && n(23, S = q.autoscroll), "$$scope" in q && n(28, a = q.$$scope);
  }, e.$$.update = () => {
    e.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    218103809 && (_ === null && n(0, _ = P), _ != null && P !== _ && (n(27, E = (performance.now() - C) / 1e3 + _), n(19, B = E.toFixed(1)), n(26, P = _))), e.$$.dirty[0] & /*eta_from_start, timer_diff*/
    167772160 && n(17, Y = E === null || E <= 0 || !T ? null : Math.min(T / E, 1)), e.$$.dirty[0] & /*progress*/
    128 && w != null && n(18, H = !1), e.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (w != null ? n(14, R = w.map((q) => {
      if (q.index != null && q.length != null)
        return q.index / q.length;
      if (q.progress != null)
        return q.progress;
    })) : n(14, R = null), R ? (n(15, Z = R[R.length - 1]), U && (Z === 0 ? n(16, U.style.transition = "0", U) : n(16, U.style.transition = "150ms", U))) : n(15, Z = void 0)), e.$$.dirty[0] & /*status*/
    16 && (u === "pending" ? Q() : ae()), e.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    10493968 && $ && f && (u === "pending" || u === "complete") && uc($, S), e.$$.dirty[0] & /*status, message*/
    4194320, e.$$.dirty[0] & /*timer_diff*/
    33554432 && n(20, o = T.toFixed(1));
  }, [
    _,
    s,
    l,
    r,
    u,
    d,
    c,
    w,
    b,
    v,
    g,
    p,
    h,
    $,
    R,
    Z,
    U,
    Y,
    H,
    B,
    o,
    f,
    m,
    S,
    C,
    T,
    P,
    E,
    a,
    i,
    Le,
    _t
  ];
}
let dc = class extends Rd {
  constructor(t) {
    super(), Xd(
      this,
      t,
      fc,
      rc,
      Wd,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 21,
        timer: 5,
        show_progress: 6,
        message: 22,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 23
      },
      null,
      [-1, -1]
    );
  }
};
const {
  SvelteComponent: cq,
  append: pq,
  attr: mq,
  detach: hq,
  init: $q,
  insert: vq,
  noop: gq,
  safe_not_equal: wq,
  svg_element: bq
} = window.__gradio__svelte__internal, {
  SvelteComponent: Sq,
  append: Cq,
  attr: qq,
  detach: yq,
  init: kq,
  insert: Eq,
  noop: Tq,
  safe_not_equal: Bq,
  svg_element: Hq
} = window.__gradio__svelte__internal, {
  SvelteComponent: Aq,
  append: Nq,
  attr: Pq,
  detach: Lq,
  init: Iq,
  insert: Mq,
  noop: Oq,
  safe_not_equal: Dq,
  svg_element: Fq
} = window.__gradio__svelte__internal, {
  SvelteComponent: Rq,
  append: Uq,
  attr: Gq,
  detach: jq,
  init: Vq,
  insert: zq,
  noop: Xq,
  safe_not_equal: Zq,
  svg_element: Wq
} = window.__gradio__svelte__internal, {
  SvelteComponent: Jq,
  append: Qq,
  attr: Yq,
  detach: Kq,
  init: xq,
  insert: e6,
  noop: t6,
  safe_not_equal: n6,
  svg_element: o6
} = window.__gradio__svelte__internal, {
  SvelteComponent: i6,
  append: a6,
  attr: l6,
  detach: s6,
  init: _6,
  insert: r6,
  noop: u6,
  safe_not_equal: f6,
  svg_element: d6
} = window.__gradio__svelte__internal, {
  SvelteComponent: c6,
  append: p6,
  attr: m6,
  detach: h6,
  init: $6,
  insert: v6,
  noop: g6,
  safe_not_equal: w6,
  svg_element: b6
} = window.__gradio__svelte__internal, {
  SvelteComponent: S6,
  append: C6,
  attr: q6,
  detach: y6,
  init: k6,
  insert: E6,
  noop: T6,
  safe_not_equal: B6,
  svg_element: H6
} = window.__gradio__svelte__internal, {
  SvelteComponent: A6,
  append: N6,
  attr: P6,
  detach: L6,
  init: I6,
  insert: M6,
  noop: O6,
  safe_not_equal: D6,
  set_style: F6,
  svg_element: R6
} = window.__gradio__svelte__internal, {
  SvelteComponent: U6,
  append: G6,
  attr: j6,
  detach: V6,
  init: z6,
  insert: X6,
  noop: Z6,
  safe_not_equal: W6,
  svg_element: J6
} = window.__gradio__svelte__internal, {
  SvelteComponent: Q6,
  append: Y6,
  attr: K6,
  detach: x6,
  init: e8,
  insert: t8,
  noop: n8,
  safe_not_equal: o8,
  svg_element: i8
} = window.__gradio__svelte__internal, {
  SvelteComponent: a8,
  append: l8,
  attr: s8,
  detach: _8,
  init: r8,
  insert: u8,
  noop: f8,
  safe_not_equal: d8,
  svg_element: c8
} = window.__gradio__svelte__internal, {
  SvelteComponent: p8,
  append: m8,
  attr: h8,
  detach: $8,
  init: v8,
  insert: g8,
  noop: w8,
  safe_not_equal: b8,
  svg_element: S8
} = window.__gradio__svelte__internal, {
  SvelteComponent: C8,
  append: q8,
  attr: y8,
  detach: k8,
  init: E8,
  insert: T8,
  noop: B8,
  safe_not_equal: H8,
  svg_element: A8
} = window.__gradio__svelte__internal, {
  SvelteComponent: N8,
  append: P8,
  attr: L8,
  detach: I8,
  init: M8,
  insert: O8,
  noop: D8,
  safe_not_equal: F8,
  svg_element: R8
} = window.__gradio__svelte__internal, {
  SvelteComponent: U8,
  append: G8,
  attr: j8,
  detach: V8,
  init: z8,
  insert: X8,
  noop: Z8,
  safe_not_equal: W8,
  svg_element: J8
} = window.__gradio__svelte__internal, {
  SvelteComponent: Q8,
  append: Y8,
  attr: K8,
  detach: x8,
  init: ey,
  insert: ty,
  noop: ny,
  safe_not_equal: oy,
  svg_element: iy
} = window.__gradio__svelte__internal, {
  SvelteComponent: ay,
  append: ly,
  attr: sy,
  detach: _y,
  init: ry,
  insert: uy,
  noop: fy,
  safe_not_equal: dy,
  svg_element: cy
} = window.__gradio__svelte__internal, {
  SvelteComponent: py,
  append: my,
  attr: hy,
  detach: $y,
  init: vy,
  insert: gy,
  noop: wy,
  safe_not_equal: by,
  svg_element: Sy
} = window.__gradio__svelte__internal, {
  SvelteComponent: Cy,
  append: qy,
  attr: yy,
  detach: ky,
  init: Ey,
  insert: Ty,
  noop: By,
  safe_not_equal: Hy,
  svg_element: Ay
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ny,
  append: Py,
  attr: Ly,
  detach: Iy,
  init: My,
  insert: Oy,
  noop: Dy,
  safe_not_equal: Fy,
  svg_element: Ry
} = window.__gradio__svelte__internal, {
  SvelteComponent: Uy,
  append: Gy,
  attr: jy,
  detach: Vy,
  init: zy,
  insert: Xy,
  noop: Zy,
  safe_not_equal: Wy,
  svg_element: Jy
} = window.__gradio__svelte__internal, {
  SvelteComponent: Qy,
  append: Yy,
  attr: Ky,
  detach: xy,
  init: e9,
  insert: t9,
  noop: n9,
  safe_not_equal: o9,
  svg_element: i9
} = window.__gradio__svelte__internal, {
  SvelteComponent: a9,
  append: l9,
  attr: s9,
  detach: _9,
  init: r9,
  insert: u9,
  noop: f9,
  safe_not_equal: d9,
  svg_element: c9
} = window.__gradio__svelte__internal, {
  SvelteComponent: p9,
  append: m9,
  attr: h9,
  detach: $9,
  init: v9,
  insert: g9,
  noop: w9,
  safe_not_equal: b9,
  svg_element: S9
} = window.__gradio__svelte__internal, {
  SvelteComponent: C9,
  append: q9,
  attr: y9,
  detach: k9,
  init: E9,
  insert: T9,
  noop: B9,
  safe_not_equal: H9,
  svg_element: A9
} = window.__gradio__svelte__internal, {
  SvelteComponent: N9,
  append: P9,
  attr: L9,
  detach: I9,
  init: M9,
  insert: O9,
  noop: D9,
  safe_not_equal: F9,
  svg_element: R9
} = window.__gradio__svelte__internal, {
  SvelteComponent: U9,
  append: G9,
  attr: j9,
  detach: V9,
  init: z9,
  insert: X9,
  noop: Z9,
  safe_not_equal: W9,
  svg_element: J9
} = window.__gradio__svelte__internal, {
  SvelteComponent: Q9,
  append: Y9,
  attr: K9,
  detach: x9,
  init: ek,
  insert: tk,
  noop: nk,
  safe_not_equal: ok,
  svg_element: ik
} = window.__gradio__svelte__internal, {
  SvelteComponent: ak,
  append: lk,
  attr: sk,
  detach: _k,
  init: rk,
  insert: uk,
  noop: fk,
  safe_not_equal: dk,
  svg_element: ck
} = window.__gradio__svelte__internal, {
  SvelteComponent: pk,
  append: mk,
  attr: hk,
  detach: $k,
  init: vk,
  insert: gk,
  noop: wk,
  safe_not_equal: bk,
  svg_element: Sk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ck,
  append: qk,
  attr: yk,
  detach: kk,
  init: Ek,
  insert: Tk,
  noop: Bk,
  safe_not_equal: Hk,
  svg_element: Ak
} = window.__gradio__svelte__internal, {
  SvelteComponent: Nk,
  append: Pk,
  attr: Lk,
  detach: Ik,
  init: Mk,
  insert: Ok,
  noop: Dk,
  safe_not_equal: Fk,
  svg_element: Rk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Uk,
  append: Gk,
  attr: jk,
  detach: Vk,
  init: zk,
  insert: Xk,
  noop: Zk,
  safe_not_equal: Wk,
  svg_element: Jk
} = window.__gradio__svelte__internal, {
  SvelteComponent: Qk,
  append: Yk,
  attr: Kk,
  detach: xk,
  init: e7,
  insert: t7,
  noop: n7,
  safe_not_equal: o7,
  svg_element: i7
} = window.__gradio__svelte__internal, {
  SvelteComponent: a7,
  append: l7,
  attr: s7,
  detach: _7,
  init: r7,
  insert: u7,
  noop: f7,
  safe_not_equal: d7,
  svg_element: c7
} = window.__gradio__svelte__internal, {
  SvelteComponent: p7,
  append: m7,
  attr: h7,
  detach: $7,
  init: v7,
  insert: g7,
  noop: w7,
  safe_not_equal: b7,
  svg_element: S7
} = window.__gradio__svelte__internal, {
  SvelteComponent: C7,
  append: q7,
  attr: y7,
  detach: k7,
  init: E7,
  insert: T7,
  noop: B7,
  safe_not_equal: H7,
  svg_element: A7
} = window.__gradio__svelte__internal, {
  SvelteComponent: N7,
  append: P7,
  attr: L7,
  detach: I7,
  init: M7,
  insert: O7,
  noop: D7,
  safe_not_equal: F7,
  set_style: R7,
  svg_element: U7
} = window.__gradio__svelte__internal, {
  SvelteComponent: G7,
  append: j7,
  attr: V7,
  detach: z7,
  init: X7,
  insert: Z7,
  noop: W7,
  safe_not_equal: J7,
  svg_element: Q7
} = window.__gradio__svelte__internal, {
  SvelteComponent: Y7,
  append: K7,
  attr: x7,
  detach: eE,
  init: tE,
  insert: nE,
  noop: oE,
  safe_not_equal: iE,
  svg_element: aE
} = window.__gradio__svelte__internal, {
  SvelteComponent: lE,
  append: sE,
  attr: _E,
  detach: rE,
  init: uE,
  insert: fE,
  noop: dE,
  safe_not_equal: cE,
  svg_element: pE
} = window.__gradio__svelte__internal, {
  SvelteComponent: mE,
  append: hE,
  attr: $E,
  detach: vE,
  init: gE,
  insert: wE,
  noop: bE,
  safe_not_equal: SE,
  svg_element: CE
} = window.__gradio__svelte__internal, {
  SvelteComponent: qE,
  append: yE,
  attr: kE,
  detach: EE,
  init: TE,
  insert: BE,
  noop: HE,
  safe_not_equal: AE,
  svg_element: NE
} = window.__gradio__svelte__internal, {
  SvelteComponent: PE,
  append: LE,
  attr: IE,
  detach: ME,
  init: OE,
  insert: DE,
  noop: FE,
  safe_not_equal: RE,
  svg_element: UE
} = window.__gradio__svelte__internal, {
  SvelteComponent: GE,
  append: jE,
  attr: VE,
  detach: zE,
  init: XE,
  insert: ZE,
  noop: WE,
  safe_not_equal: JE,
  svg_element: QE
} = window.__gradio__svelte__internal, {
  SvelteComponent: YE,
  append: KE,
  attr: xE,
  detach: eT,
  init: tT,
  insert: nT,
  noop: oT,
  safe_not_equal: iT,
  svg_element: aT
} = window.__gradio__svelte__internal, {
  SvelteComponent: lT,
  append: sT,
  attr: _T,
  detach: rT,
  init: uT,
  insert: fT,
  noop: dT,
  safe_not_equal: cT,
  svg_element: pT,
  text: mT
} = window.__gradio__svelte__internal, {
  SvelteComponent: hT,
  append: $T,
  attr: vT,
  detach: gT,
  init: wT,
  insert: bT,
  noop: ST,
  safe_not_equal: CT,
  svg_element: qT
} = window.__gradio__svelte__internal, {
  SvelteComponent: yT,
  append: kT,
  attr: ET,
  detach: TT,
  init: BT,
  insert: HT,
  noop: AT,
  safe_not_equal: NT,
  svg_element: PT
} = window.__gradio__svelte__internal, {
  SvelteComponent: LT,
  append: IT,
  attr: MT,
  detach: OT,
  init: DT,
  insert: FT,
  noop: RT,
  safe_not_equal: UT,
  svg_element: GT
} = window.__gradio__svelte__internal, {
  SvelteComponent: jT,
  append: VT,
  attr: zT,
  detach: XT,
  init: ZT,
  insert: WT,
  noop: JT,
  safe_not_equal: QT,
  svg_element: YT
} = window.__gradio__svelte__internal, {
  SvelteComponent: KT,
  append: xT,
  attr: eB,
  detach: tB,
  init: nB,
  insert: oB,
  noop: iB,
  safe_not_equal: aB,
  svg_element: lB
} = window.__gradio__svelte__internal, {
  SvelteComponent: sB,
  append: _B,
  attr: rB,
  detach: uB,
  init: fB,
  insert: dB,
  noop: cB,
  safe_not_equal: pB,
  svg_element: mB,
  text: hB
} = window.__gradio__svelte__internal, {
  SvelteComponent: $B,
  append: vB,
  attr: gB,
  detach: wB,
  init: bB,
  insert: SB,
  noop: CB,
  safe_not_equal: qB,
  svg_element: yB,
  text: kB
} = window.__gradio__svelte__internal, {
  SvelteComponent: EB,
  append: TB,
  attr: BB,
  detach: HB,
  init: AB,
  insert: NB,
  noop: PB,
  safe_not_equal: LB,
  svg_element: IB,
  text: MB
} = window.__gradio__svelte__internal, {
  SvelteComponent: OB,
  append: DB,
  attr: FB,
  detach: RB,
  init: UB,
  insert: GB,
  noop: jB,
  safe_not_equal: VB,
  svg_element: zB
} = window.__gradio__svelte__internal, {
  SvelteComponent: XB,
  append: ZB,
  attr: WB,
  detach: JB,
  init: QB,
  insert: YB,
  noop: KB,
  safe_not_equal: xB,
  svg_element: eH
} = window.__gradio__svelte__internal, {
  SvelteComponent: tH,
  add_render_callback: nH,
  append: oH,
  attr: iH,
  bubble: aH,
  check_outros: lH,
  create_component: sH,
  create_in_transition: _H,
  create_out_transition: rH,
  destroy_component: uH,
  detach: fH,
  element: dH,
  group_outros: cH,
  init: pH,
  insert: mH,
  listen: hH,
  mount_component: $H,
  run_all: vH,
  safe_not_equal: gH,
  set_data: wH,
  space: bH,
  stop_propagation: SH,
  text: CH,
  transition_in: qH,
  transition_out: yH
} = window.__gradio__svelte__internal, { createEventDispatcher: kH, onMount: EH } = window.__gradio__svelte__internal, {
  SvelteComponent: TH,
  append: BH,
  attr: HH,
  bubble: AH,
  check_outros: NH,
  create_animation: PH,
  create_component: LH,
  destroy_component: IH,
  detach: MH,
  element: OH,
  ensure_array_like: DH,
  fix_and_outro_and_destroy_block: FH,
  fix_position: RH,
  group_outros: UH,
  init: GH,
  insert: jH,
  mount_component: VH,
  noop: zH,
  safe_not_equal: XH,
  set_style: ZH,
  space: WH,
  transition_in: JH,
  transition_out: QH,
  update_keyed_each: YH
} = window.__gradio__svelte__internal, {
  SvelteComponent: KH,
  append: xH,
  attr: eA,
  detach: tA,
  element: nA,
  init: oA,
  insert: iA,
  noop: aA,
  safe_not_equal: lA,
  set_data: sA,
  text: _A,
  toggle_class: rA
} = window.__gradio__svelte__internal, {
  SvelteComponent: cc,
  add_flush_callback: oo,
  assign: pc,
  bind: io,
  binding_callbacks: ao,
  check_outros: mc,
  create_component: Co,
  destroy_component: qo,
  detach: Ka,
  empty: hc,
  get_spread_object: $c,
  get_spread_update: vc,
  group_outros: gc,
  init: wc,
  insert: xa,
  mount_component: yo,
  safe_not_equal: bc,
  space: Sc,
  transition_in: Dt,
  transition_out: Ft
} = window.__gradio__svelte__internal;
function Cc(e) {
  let t, n, o, i;
  function a(l) {
    e[26](l);
  }
  function s(l) {
    e[27](l);
  }
  let _ = {
    choices: (
      /*choices*/
      e[9]
    ),
    label: (
      /*label*/
      e[2]
    ),
    info: (
      /*info*/
      e[3]
    ),
    show_label: (
      /*show_label*/
      e[10]
    ),
    filterable: (
      /*filterable*/
      e[11]
    ),
    allow_custom_value: (
      /*allow_custom_value*/
      e[16]
    ),
    container: (
      /*container*/
      e[12]
    ),
    disabled: !/*interactive*/
    e[18]
  };
  return (
    /*value*/
    e[0] !== void 0 && (_.value = /*value*/
    e[0]), /*value_is_output*/
    e[1] !== void 0 && (_.value_is_output = /*value_is_output*/
    e[1]), t = new Bd({ props: _ }), ao.push(() => io(t, "value", a)), ao.push(() => io(t, "value_is_output", s)), t.$on(
      "change",
      /*change_handler_1*/
      e[28]
    ), t.$on(
      "input",
      /*input_handler_1*/
      e[29]
    ), t.$on(
      "select",
      /*select_handler_1*/
      e[30]
    ), t.$on(
      "blur",
      /*blur_handler_1*/
      e[31]
    ), t.$on(
      "focus",
      /*focus_handler_1*/
      e[32]
    ), {
      c() {
        Co(t.$$.fragment);
      },
      m(l, r) {
        yo(t, l, r), i = !0;
      },
      p(l, r) {
        const u = {};
        r[0] & /*choices*/
        512 && (u.choices = /*choices*/
        l[9]), r[0] & /*label*/
        4 && (u.label = /*label*/
        l[2]), r[0] & /*info*/
        8 && (u.info = /*info*/
        l[3]), r[0] & /*show_label*/
        1024 && (u.show_label = /*show_label*/
        l[10]), r[0] & /*filterable*/
        2048 && (u.filterable = /*filterable*/
        l[11]), r[0] & /*allow_custom_value*/
        65536 && (u.allow_custom_value = /*allow_custom_value*/
        l[16]), r[0] & /*container*/
        4096 && (u.container = /*container*/
        l[12]), r[0] & /*interactive*/
        262144 && (u.disabled = !/*interactive*/
        l[18]), !n && r[0] & /*value*/
        1 && (n = !0, u.value = /*value*/
        l[0], oo(() => n = !1)), !o && r[0] & /*value_is_output*/
        2 && (o = !0, u.value_is_output = /*value_is_output*/
        l[1], oo(() => o = !1)), t.$set(u);
      },
      i(l) {
        i || (Dt(t.$$.fragment, l), i = !0);
      },
      o(l) {
        Ft(t.$$.fragment, l), i = !1;
      },
      d(l) {
        qo(t, l);
      }
    }
  );
}
function qc(e) {
  let t, n, o, i;
  function a(l) {
    e[19](l);
  }
  function s(l) {
    e[20](l);
  }
  let _ = {
    choices: (
      /*choices*/
      e[9]
    ),
    max_choices: (
      /*max_choices*/
      e[8]
    ),
    label: (
      /*label*/
      e[2]
    ),
    info: (
      /*info*/
      e[3]
    ),
    show_label: (
      /*show_label*/
      e[10]
    ),
    allow_custom_value: (
      /*allow_custom_value*/
      e[16]
    ),
    filterable: (
      /*filterable*/
      e[11]
    ),
    container: (
      /*container*/
      e[12]
    ),
    i18n: (
      /*gradio*/
      e[17].i18n
    ),
    disabled: !/*interactive*/
    e[18]
  };
  return (
    /*value*/
    e[0] !== void 0 && (_.value = /*value*/
    e[0]), /*value_is_output*/
    e[1] !== void 0 && (_.value_is_output = /*value_is_output*/
    e[1]), t = new pd({ props: _ }), ao.push(() => io(t, "value", a)), ao.push(() => io(t, "value_is_output", s)), t.$on(
      "change",
      /*change_handler*/
      e[21]
    ), t.$on(
      "input",
      /*input_handler*/
      e[22]
    ), t.$on(
      "select",
      /*select_handler*/
      e[23]
    ), t.$on(
      "blur",
      /*blur_handler*/
      e[24]
    ), t.$on(
      "focus",
      /*focus_handler*/
      e[25]
    ), {
      c() {
        Co(t.$$.fragment);
      },
      m(l, r) {
        yo(t, l, r), i = !0;
      },
      p(l, r) {
        const u = {};
        r[0] & /*choices*/
        512 && (u.choices = /*choices*/
        l[9]), r[0] & /*max_choices*/
        256 && (u.max_choices = /*max_choices*/
        l[8]), r[0] & /*label*/
        4 && (u.label = /*label*/
        l[2]), r[0] & /*info*/
        8 && (u.info = /*info*/
        l[3]), r[0] & /*show_label*/
        1024 && (u.show_label = /*show_label*/
        l[10]), r[0] & /*allow_custom_value*/
        65536 && (u.allow_custom_value = /*allow_custom_value*/
        l[16]), r[0] & /*filterable*/
        2048 && (u.filterable = /*filterable*/
        l[11]), r[0] & /*container*/
        4096 && (u.container = /*container*/
        l[12]), r[0] & /*gradio*/
        131072 && (u.i18n = /*gradio*/
        l[17].i18n), r[0] & /*interactive*/
        262144 && (u.disabled = !/*interactive*/
        l[18]), !n && r[0] & /*value*/
        1 && (n = !0, u.value = /*value*/
        l[0], oo(() => n = !1)), !o && r[0] & /*value_is_output*/
        2 && (o = !0, u.value_is_output = /*value_is_output*/
        l[1], oo(() => o = !1)), t.$set(u);
      },
      i(l) {
        i || (Dt(t.$$.fragment, l), i = !0);
      },
      o(l) {
        Ft(t.$$.fragment, l), i = !1;
      },
      d(l) {
        qo(t, l);
      }
    }
  );
}
function yc(e) {
  let t, n, o, i, a, s;
  const _ = [
    {
      autoscroll: (
        /*gradio*/
        e[17].autoscroll
      )
    },
    { i18n: (
      /*gradio*/
      e[17].i18n
    ) },
    /*loading_status*/
    e[15]
  ];
  let l = {};
  for (let d = 0; d < _.length; d += 1)
    l = pc(l, _[d]);
  t = new dc({ props: l });
  const r = [qc, Cc], u = [];
  function f(d, c) {
    return (
      /*multiselect*/
      d[7] ? 0 : 1
    );
  }
  return o = f(e), i = u[o] = r[o](e), {
    c() {
      Co(t.$$.fragment), n = Sc(), i.c(), a = hc();
    },
    m(d, c) {
      yo(t, d, c), xa(d, n, c), u[o].m(d, c), xa(d, a, c), s = !0;
    },
    p(d, c) {
      const m = c[0] & /*gradio, loading_status*/
      163840 ? vc(_, [
        c[0] & /*gradio*/
        131072 && {
          autoscroll: (
            /*gradio*/
            d[17].autoscroll
          )
        },
        c[0] & /*gradio*/
        131072 && { i18n: (
          /*gradio*/
          d[17].i18n
        ) },
        c[0] & /*loading_status*/
        32768 && $c(
          /*loading_status*/
          d[15]
        )
      ]) : {};
      t.$set(m);
      let w = o;
      o = f(d), o === w ? u[o].p(d, c) : (gc(), Ft(u[w], 1, 1, () => {
        u[w] = null;
      }), mc(), i = u[o], i ? i.p(d, c) : (i = u[o] = r[o](d), i.c()), Dt(i, 1), i.m(a.parentNode, a));
    },
    i(d) {
      s || (Dt(t.$$.fragment, d), Dt(i), s = !0);
    },
    o(d) {
      Ft(t.$$.fragment, d), Ft(i), s = !1;
    },
    d(d) {
      d && (Ka(n), Ka(a)), qo(t, d), u[o].d(d);
    }
  };
}
function kc(e) {
  let t, n;
  return t = new Gu({
    props: {
      visible: (
        /*visible*/
        e[6]
      ),
      elem_id: (
        /*elem_id*/
        e[4]
      ),
      elem_classes: (
        /*elem_classes*/
        e[5]
      ),
      padding: (
        /*container*/
        e[12]
      ),
      allow_overflow: !1,
      scale: (
        /*scale*/
        e[13]
      ),
      min_width: (
        /*min_width*/
        e[14]
      ),
      $$slots: { default: [yc] },
      $$scope: { ctx: e }
    }
  }), {
    c() {
      Co(t.$$.fragment);
    },
    m(o, i) {
      yo(t, o, i), n = !0;
    },
    p(o, i) {
      const a = {};
      i[0] & /*visible*/
      64 && (a.visible = /*visible*/
      o[6]), i[0] & /*elem_id*/
      16 && (a.elem_id = /*elem_id*/
      o[4]), i[0] & /*elem_classes*/
      32 && (a.elem_classes = /*elem_classes*/
      o[5]), i[0] & /*container*/
      4096 && (a.padding = /*container*/
      o[12]), i[0] & /*scale*/
      8192 && (a.scale = /*scale*/
      o[13]), i[0] & /*min_width*/
      16384 && (a.min_width = /*min_width*/
      o[14]), i[0] & /*choices, max_choices, label, info, show_label, allow_custom_value, filterable, container, gradio, interactive, value, value_is_output, multiselect, loading_status*/
      499599 | i[1] & /*$$scope*/
      4 && (a.$$scope = { dirty: i, ctx: o }), t.$set(a);
    },
    i(o) {
      n || (Dt(t.$$.fragment, o), n = !0);
    },
    o(o) {
      Ft(t.$$.fragment, o), n = !1;
    },
    d(o) {
      qo(t, o);
    }
  };
}
function Ec(e, t, n) {
  let { label: o = "Dropdown" } = t, { info: i = void 0 } = t, { elem_id: a = "" } = t, { elem_classes: s = [] } = t, { visible: _ = !0 } = t, { value: l } = t, { value_is_output: r = !1 } = t, { multiselect: u = !1 } = t, { max_choices: f = null } = t, { choices: d } = t, { show_label: c } = t, { filterable: m } = t, { container: w = !0 } = t, { scale: b = null } = t, { min_width: v = void 0 } = t, { loading_status: g } = t, { allow_custom_value: p = !1 } = t, { gradio: h } = t, { interactive: S } = t;
  function $(B) {
    l = B, n(0, l);
  }
  function y(B) {
    r = B, n(1, r);
  }
  const C = () => h.dispatch("change"), T = () => h.dispatch("input"), P = (B) => h.dispatch("select", B.detail), E = () => h.dispatch("blur"), Y = () => h.dispatch("focus");
  function R(B) {
    l = B, n(0, l);
  }
  function Z(B) {
    r = B, n(1, r);
  }
  const U = () => h.dispatch("change"), H = () => h.dispatch("input"), Q = (B) => h.dispatch("select", B.detail), A = () => h.dispatch("blur"), ae = () => h.dispatch("focus");
  return e.$$set = (B) => {
    "label" in B && n(2, o = B.label), "info" in B && n(3, i = B.info), "elem_id" in B && n(4, a = B.elem_id), "elem_classes" in B && n(5, s = B.elem_classes), "visible" in B && n(6, _ = B.visible), "value" in B && n(0, l = B.value), "value_is_output" in B && n(1, r = B.value_is_output), "multiselect" in B && n(7, u = B.multiselect), "max_choices" in B && n(8, f = B.max_choices), "choices" in B && n(9, d = B.choices), "show_label" in B && n(10, c = B.show_label), "filterable" in B && n(11, m = B.filterable), "container" in B && n(12, w = B.container), "scale" in B && n(13, b = B.scale), "min_width" in B && n(14, v = B.min_width), "loading_status" in B && n(15, g = B.loading_status), "allow_custom_value" in B && n(16, p = B.allow_custom_value), "gradio" in B && n(17, h = B.gradio), "interactive" in B && n(18, S = B.interactive);
  }, [
    l,
    r,
    o,
    i,
    a,
    s,
    _,
    u,
    f,
    d,
    c,
    m,
    w,
    b,
    v,
    g,
    p,
    h,
    S,
    $,
    y,
    C,
    T,
    P,
    E,
    Y,
    R,
    Z,
    U,
    H,
    Q,
    A,
    ae
  ];
}
let pi = class extends cc {
  constructor(t) {
    super(), wc(
      this,
      t,
      Ec,
      kc,
      bc,
      {
        label: 2,
        info: 3,
        elem_id: 4,
        elem_classes: 5,
        visible: 6,
        value: 0,
        value_is_output: 1,
        multiselect: 7,
        max_choices: 8,
        choices: 9,
        show_label: 10,
        filterable: 11,
        container: 12,
        scale: 13,
        min_width: 14,
        loading_status: 15,
        allow_custom_value: 16,
        gradio: 17,
        interactive: 18
      },
      null,
      [-1, -1]
    );
  }
};
const {
  SvelteComponent: Tc,
  add_flush_callback: el,
  add_render_callback: Bc,
  append: J,
  attr: oe,
  bind: tl,
  binding_callbacks: nl,
  check_outros: Hc,
  create_bidirectional_transition: ol,
  create_component: il,
  create_slot: Ac,
  destroy_component: al,
  detach: s_,
  element: le,
  get_all_dirty_from_scope: Nc,
  get_slot_changes: Pc,
  group_outros: Lc,
  init: Ic,
  insert: __,
  listen: mi,
  mount_component: ll,
  run_all: Mc,
  safe_not_equal: Oc,
  set_data: sl,
  set_input_value: An,
  space: We,
  text: Nn,
  toggle_class: _l,
  transition_in: Rt,
  transition_out: un,
  update_slot_base: Dc
} = window.__gradio__svelte__internal;
function rl(e) {
  let t, n, o, i, a, s, _, l, r, u, f, d, c, m, w, b, v, g, p, h, S, $, y, C, T;
  const P = (
    /*#slots*/
    e[8].default
  ), E = Ac(
    P,
    e,
    /*$$scope*/
    e[7],
    null
  );
  function Y(H) {
    e[12](H);
  }
  let R = {
    gradio: (
      /*gradio*/
      e[3]
    ),
    choices: (
      /*otherConditions*/
      e[4]
    ),
    placeholder: "AND...",
    label: "AND condition",
    class: "item",
    interactive: "true",
    multiselect: "true"
  };
  /*cond*/
  e[0].and_condition !== void 0 && (R.value = /*cond*/
  e[0].and_condition), v = new pi({ props: R }), nl.push(() => tl(v, "value", Y));
  function Z(H) {
    e[13](H);
  }
  let U = {
    gradio: (
      /*gradio*/
      e[3]
    ),
    choices: (
      /*otherConditions*/
      e[4]
    ),
    placeholder: "OR...",
    label: "OR condition",
    class: "item",
    interactive: "true",
    multiselect: "true"
  };
  return (
    /*cond*/
    e[0].or_condition !== void 0 && (U.value = /*cond*/
    e[0].or_condition), h = new pi({ props: U }), nl.push(() => tl(h, "value", Z)), {
      c() {
        t = le("div"), n = le("div"), o = le("div"), i = le("div"), a = le("span"), a.textContent = "Key", s = We(), _ = le("input"), l = We(), r = le("div"), u = le("span"), u.textContent = "Prompt to add", f = We(), d = le("input"), c = We(), E && E.c(), m = We(), w = le("div"), b = le("div"), il(v.$$.fragment), p = We(), il(h.$$.fragment), oe(_, "type", "text"), oe(_, "placeholder", "condition ID"), oe(_, "class", "svelte-fwy29"), oe(i, "class", "input-group svelte-fwy29"), oe(d, "type", "text"), oe(d, "placeholder", ""), oe(d, "class", "svelte-fwy29"), oe(r, "class", "input-group svelte-fwy29"), oe(o, "class", "card-body svelte-fwy29"), oe(b, "class", "gradio-row svelte-fwy29"), oe(w, "class", "card-footer svelte-fwy29"), oe(n, "class", "content"), oe(t, "class", "content-wrapper");
      },
      m(H, Q) {
        __(H, t, Q), J(t, n), J(n, o), J(o, i), J(i, a), J(i, s), J(i, _), An(
          _,
          /*cond*/
          e[0].key
        ), J(o, l), J(o, r), J(r, u), J(r, f), J(r, d), An(
          d,
          /*cond*/
          e[0].add
        ), J(o, c), E && E.m(o, null), J(n, m), J(n, w), J(w, b), ll(v, b, null), J(b, p), ll(h, b, null), y = !0, C || (T = [
          mi(
            _,
            "input",
            /*input0_input_handler*/
            e[10]
          ),
          mi(
            d,
            "input",
            /*input1_input_handler*/
            e[11]
          )
        ], C = !0);
      },
      p(H, Q) {
        Q & /*cond*/
        1 && _.value !== /*cond*/
        H[0].key && An(
          _,
          /*cond*/
          H[0].key
        ), Q & /*cond*/
        1 && d.value !== /*cond*/
        H[0].add && An(
          d,
          /*cond*/
          H[0].add
        ), E && E.p && (!y || Q & /*$$scope*/
        128) && Dc(
          E,
          P,
          H,
          /*$$scope*/
          H[7],
          y ? Pc(
            P,
            /*$$scope*/
            H[7],
            Q,
            null
          ) : Nc(
            /*$$scope*/
            H[7]
          ),
          null
        );
        const A = {};
        Q & /*gradio*/
        8 && (A.gradio = /*gradio*/
        H[3]), Q & /*otherConditions*/
        16 && (A.choices = /*otherConditions*/
        H[4]), !g && Q & /*cond*/
        1 && (g = !0, A.value = /*cond*/
        H[0].and_condition, el(() => g = !1)), v.$set(A);
        const ae = {};
        Q & /*gradio*/
        8 && (ae.gradio = /*gradio*/
        H[3]), Q & /*otherConditions*/
        16 && (ae.choices = /*otherConditions*/
        H[4]), !S && Q & /*cond*/
        1 && (S = !0, ae.value = /*cond*/
        H[0].or_condition, el(() => S = !1)), h.$set(ae);
      },
      i(H) {
        y || (Rt(E, H), Rt(v.$$.fragment, H), Rt(h.$$.fragment, H), H && Bc(() => {
          y && ($ || ($ = ol(t, Qi, { duration: 300 }, !0)), $.run(1));
        }), y = !0);
      },
      o(H) {
        un(E, H), un(v.$$.fragment, H), un(h.$$.fragment, H), H && ($ || ($ = ol(t, Qi, { duration: 300 }, !1)), $.run(0)), y = !1;
      },
      d(H) {
        H && s_(t), E && E.d(H), al(v), al(h), H && $ && $.end(), C = !1, Mc(T);
      }
    }
  );
}
function Fc(e) {
  let t, n, o, i, a, s, _ = (
    /*title*/
    (e[5] || /*theme*/
    e[2]) + ""
  ), l, r, u = (
    /*cond*/
    e[0].key + ""
  ), f, d, c, m, w, b, v, g, p, h = (
    /*isOpen*/
    e[1] && rl(e)
  );
  return {
    c() {
      t = le("div"), n = le("button"), o = le("div"), i = le("div"), a = We(), s = le("div"), l = Nn(_), r = Nn(" ("), f = Nn(u), d = Nn(")"), c = We(), m = le("span"), m.textContent = "▼", w = We(), h && h.c(), oe(i, "class", "title-circle svelte-fwy29"), oe(s, "class", "title-badge svelte-fwy29"), oe(o, "class", "gradio-row center-col svelte-fwy29"), oe(m, "class", "chevron svelte-fwy29"), _l(
        m,
        "open",
        /*isOpen*/
        e[1]
      ), oe(n, "class", "card-header svelte-fwy29"), oe(t, "class", b = "condition-card " + /*theme*/
      e[2] + " svelte-fwy29");
    },
    m(S, $) {
      __(S, t, $), J(t, n), J(n, o), J(o, i), J(o, a), J(o, s), J(s, l), J(s, r), J(s, f), J(s, d), J(n, c), J(n, m), J(t, w), h && h.m(t, null), v = !0, g || (p = mi(
        n,
        "click",
        /*click_handler*/
        e[9]
      ), g = !0);
    },
    p(S, [$]) {
      (!v || $ & /*title, theme*/
      36) && _ !== (_ = /*title*/
      (S[5] || /*theme*/
      S[2]) + "") && sl(l, _), (!v || $ & /*cond*/
      1) && u !== (u = /*cond*/
      S[0].key + "") && sl(f, u), (!v || $ & /*isOpen*/
      2) && _l(
        m,
        "open",
        /*isOpen*/
        S[1]
      ), /*isOpen*/
      S[1] ? h ? (h.p(S, $), $ & /*isOpen*/
      2 && Rt(h, 1)) : (h = rl(S), h.c(), Rt(h, 1), h.m(t, null)) : h && (Lc(), un(h, 1, 1, () => {
        h = null;
      }), Hc()), (!v || $ & /*theme*/
      4 && b !== (b = "condition-card " + /*theme*/
      S[2] + " svelte-fwy29")) && oe(t, "class", b);
    },
    i(S) {
      v || (Rt(h), v = !0);
    },
    o(S) {
      un(h), v = !1;
    },
    d(S) {
      S && s_(t), h && h.d(), g = !1, p();
    }
  };
}
function Rc(e, t, n) {
  let { $$slots: o = {}, $$scope: i } = t, { onDelete: a } = t, { theme: s } = t, { cond: _ } = t, { gradio: l } = t, { otherConditions: r } = t, { title: u = void 0 } = t, { isOpen: f = !0 } = t;
  const d = () => n(1, f = !f);
  function c() {
    _.key = this.value, n(0, _);
  }
  function m() {
    _.add = this.value, n(0, _);
  }
  function w(v) {
    e.$$.not_equal(_.and_condition, v) && (_.and_condition = v, n(0, _));
  }
  function b(v) {
    e.$$.not_equal(_.or_condition, v) && (_.or_condition = v, n(0, _));
  }
  return e.$$set = (v) => {
    "onDelete" in v && n(6, a = v.onDelete), "theme" in v && n(2, s = v.theme), "cond" in v && n(0, _ = v.cond), "gradio" in v && n(3, l = v.gradio), "otherConditions" in v && n(4, r = v.otherConditions), "title" in v && n(5, u = v.title), "isOpen" in v && n(1, f = v.isOpen), "$$scope" in v && n(7, i = v.$$scope);
  }, [
    _,
    f,
    s,
    l,
    r,
    u,
    a,
    i,
    o,
    d,
    c,
    m,
    w,
    b
  ];
}
class r_ extends Tc {
  constructor(t) {
    super(), Ic(this, t, Rc, Fc, Oc, {
      onDelete: 6,
      theme: 2,
      cond: 0,
      gradio: 3,
      otherConditions: 4,
      title: 5,
      isOpen: 1
    });
  }
}
const {
  SvelteComponent: Uc,
  append: De,
  attr: ne,
  detach: u_,
  element: ct,
  init: Gc,
  insert: f_,
  listen: nn,
  noop: ul,
  run_all: jc,
  safe_not_equal: Vc,
  set_data: d_,
  set_input_value: Pn,
  set_style: fl,
  space: Ro,
  text: c_,
  to_number: hi
} = window.__gradio__svelte__internal;
function dl(e) {
  let t, n;
  return {
    c() {
      t = ct("span"), n = c_(
        /*unit*/
        e[2]
      ), ne(t, "class", "unit-suffix svelte-117lgz5");
    },
    m(o, i) {
      f_(o, t, i), De(t, n);
    },
    p(o, i) {
      i & /*unit*/
      4 && d_(
        n,
        /*unit*/
        o[2]
      );
    },
    d(o) {
      o && u_(t);
    }
  };
}
function zc(e) {
  let t, n, o, i, a, s, _, l, r, u, f, d, c = (
    /*unit*/
    e[2] && dl(e)
  );
  return {
    c() {
      t = ct("div"), n = ct("div"), o = c_(
        /*label*/
        e[1]
      ), i = Ro(), a = ct("div"), s = ct("input"), _ = Ro(), l = ct("div"), r = ct("input"), u = Ro(), c && c.c(), ne(n, "class", "label-area svelte-117lgz5"), ne(s, "type", "range"), ne(
        s,
        "min",
        /*min*/
        e[3]
      ), ne(
        s,
        "max",
        /*max*/
        e[4]
      ), ne(
        s,
        "step",
        /*step*/
        e[5]
      ), ne(s, "class", "custom-range svelte-117lgz5"), fl(
        s,
        "--progress",
        /*percentage*/
        e[6] + "%"
      ), ne(a, "class", "slider-wrapper svelte-117lgz5"), ne(r, "type", "number"), ne(
        r,
        "min",
        /*min*/
        e[3]
      ), ne(
        r,
        "max",
        /*max*/
        e[4]
      ), ne(
        r,
        "step",
        /*step*/
        e[5]
      ), ne(r, "class", "number-input-raw svelte-117lgz5"), ne(l, "class", "input-container svelte-117lgz5"), ne(t, "class", "slider-row svelte-117lgz5");
    },
    m(m, w) {
      f_(m, t, w), De(t, n), De(n, o), De(t, i), De(t, a), De(a, s), Pn(
        s,
        /*value*/
        e[0]
      ), De(t, _), De(t, l), De(l, r), Pn(
        r,
        /*value*/
        e[0]
      ), De(l, u), c && c.m(l, null), f || (d = [
        nn(
          s,
          "change",
          /*input0_change_input_handler*/
          e[8]
        ),
        nn(
          s,
          "input",
          /*input0_change_input_handler*/
          e[8]
        ),
        nn(
          r,
          "input",
          /*input1_input_handler*/
          e[9]
        ),
        nn(
          r,
          "blur",
          /*handleBlur*/
          e[7]
        ),
        nn(
          r,
          "keydown",
          /*keydown_handler*/
          e[10]
        )
      ], f = !0);
    },
    p(m, [w]) {
      w & /*label*/
      2 && d_(
        o,
        /*label*/
        m[1]
      ), w & /*min*/
      8 && ne(
        s,
        "min",
        /*min*/
        m[3]
      ), w & /*max*/
      16 && ne(
        s,
        "max",
        /*max*/
        m[4]
      ), w & /*step*/
      32 && ne(
        s,
        "step",
        /*step*/
        m[5]
      ), w & /*percentage*/
      64 && fl(
        s,
        "--progress",
        /*percentage*/
        m[6] + "%"
      ), w & /*value*/
      1 && Pn(
        s,
        /*value*/
        m[0]
      ), w & /*min*/
      8 && ne(
        r,
        "min",
        /*min*/
        m[3]
      ), w & /*max*/
      16 && ne(
        r,
        "max",
        /*max*/
        m[4]
      ), w & /*step*/
      32 && ne(
        r,
        "step",
        /*step*/
        m[5]
      ), w & /*value*/
      1 && hi(r.value) !== /*value*/
      m[0] && Pn(
        r,
        /*value*/
        m[0]
      ), /*unit*/
      m[2] ? c ? c.p(m, w) : (c = dl(m), c.c(), c.m(l, null)) : c && (c.d(1), c = null);
    },
    i: ul,
    o: ul,
    d(m) {
      m && u_(t), c && c.d(), f = !1, jc(d);
    }
  };
}
function Xc(e, t, n) {
  let o, { label: i = "サイズ" } = t, { unit: a = "px" } = t, { min: s = 0 } = t, { max: _ = 200 } = t, { value: l = 80 } = t, { step: r = 1 } = t;
  function u() {
    l == null || isNaN(l) ? n(0, l = s) : n(0, l = Math.max(s, Math.min(_, l)));
  }
  function f() {
    l = hi(this.value), n(0, l);
  }
  function d() {
    l = hi(this.value), n(0, l);
  }
  const c = (m) => m.key === "Enter" && u();
  return e.$$set = (m) => {
    "label" in m && n(1, i = m.label), "unit" in m && n(2, a = m.unit), "min" in m && n(3, s = m.min), "max" in m && n(4, _ = m.max), "value" in m && n(0, l = m.value), "step" in m && n(5, r = m.step);
  }, e.$$.update = () => {
    e.$$.dirty & /*value, min, max*/
    25 && n(6, o = (l - s) / (_ - s) * 100);
  }, [
    l,
    i,
    a,
    s,
    _,
    r,
    o,
    u,
    f,
    d,
    c
  ];
}
class Zc extends Uc {
  constructor(t) {
    super(), Gc(this, t, Xc, zc, Vc, {
      label: 1,
      unit: 2,
      min: 3,
      max: 4,
      value: 0,
      step: 5
    });
  }
}
const {
  SvelteComponent: Wc,
  add_flush_callback: p_,
  attr: cl,
  bind: m_,
  binding_callbacks: h_,
  create_component: $_,
  destroy_component: v_,
  detach: Uo,
  element: pl,
  init: Jc,
  insert: Go,
  mount_component: g_,
  safe_not_equal: Qc,
  space: Yc,
  transition_in: w_,
  transition_out: b_
} = window.__gradio__svelte__internal;
function Kc(e) {
  let t, n, o, i, a, s;
  function _(r) {
    e[4](r);
  }
  let l = {
    label: "threshold",
    ",": !0,
    min: "0.1",
    max: "99.9",
    step: "0.1",
    unit: "%"
  };
  return (
    /*cond*/
    e[0].percent !== void 0 && (l.value = /*cond*/
    e[0].percent), i = new Zc({ props: l }), h_.push(() => m_(i, "value", _)), {
      c() {
        t = pl("div"), n = Yc(), o = pl("div"), $_(i.$$.fragment), cl(t, "class", "break svelte-15rr612"), cl(o, "class", "input-group highlight-field svelte-15rr612");
      },
      m(r, u) {
        Go(r, t, u), Go(r, n, u), Go(r, o, u), g_(i, o, null), s = !0;
      },
      p(r, u) {
        const f = {};
        !a && u & /*cond*/
        1 && (a = !0, f.value = /*cond*/
        r[0].percent, p_(() => a = !1)), i.$set(f);
      },
      i(r) {
        s || (w_(i.$$.fragment, r), s = !0);
      },
      o(r) {
        b_(i.$$.fragment, r), s = !1;
      },
      d(r) {
        r && (Uo(t), Uo(n), Uo(o)), v_(i);
      }
    }
  );
}
function xc(e) {
  let t, n, o;
  function i(s) {
    e[5](s);
  }
  let a = {
    theme: "percentage",
    onDelete: (
      /*onDelete*/
      e[2]
    ),
    otherConditions: (
      /*otherConditions*/
      e[1]
    ),
    gradio: (
      /*gradio*/
      e[3]
    ),
    $$slots: { default: [Kc] },
    $$scope: { ctx: e }
  };
  return (
    /*cond*/
    e[0] !== void 0 && (a.cond = /*cond*/
    e[0]), t = new r_({ props: a }), h_.push(() => m_(t, "cond", i)), {
      c() {
        $_(t.$$.fragment);
      },
      m(s, _) {
        g_(t, s, _), o = !0;
      },
      p(s, [_]) {
        const l = {};
        _ & /*onDelete*/
        4 && (l.onDelete = /*onDelete*/
        s[2]), _ & /*otherConditions*/
        2 && (l.otherConditions = /*otherConditions*/
        s[1]), _ & /*gradio*/
        8 && (l.gradio = /*gradio*/
        s[3]), _ & /*$$scope, cond*/
        65 && (l.$$scope = { dirty: _, ctx: s }), !n && _ & /*cond*/
        1 && (n = !0, l.cond = /*cond*/
        s[0], p_(() => n = !1)), t.$set(l);
      },
      i(s) {
        o || (w_(t.$$.fragment, s), o = !0);
      },
      o(s) {
        b_(t.$$.fragment, s), o = !1;
      },
      d(s) {
        v_(t, s);
      }
    }
  );
}
function ep(e, t, n) {
  let { cond: o } = t, { otherConditions: i } = t, { onDelete: a } = t, { gradio: s } = t;
  function _(r) {
    e.$$.not_equal(o.percent, r) && (o.percent = r, n(0, o));
  }
  function l(r) {
    o = r, n(0, o);
  }
  return e.$$set = (r) => {
    "cond" in r && n(0, o = r.cond), "otherConditions" in r && n(1, i = r.otherConditions), "onDelete" in r && n(2, a = r.onDelete), "gradio" in r && n(3, s = r.gradio);
  }, [
    o,
    i,
    a,
    s,
    _,
    l
  ];
}
class tp extends Wc {
  constructor(t) {
    super(), Jc(this, t, ep, xc, Qc, {
      cond: 0,
      otherConditions: 1,
      onDelete: 2,
      gradio: 3
    });
  }
}
const {
  SvelteComponent: np,
  assign: op,
  create_slot: ip,
  detach: ap,
  element: lp,
  get_all_dirty_from_scope: sp,
  get_slot_changes: _p,
  get_spread_update: rp,
  init: up,
  insert: fp,
  safe_not_equal: dp,
  set_dynamic_element_data: ml,
  set_style: de,
  toggle_class: Me,
  transition_in: S_,
  transition_out: C_,
  update_slot_base: cp
} = window.__gradio__svelte__internal;
function pp(e) {
  let t, n, o;
  const i = (
    /*#slots*/
    e[18].default
  ), a = ip(
    i,
    e,
    /*$$scope*/
    e[17],
    null
  );
  let s = [
    { "data-testid": (
      /*test_id*/
      e[7]
    ) },
    { id: (
      /*elem_id*/
      e[2]
    ) },
    {
      class: n = "block " + /*elem_classes*/
      e[3].join(" ") + " svelte-nl1om8"
    }
  ], _ = {};
  for (let l = 0; l < s.length; l += 1)
    _ = op(_, s[l]);
  return {
    c() {
      t = lp(
        /*tag*/
        e[14]
      ), a && a.c(), ml(
        /*tag*/
        e[14]
      )(t, _), Me(
        t,
        "hidden",
        /*visible*/
        e[10] === !1
      ), Me(
        t,
        "padded",
        /*padding*/
        e[6]
      ), Me(
        t,
        "border_focus",
        /*border_mode*/
        e[5] === "focus"
      ), Me(
        t,
        "border_contrast",
        /*border_mode*/
        e[5] === "contrast"
      ), Me(t, "hide-container", !/*explicit_call*/
      e[8] && !/*container*/
      e[9]), de(
        t,
        "height",
        /*get_dimension*/
        e[15](
          /*height*/
          e[0]
        )
      ), de(t, "width", typeof /*width*/
      e[1] == "number" ? `calc(min(${/*width*/
      e[1]}px, 100%))` : (
        /*get_dimension*/
        e[15](
          /*width*/
          e[1]
        )
      )), de(
        t,
        "border-style",
        /*variant*/
        e[4]
      ), de(
        t,
        "overflow",
        /*allow_overflow*/
        e[11] ? "visible" : "hidden"
      ), de(
        t,
        "flex-grow",
        /*scale*/
        e[12]
      ), de(t, "min-width", `calc(min(${/*min_width*/
      e[13]}px, 100%))`), de(t, "border-width", "var(--block-border-width)");
    },
    m(l, r) {
      fp(l, t, r), a && a.m(t, null), o = !0;
    },
    p(l, r) {
      a && a.p && (!o || r & /*$$scope*/
      131072) && cp(
        a,
        i,
        l,
        /*$$scope*/
        l[17],
        o ? _p(
          i,
          /*$$scope*/
          l[17],
          r,
          null
        ) : sp(
          /*$$scope*/
          l[17]
        ),
        null
      ), ml(
        /*tag*/
        l[14]
      )(t, _ = rp(s, [
        (!o || r & /*test_id*/
        128) && { "data-testid": (
          /*test_id*/
          l[7]
        ) },
        (!o || r & /*elem_id*/
        4) && { id: (
          /*elem_id*/
          l[2]
        ) },
        (!o || r & /*elem_classes*/
        8 && n !== (n = "block " + /*elem_classes*/
        l[3].join(" ") + " svelte-nl1om8")) && { class: n }
      ])), Me(
        t,
        "hidden",
        /*visible*/
        l[10] === !1
      ), Me(
        t,
        "padded",
        /*padding*/
        l[6]
      ), Me(
        t,
        "border_focus",
        /*border_mode*/
        l[5] === "focus"
      ), Me(
        t,
        "border_contrast",
        /*border_mode*/
        l[5] === "contrast"
      ), Me(t, "hide-container", !/*explicit_call*/
      l[8] && !/*container*/
      l[9]), r & /*height*/
      1 && de(
        t,
        "height",
        /*get_dimension*/
        l[15](
          /*height*/
          l[0]
        )
      ), r & /*width*/
      2 && de(t, "width", typeof /*width*/
      l[1] == "number" ? `calc(min(${/*width*/
      l[1]}px, 100%))` : (
        /*get_dimension*/
        l[15](
          /*width*/
          l[1]
        )
      )), r & /*variant*/
      16 && de(
        t,
        "border-style",
        /*variant*/
        l[4]
      ), r & /*allow_overflow*/
      2048 && de(
        t,
        "overflow",
        /*allow_overflow*/
        l[11] ? "visible" : "hidden"
      ), r & /*scale*/
      4096 && de(
        t,
        "flex-grow",
        /*scale*/
        l[12]
      ), r & /*min_width*/
      8192 && de(t, "min-width", `calc(min(${/*min_width*/
      l[13]}px, 100%))`);
    },
    i(l) {
      o || (S_(a, l), o = !0);
    },
    o(l) {
      C_(a, l), o = !1;
    },
    d(l) {
      l && ap(t), a && a.d(l);
    }
  };
}
function mp(e) {
  let t, n = (
    /*tag*/
    e[14] && pp(e)
  );
  return {
    c() {
      n && n.c();
    },
    m(o, i) {
      n && n.m(o, i), t = !0;
    },
    p(o, [i]) {
      /*tag*/
      o[14] && n.p(o, i);
    },
    i(o) {
      t || (S_(n, o), t = !0);
    },
    o(o) {
      C_(n, o), t = !1;
    },
    d(o) {
      n && n.d(o);
    }
  };
}
function hp(e, t, n) {
  let { $$slots: o = {}, $$scope: i } = t, { height: a = void 0 } = t, { width: s = void 0 } = t, { elem_id: _ = "" } = t, { elem_classes: l = [] } = t, { variant: r = "solid" } = t, { border_mode: u = "base" } = t, { padding: f = !0 } = t, { type: d = "normal" } = t, { test_id: c = void 0 } = t, { explicit_call: m = !1 } = t, { container: w = !0 } = t, { visible: b = !0 } = t, { allow_overflow: v = !0 } = t, { scale: g = null } = t, { min_width: p = 0 } = t, h = d === "fieldset" ? "fieldset" : "div";
  const S = ($) => {
    if ($ !== void 0) {
      if (typeof $ == "number")
        return $ + "px";
      if (typeof $ == "string")
        return $;
    }
  };
  return e.$$set = ($) => {
    "height" in $ && n(0, a = $.height), "width" in $ && n(1, s = $.width), "elem_id" in $ && n(2, _ = $.elem_id), "elem_classes" in $ && n(3, l = $.elem_classes), "variant" in $ && n(4, r = $.variant), "border_mode" in $ && n(5, u = $.border_mode), "padding" in $ && n(6, f = $.padding), "type" in $ && n(16, d = $.type), "test_id" in $ && n(7, c = $.test_id), "explicit_call" in $ && n(8, m = $.explicit_call), "container" in $ && n(9, w = $.container), "visible" in $ && n(10, b = $.visible), "allow_overflow" in $ && n(11, v = $.allow_overflow), "scale" in $ && n(12, g = $.scale), "min_width" in $ && n(13, p = $.min_width), "$$scope" in $ && n(17, i = $.$$scope);
  }, [
    a,
    s,
    _,
    l,
    r,
    u,
    f,
    c,
    m,
    w,
    b,
    v,
    g,
    p,
    h,
    S,
    d,
    i,
    o
  ];
}
let $p = class extends np {
  constructor(t) {
    super(), up(this, t, hp, mp, dp, {
      height: 0,
      width: 1,
      elem_id: 2,
      elem_classes: 3,
      variant: 4,
      border_mode: 5,
      padding: 6,
      type: 16,
      test_id: 7,
      explicit_call: 8,
      container: 9,
      visible: 10,
      allow_overflow: 11,
      scale: 12,
      min_width: 13
    });
  }
};
const {
  SvelteComponent: vp,
  attr: gp,
  create_slot: wp,
  detach: bp,
  element: Sp,
  get_all_dirty_from_scope: Cp,
  get_slot_changes: qp,
  init: yp,
  insert: kp,
  safe_not_equal: Ep,
  transition_in: Tp,
  transition_out: Bp,
  update_slot_base: Hp
} = window.__gradio__svelte__internal;
function Ap(e) {
  let t, n;
  const o = (
    /*#slots*/
    e[1].default
  ), i = wp(
    o,
    e,
    /*$$scope*/
    e[0],
    null
  );
  return {
    c() {
      t = Sp("div"), i && i.c(), gp(t, "class", "svelte-1hnfib2");
    },
    m(a, s) {
      kp(a, t, s), i && i.m(t, null), n = !0;
    },
    p(a, [s]) {
      i && i.p && (!n || s & /*$$scope*/
      1) && Hp(
        i,
        o,
        a,
        /*$$scope*/
        a[0],
        n ? qp(
          o,
          /*$$scope*/
          a[0],
          s,
          null
        ) : Cp(
          /*$$scope*/
          a[0]
        ),
        null
      );
    },
    i(a) {
      n || (Tp(i, a), n = !0);
    },
    o(a) {
      Bp(i, a), n = !1;
    },
    d(a) {
      a && bp(t), i && i.d(a);
    }
  };
}
function Np(e, t, n) {
  let { $$slots: o = {}, $$scope: i } = t;
  return e.$$set = (a) => {
    "$$scope" in a && n(0, i = a.$$scope);
  }, [i, o];
}
let Pp = class extends vp {
  constructor(t) {
    super(), yp(this, t, Np, Ap, Ep, {});
  }
};
const {
  SvelteComponent: cA,
  attr: pA,
  check_outros: mA,
  create_component: hA,
  create_slot: $A,
  destroy_component: vA,
  detach: gA,
  element: wA,
  empty: bA,
  get_all_dirty_from_scope: SA,
  get_slot_changes: CA,
  group_outros: qA,
  init: yA,
  insert: kA,
  mount_component: EA,
  safe_not_equal: TA,
  set_data: BA,
  space: HA,
  text: AA,
  toggle_class: NA,
  transition_in: PA,
  transition_out: LA,
  update_slot_base: IA
} = window.__gradio__svelte__internal, {
  SvelteComponent: MA,
  append: OA,
  attr: DA,
  create_component: FA,
  destroy_component: RA,
  detach: UA,
  element: GA,
  init: jA,
  insert: VA,
  mount_component: zA,
  safe_not_equal: XA,
  set_data: ZA,
  space: WA,
  text: JA,
  toggle_class: QA,
  transition_in: YA,
  transition_out: KA
} = window.__gradio__svelte__internal, {
  SvelteComponent: Lp,
  append: $i,
  attr: Ze,
  bubble: Ip,
  create_component: Mp,
  destroy_component: Op,
  detach: q_,
  element: vi,
  init: Dp,
  insert: y_,
  listen: Fp,
  mount_component: Rp,
  safe_not_equal: Up,
  set_data: Gp,
  set_style: kt,
  space: jp,
  text: Vp,
  toggle_class: ue,
  transition_in: zp,
  transition_out: Xp
} = window.__gradio__svelte__internal;
function hl(e) {
  let t, n;
  return {
    c() {
      t = vi("span"), n = Vp(
        /*label*/
        e[1]
      ), Ze(t, "class", "svelte-1lrphxw");
    },
    m(o, i) {
      y_(o, t, i), $i(t, n);
    },
    p(o, i) {
      i & /*label*/
      2 && Gp(
        n,
        /*label*/
        o[1]
      );
    },
    d(o) {
      o && q_(t);
    }
  };
}
function Zp(e) {
  let t, n, o, i, a, s, _, l = (
    /*show_label*/
    e[2] && hl(e)
  );
  return i = new /*Icon*/
  e[0]({}), {
    c() {
      t = vi("button"), l && l.c(), n = jp(), o = vi("div"), Mp(i.$$.fragment), Ze(o, "class", "svelte-1lrphxw"), ue(
        o,
        "small",
        /*size*/
        e[4] === "small"
      ), ue(
        o,
        "large",
        /*size*/
        e[4] === "large"
      ), ue(
        o,
        "medium",
        /*size*/
        e[4] === "medium"
      ), t.disabled = /*disabled*/
      e[7], Ze(
        t,
        "aria-label",
        /*label*/
        e[1]
      ), Ze(
        t,
        "aria-haspopup",
        /*hasPopup*/
        e[8]
      ), Ze(
        t,
        "title",
        /*label*/
        e[1]
      ), Ze(t, "class", "svelte-1lrphxw"), ue(
        t,
        "pending",
        /*pending*/
        e[3]
      ), ue(
        t,
        "padded",
        /*padded*/
        e[5]
      ), ue(
        t,
        "highlight",
        /*highlight*/
        e[6]
      ), ue(
        t,
        "transparent",
        /*transparent*/
        e[9]
      ), kt(t, "color", !/*disabled*/
      e[7] && /*_color*/
      e[12] ? (
        /*_color*/
        e[12]
      ) : "var(--block-label-text-color)"), kt(t, "--bg-color", /*disabled*/
      e[7] ? "auto" : (
        /*background*/
        e[10]
      )), kt(
        t,
        "margin-left",
        /*offset*/
        e[11] + "px"
      );
    },
    m(r, u) {
      y_(r, t, u), l && l.m(t, null), $i(t, n), $i(t, o), Rp(i, o, null), a = !0, s || (_ = Fp(
        t,
        "click",
        /*click_handler*/
        e[14]
      ), s = !0);
    },
    p(r, [u]) {
      /*show_label*/
      r[2] ? l ? l.p(r, u) : (l = hl(r), l.c(), l.m(t, n)) : l && (l.d(1), l = null), (!a || u & /*size*/
      16) && ue(
        o,
        "small",
        /*size*/
        r[4] === "small"
      ), (!a || u & /*size*/
      16) && ue(
        o,
        "large",
        /*size*/
        r[4] === "large"
      ), (!a || u & /*size*/
      16) && ue(
        o,
        "medium",
        /*size*/
        r[4] === "medium"
      ), (!a || u & /*disabled*/
      128) && (t.disabled = /*disabled*/
      r[7]), (!a || u & /*label*/
      2) && Ze(
        t,
        "aria-label",
        /*label*/
        r[1]
      ), (!a || u & /*hasPopup*/
      256) && Ze(
        t,
        "aria-haspopup",
        /*hasPopup*/
        r[8]
      ), (!a || u & /*label*/
      2) && Ze(
        t,
        "title",
        /*label*/
        r[1]
      ), (!a || u & /*pending*/
      8) && ue(
        t,
        "pending",
        /*pending*/
        r[3]
      ), (!a || u & /*padded*/
      32) && ue(
        t,
        "padded",
        /*padded*/
        r[5]
      ), (!a || u & /*highlight*/
      64) && ue(
        t,
        "highlight",
        /*highlight*/
        r[6]
      ), (!a || u & /*transparent*/
      512) && ue(
        t,
        "transparent",
        /*transparent*/
        r[9]
      ), u & /*disabled, _color*/
      4224 && kt(t, "color", !/*disabled*/
      r[7] && /*_color*/
      r[12] ? (
        /*_color*/
        r[12]
      ) : "var(--block-label-text-color)"), u & /*disabled, background*/
      1152 && kt(t, "--bg-color", /*disabled*/
      r[7] ? "auto" : (
        /*background*/
        r[10]
      )), u & /*offset*/
      2048 && kt(
        t,
        "margin-left",
        /*offset*/
        r[11] + "px"
      );
    },
    i(r) {
      a || (zp(i.$$.fragment, r), a = !0);
    },
    o(r) {
      Xp(i.$$.fragment, r), a = !1;
    },
    d(r) {
      r && q_(t), l && l.d(), Op(i), s = !1, _();
    }
  };
}
function Wp(e, t, n) {
  let o, { Icon: i } = t, { label: a = "" } = t, { show_label: s = !1 } = t, { pending: _ = !1 } = t, { size: l = "small" } = t, { padded: r = !0 } = t, { highlight: u = !1 } = t, { disabled: f = !1 } = t, { hasPopup: d = !1 } = t, { color: c = "var(--block-label-text-color)" } = t, { transparent: m = !1 } = t, { background: w = "var(--background-fill-primary)" } = t, { offset: b = 0 } = t;
  function v(g) {
    Ip.call(this, e, g);
  }
  return e.$$set = (g) => {
    "Icon" in g && n(0, i = g.Icon), "label" in g && n(1, a = g.label), "show_label" in g && n(2, s = g.show_label), "pending" in g && n(3, _ = g.pending), "size" in g && n(4, l = g.size), "padded" in g && n(5, r = g.padded), "highlight" in g && n(6, u = g.highlight), "disabled" in g && n(7, f = g.disabled), "hasPopup" in g && n(8, d = g.hasPopup), "color" in g && n(13, c = g.color), "transparent" in g && n(9, m = g.transparent), "background" in g && n(10, w = g.background), "offset" in g && n(11, b = g.offset);
  }, e.$$.update = () => {
    e.$$.dirty & /*highlight, color*/
    8256 && n(12, o = u ? "var(--color-accent)" : c);
  }, [
    i,
    a,
    s,
    _,
    l,
    r,
    u,
    f,
    d,
    m,
    w,
    b,
    o,
    c,
    v
  ];
}
class Jp extends Lp {
  constructor(t) {
    super(), Dp(this, t, Wp, Zp, Up, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 13,
      transparent: 9,
      background: 10,
      offset: 11
    });
  }
}
const {
  SvelteComponent: xA,
  append: eN,
  attr: tN,
  binding_callbacks: nN,
  create_slot: oN,
  detach: iN,
  element: aN,
  get_all_dirty_from_scope: lN,
  get_slot_changes: sN,
  init: _N,
  insert: rN,
  safe_not_equal: uN,
  toggle_class: fN,
  transition_in: dN,
  transition_out: cN,
  update_slot_base: pN
} = window.__gradio__svelte__internal, {
  SvelteComponent: mN,
  append: hN,
  attr: $N,
  detach: vN,
  init: gN,
  insert: wN,
  noop: bN,
  safe_not_equal: SN,
  svg_element: CN
} = window.__gradio__svelte__internal, {
  SvelteComponent: qN,
  append: yN,
  attr: kN,
  detach: EN,
  init: TN,
  insert: BN,
  noop: HN,
  safe_not_equal: AN,
  svg_element: NN
} = window.__gradio__svelte__internal, {
  SvelteComponent: PN,
  append: LN,
  attr: IN,
  detach: MN,
  init: ON,
  insert: DN,
  noop: FN,
  safe_not_equal: RN,
  svg_element: UN
} = window.__gradio__svelte__internal, {
  SvelteComponent: GN,
  append: jN,
  attr: VN,
  detach: zN,
  init: XN,
  insert: ZN,
  noop: WN,
  safe_not_equal: JN,
  svg_element: QN
} = window.__gradio__svelte__internal, {
  SvelteComponent: YN,
  append: KN,
  attr: xN,
  detach: eP,
  init: tP,
  insert: nP,
  noop: oP,
  safe_not_equal: iP,
  svg_element: aP
} = window.__gradio__svelte__internal, {
  SvelteComponent: lP,
  append: sP,
  attr: _P,
  detach: rP,
  init: uP,
  insert: fP,
  noop: dP,
  safe_not_equal: cP,
  svg_element: pP
} = window.__gradio__svelte__internal, {
  SvelteComponent: mP,
  append: hP,
  attr: $P,
  detach: vP,
  init: gP,
  insert: wP,
  noop: bP,
  safe_not_equal: SP,
  svg_element: CP
} = window.__gradio__svelte__internal, {
  SvelteComponent: qP,
  append: yP,
  attr: kP,
  detach: EP,
  init: TP,
  insert: BP,
  noop: HP,
  safe_not_equal: AP,
  svg_element: NP
} = window.__gradio__svelte__internal, {
  SvelteComponent: PP,
  append: LP,
  attr: IP,
  detach: MP,
  init: OP,
  insert: DP,
  noop: FP,
  safe_not_equal: RP,
  svg_element: UP
} = window.__gradio__svelte__internal, {
  SvelteComponent: GP,
  append: jP,
  attr: VP,
  detach: zP,
  init: XP,
  insert: ZP,
  noop: WP,
  safe_not_equal: JP,
  svg_element: QP
} = window.__gradio__svelte__internal, {
  SvelteComponent: YP,
  append: KP,
  attr: xP,
  detach: eL,
  init: tL,
  insert: nL,
  noop: oL,
  safe_not_equal: iL,
  set_style: aL,
  svg_element: lL
} = window.__gradio__svelte__internal, {
  SvelteComponent: sL,
  append: _L,
  attr: rL,
  detach: uL,
  init: fL,
  insert: dL,
  noop: cL,
  safe_not_equal: pL,
  svg_element: mL
} = window.__gradio__svelte__internal, {
  SvelteComponent: hL,
  append: $L,
  attr: vL,
  detach: gL,
  init: wL,
  insert: bL,
  noop: SL,
  safe_not_equal: CL,
  svg_element: qL
} = window.__gradio__svelte__internal, {
  SvelteComponent: yL,
  append: kL,
  attr: EL,
  detach: TL,
  init: BL,
  insert: HL,
  noop: AL,
  safe_not_equal: NL,
  svg_element: PL
} = window.__gradio__svelte__internal, {
  SvelteComponent: LL,
  append: IL,
  attr: ML,
  detach: OL,
  init: DL,
  insert: FL,
  noop: RL,
  safe_not_equal: UL,
  svg_element: GL
} = window.__gradio__svelte__internal, {
  SvelteComponent: jL,
  append: VL,
  attr: zL,
  detach: XL,
  init: ZL,
  insert: WL,
  noop: JL,
  safe_not_equal: QL,
  svg_element: YL
} = window.__gradio__svelte__internal, {
  SvelteComponent: KL,
  append: xL,
  attr: eI,
  detach: tI,
  init: nI,
  insert: oI,
  noop: iI,
  safe_not_equal: aI,
  svg_element: lI
} = window.__gradio__svelte__internal, {
  SvelteComponent: sI,
  append: _I,
  attr: rI,
  detach: uI,
  init: fI,
  insert: dI,
  noop: cI,
  safe_not_equal: pI,
  svg_element: mI
} = window.__gradio__svelte__internal, {
  SvelteComponent: hI,
  append: $I,
  attr: vI,
  detach: gI,
  init: wI,
  insert: bI,
  noop: SI,
  safe_not_equal: CI,
  svg_element: qI
} = window.__gradio__svelte__internal, {
  SvelteComponent: yI,
  append: kI,
  attr: EI,
  detach: TI,
  init: BI,
  insert: HI,
  noop: AI,
  safe_not_equal: NI,
  svg_element: PI
} = window.__gradio__svelte__internal, {
  SvelteComponent: LI,
  append: II,
  attr: MI,
  detach: OI,
  init: DI,
  insert: FI,
  noop: RI,
  safe_not_equal: UI,
  svg_element: GI
} = window.__gradio__svelte__internal, {
  SvelteComponent: jI,
  append: VI,
  attr: zI,
  detach: XI,
  init: ZI,
  insert: WI,
  noop: JI,
  safe_not_equal: QI,
  svg_element: YI
} = window.__gradio__svelte__internal, {
  SvelteComponent: KI,
  append: xI,
  attr: eM,
  detach: tM,
  init: nM,
  insert: oM,
  noop: iM,
  safe_not_equal: aM,
  svg_element: lM
} = window.__gradio__svelte__internal, {
  SvelteComponent: sM,
  append: _M,
  attr: rM,
  detach: uM,
  init: fM,
  insert: dM,
  noop: cM,
  safe_not_equal: pM,
  svg_element: mM
} = window.__gradio__svelte__internal, {
  SvelteComponent: hM,
  append: $M,
  attr: vM,
  detach: gM,
  init: wM,
  insert: bM,
  noop: SM,
  safe_not_equal: CM,
  svg_element: qM
} = window.__gradio__svelte__internal, {
  SvelteComponent: yM,
  append: kM,
  attr: EM,
  detach: TM,
  init: BM,
  insert: HM,
  noop: AM,
  safe_not_equal: NM,
  svg_element: PM
} = window.__gradio__svelte__internal, {
  SvelteComponent: LM,
  append: IM,
  attr: MM,
  detach: OM,
  init: DM,
  insert: FM,
  noop: RM,
  safe_not_equal: UM,
  svg_element: GM
} = window.__gradio__svelte__internal, {
  SvelteComponent: jM,
  append: VM,
  attr: zM,
  detach: XM,
  init: ZM,
  insert: WM,
  noop: JM,
  safe_not_equal: QM,
  svg_element: YM
} = window.__gradio__svelte__internal, {
  SvelteComponent: KM,
  append: xM,
  attr: eO,
  detach: tO,
  init: nO,
  insert: oO,
  noop: iO,
  safe_not_equal: aO,
  svg_element: lO
} = window.__gradio__svelte__internal, {
  SvelteComponent: sO,
  append: _O,
  attr: rO,
  detach: uO,
  init: fO,
  insert: dO,
  noop: cO,
  safe_not_equal: pO,
  svg_element: mO
} = window.__gradio__svelte__internal, {
  SvelteComponent: hO,
  append: $O,
  attr: vO,
  detach: gO,
  init: wO,
  insert: bO,
  noop: SO,
  safe_not_equal: CO,
  svg_element: qO
} = window.__gradio__svelte__internal, {
  SvelteComponent: yO,
  append: kO,
  attr: EO,
  detach: TO,
  init: BO,
  insert: HO,
  noop: AO,
  safe_not_equal: NO,
  svg_element: PO
} = window.__gradio__svelte__internal, {
  SvelteComponent: LO,
  append: IO,
  attr: MO,
  detach: OO,
  init: DO,
  insert: FO,
  noop: RO,
  safe_not_equal: UO,
  svg_element: GO
} = window.__gradio__svelte__internal, {
  SvelteComponent: jO,
  append: VO,
  attr: zO,
  detach: XO,
  init: ZO,
  insert: WO,
  noop: JO,
  safe_not_equal: QO,
  svg_element: YO
} = window.__gradio__svelte__internal, {
  SvelteComponent: KO,
  append: xO,
  attr: eD,
  detach: tD,
  init: nD,
  insert: oD,
  noop: iD,
  safe_not_equal: aD,
  svg_element: lD
} = window.__gradio__svelte__internal, {
  SvelteComponent: sD,
  append: _D,
  attr: rD,
  detach: uD,
  init: fD,
  insert: dD,
  noop: cD,
  safe_not_equal: pD,
  svg_element: mD
} = window.__gradio__svelte__internal, {
  SvelteComponent: hD,
  append: $D,
  attr: vD,
  detach: gD,
  init: wD,
  insert: bD,
  noop: SD,
  safe_not_equal: CD,
  svg_element: qD
} = window.__gradio__svelte__internal, {
  SvelteComponent: yD,
  append: kD,
  attr: ED,
  detach: TD,
  init: BD,
  insert: HD,
  noop: AD,
  safe_not_equal: ND,
  svg_element: PD
} = window.__gradio__svelte__internal, {
  SvelteComponent: LD,
  append: ID,
  attr: MD,
  detach: OD,
  init: DD,
  insert: FD,
  noop: RD,
  safe_not_equal: UD,
  svg_element: GD
} = window.__gradio__svelte__internal, {
  SvelteComponent: jD,
  append: VD,
  attr: zD,
  detach: XD,
  init: ZD,
  insert: WD,
  noop: JD,
  safe_not_equal: QD,
  svg_element: YD
} = window.__gradio__svelte__internal, {
  SvelteComponent: KD,
  append: xD,
  attr: eF,
  detach: tF,
  init: nF,
  insert: oF,
  noop: iF,
  safe_not_equal: aF,
  set_style: lF,
  svg_element: sF
} = window.__gradio__svelte__internal, {
  SvelteComponent: _F,
  append: rF,
  attr: uF,
  detach: fF,
  init: dF,
  insert: cF,
  noop: pF,
  safe_not_equal: mF,
  svg_element: hF
} = window.__gradio__svelte__internal, {
  SvelteComponent: $F,
  append: vF,
  attr: gF,
  detach: wF,
  init: bF,
  insert: SF,
  noop: CF,
  safe_not_equal: qF,
  svg_element: yF
} = window.__gradio__svelte__internal, {
  SvelteComponent: kF,
  append: EF,
  attr: TF,
  detach: BF,
  init: HF,
  insert: AF,
  noop: NF,
  safe_not_equal: PF,
  svg_element: LF
} = window.__gradio__svelte__internal, {
  SvelteComponent: IF,
  append: MF,
  attr: OF,
  detach: DF,
  init: FF,
  insert: RF,
  noop: UF,
  safe_not_equal: GF,
  svg_element: jF
} = window.__gradio__svelte__internal, {
  SvelteComponent: VF,
  append: zF,
  attr: XF,
  detach: ZF,
  init: WF,
  insert: JF,
  noop: QF,
  safe_not_equal: YF,
  svg_element: KF
} = window.__gradio__svelte__internal, {
  SvelteComponent: xF,
  append: eR,
  attr: tR,
  detach: nR,
  init: oR,
  insert: iR,
  noop: aR,
  safe_not_equal: lR,
  svg_element: sR
} = window.__gradio__svelte__internal, {
  SvelteComponent: _R,
  append: rR,
  attr: uR,
  detach: fR,
  init: dR,
  insert: cR,
  noop: pR,
  safe_not_equal: mR,
  svg_element: hR
} = window.__gradio__svelte__internal, {
  SvelteComponent: $R,
  append: vR,
  attr: gR,
  detach: wR,
  init: bR,
  insert: SR,
  noop: CR,
  safe_not_equal: qR,
  svg_element: yR
} = window.__gradio__svelte__internal, {
  SvelteComponent: kR,
  append: ER,
  attr: TR,
  detach: BR,
  init: HR,
  insert: AR,
  noop: NR,
  safe_not_equal: PR,
  svg_element: LR,
  text: IR
} = window.__gradio__svelte__internal, {
  SvelteComponent: MR,
  append: OR,
  attr: DR,
  detach: FR,
  init: RR,
  insert: UR,
  noop: GR,
  safe_not_equal: jR,
  svg_element: VR
} = window.__gradio__svelte__internal, {
  SvelteComponent: zR,
  append: XR,
  attr: ZR,
  detach: WR,
  init: JR,
  insert: QR,
  noop: YR,
  safe_not_equal: KR,
  svg_element: xR
} = window.__gradio__svelte__internal, {
  SvelteComponent: eU,
  append: tU,
  attr: nU,
  detach: oU,
  init: iU,
  insert: aU,
  noop: lU,
  safe_not_equal: sU,
  svg_element: _U
} = window.__gradio__svelte__internal, {
  SvelteComponent: rU,
  append: uU,
  attr: fU,
  detach: dU,
  init: cU,
  insert: pU,
  noop: mU,
  safe_not_equal: hU,
  svg_element: $U
} = window.__gradio__svelte__internal, {
  SvelteComponent: vU,
  append: gU,
  attr: wU,
  detach: bU,
  init: SU,
  insert: CU,
  noop: qU,
  safe_not_equal: yU,
  svg_element: kU
} = window.__gradio__svelte__internal, {
  SvelteComponent: EU,
  append: TU,
  attr: BU,
  detach: HU,
  init: AU,
  insert: NU,
  noop: PU,
  safe_not_equal: LU,
  svg_element: IU,
  text: MU
} = window.__gradio__svelte__internal, {
  SvelteComponent: OU,
  append: DU,
  attr: FU,
  detach: RU,
  init: UU,
  insert: GU,
  noop: jU,
  safe_not_equal: VU,
  svg_element: zU,
  text: XU
} = window.__gradio__svelte__internal, {
  SvelteComponent: ZU,
  append: WU,
  attr: JU,
  detach: QU,
  init: YU,
  insert: KU,
  noop: xU,
  safe_not_equal: eG,
  svg_element: tG,
  text: nG
} = window.__gradio__svelte__internal, {
  SvelteComponent: oG,
  append: iG,
  attr: aG,
  detach: lG,
  init: sG,
  insert: _G,
  noop: rG,
  safe_not_equal: uG,
  svg_element: fG
} = window.__gradio__svelte__internal, {
  SvelteComponent: dG,
  append: cG,
  attr: pG,
  detach: mG,
  init: hG,
  insert: $G,
  noop: vG,
  safe_not_equal: gG,
  svg_element: wG
} = window.__gradio__svelte__internal, {
  SvelteComponent: bG,
  create_component: SG,
  destroy_component: CG,
  init: qG,
  mount_component: yG,
  safe_not_equal: kG,
  transition_in: EG,
  transition_out: TG
} = window.__gradio__svelte__internal, { createEventDispatcher: BG } = window.__gradio__svelte__internal, {
  SvelteComponent: HG,
  append: AG,
  attr: NG,
  check_outros: PG,
  create_component: LG,
  destroy_component: IG,
  detach: MG,
  element: OG,
  group_outros: DG,
  init: FG,
  insert: RG,
  mount_component: UG,
  safe_not_equal: GG,
  set_data: jG,
  space: VG,
  text: zG,
  toggle_class: XG,
  transition_in: ZG,
  transition_out: WG
} = window.__gradio__svelte__internal, {
  SvelteComponent: JG,
  attr: QG,
  create_slot: YG,
  detach: KG,
  element: xG,
  get_all_dirty_from_scope: ej,
  get_slot_changes: tj,
  init: nj,
  insert: oj,
  safe_not_equal: ij,
  toggle_class: aj,
  transition_in: lj,
  transition_out: sj,
  update_slot_base: _j
} = window.__gradio__svelte__internal, {
  SvelteComponent: rj,
  append: uj,
  attr: fj,
  check_outros: dj,
  create_component: cj,
  destroy_component: pj,
  detach: mj,
  element: hj,
  empty: $j,
  group_outros: vj,
  init: gj,
  insert: wj,
  listen: bj,
  mount_component: Sj,
  safe_not_equal: Cj,
  space: qj,
  toggle_class: yj,
  transition_in: kj,
  transition_out: Ej
} = window.__gradio__svelte__internal;
function Lt(e) {
  let t = ["", "k", "M", "G", "T", "P", "E", "Z"], n = 0;
  for (; e > 1e3 && n < t.length - 1; )
    e /= 1e3, n++;
  let o = t[n];
  return (Number.isInteger(e) ? e : e.toFixed(1)) + o;
}
const {
  SvelteComponent: Qp,
  append: ke,
  attr: z,
  component_subscribe: $l,
  detach: Yp,
  element: Kp,
  init: xp,
  insert: em,
  noop: vl,
  safe_not_equal: tm,
  set_style: Ln,
  svg_element: Ee,
  toggle_class: gl
} = window.__gradio__svelte__internal, { onMount: nm } = window.__gradio__svelte__internal;
function om(e) {
  let t, n, o, i, a, s, _, l, r, u, f, d;
  return {
    c() {
      t = Kp("div"), n = Ee("svg"), o = Ee("g"), i = Ee("path"), a = Ee("path"), s = Ee("path"), _ = Ee("path"), l = Ee("g"), r = Ee("path"), u = Ee("path"), f = Ee("path"), d = Ee("path"), z(i, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), z(i, "fill", "#FF7C00"), z(i, "fill-opacity", "0.4"), z(i, "class", "svelte-43sxxs"), z(a, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), z(a, "fill", "#FF7C00"), z(a, "class", "svelte-43sxxs"), z(s, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), z(s, "fill", "#FF7C00"), z(s, "fill-opacity", "0.4"), z(s, "class", "svelte-43sxxs"), z(_, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), z(_, "fill", "#FF7C00"), z(_, "class", "svelte-43sxxs"), Ln(o, "transform", "translate(" + /*$top*/
      e[1][0] + "px, " + /*$top*/
      e[1][1] + "px)"), z(r, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), z(r, "fill", "#FF7C00"), z(r, "fill-opacity", "0.4"), z(r, "class", "svelte-43sxxs"), z(u, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), z(u, "fill", "#FF7C00"), z(u, "class", "svelte-43sxxs"), z(f, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), z(f, "fill", "#FF7C00"), z(f, "fill-opacity", "0.4"), z(f, "class", "svelte-43sxxs"), z(d, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), z(d, "fill", "#FF7C00"), z(d, "class", "svelte-43sxxs"), Ln(l, "transform", "translate(" + /*$bottom*/
      e[2][0] + "px, " + /*$bottom*/
      e[2][1] + "px)"), z(n, "viewBox", "-1200 -1200 3000 3000"), z(n, "fill", "none"), z(n, "xmlns", "http://www.w3.org/2000/svg"), z(n, "class", "svelte-43sxxs"), z(t, "class", "svelte-43sxxs"), gl(
        t,
        "margin",
        /*margin*/
        e[0]
      );
    },
    m(c, m) {
      em(c, t, m), ke(t, n), ke(n, o), ke(o, i), ke(o, a), ke(o, s), ke(o, _), ke(n, l), ke(l, r), ke(l, u), ke(l, f), ke(l, d);
    },
    p(c, [m]) {
      m & /*$top*/
      2 && Ln(o, "transform", "translate(" + /*$top*/
      c[1][0] + "px, " + /*$top*/
      c[1][1] + "px)"), m & /*$bottom*/
      4 && Ln(l, "transform", "translate(" + /*$bottom*/
      c[2][0] + "px, " + /*$bottom*/
      c[2][1] + "px)"), m & /*margin*/
      1 && gl(
        t,
        "margin",
        /*margin*/
        c[0]
      );
    },
    i: vl,
    o: vl,
    d(c) {
      c && Yp(t);
    }
  };
}
function im(e, t, n) {
  let o, i, { margin: a = !0 } = t;
  const s = Ut([0, 0]);
  $l(e, s, (d) => n(1, o = d));
  const _ = Ut([0, 0]);
  $l(e, _, (d) => n(2, i = d));
  let l;
  async function r() {
    await Promise.all([s.set([125, 140]), _.set([-125, -140])]), await Promise.all([s.set([-125, 140]), _.set([125, -140])]), await Promise.all([s.set([-125, 0]), _.set([125, -0])]), await Promise.all([s.set([125, 0]), _.set([-125, 0])]);
  }
  async function u() {
    await r(), l || u();
  }
  async function f() {
    await Promise.all([s.set([125, 0]), _.set([-125, 0])]), u();
  }
  return nm(() => (f(), () => l = !0)), e.$$set = (d) => {
    "margin" in d && n(0, a = d.margin);
  }, [a, o, i, s, _];
}
let am = class extends Qp {
  constructor(t) {
    super(), xp(this, t, im, om, tm, { margin: 0 });
  }
};
const {
  SvelteComponent: Bj,
  append: Hj,
  attr: Aj,
  detach: Nj,
  init: Pj,
  insert: Lj,
  noop: Ij,
  safe_not_equal: Mj,
  svg_element: Oj
} = window.__gradio__svelte__internal, {
  SvelteComponent: Dj,
  append: Fj,
  attr: Rj,
  detach: Uj,
  init: Gj,
  insert: jj,
  noop: Vj,
  safe_not_equal: zj,
  svg_element: Xj
} = window.__gradio__svelte__internal, {
  SvelteComponent: Zj,
  append: Wj,
  attr: Jj,
  detach: Qj,
  init: Yj,
  insert: Kj,
  noop: xj,
  safe_not_equal: eV,
  svg_element: tV
} = window.__gradio__svelte__internal, {
  SvelteComponent: nV,
  append: oV,
  attr: iV,
  detach: aV,
  init: lV,
  insert: sV,
  noop: _V,
  safe_not_equal: rV,
  svg_element: uV
} = window.__gradio__svelte__internal, {
  SvelteComponent: fV,
  append: dV,
  attr: cV,
  detach: pV,
  init: mV,
  insert: hV,
  noop: $V,
  safe_not_equal: vV,
  svg_element: gV
} = window.__gradio__svelte__internal, {
  SvelteComponent: wV,
  append: bV,
  attr: SV,
  detach: CV,
  init: qV,
  insert: yV,
  noop: kV,
  safe_not_equal: EV,
  svg_element: TV
} = window.__gradio__svelte__internal, {
  SvelteComponent: BV,
  append: HV,
  attr: AV,
  detach: NV,
  init: PV,
  insert: LV,
  noop: IV,
  safe_not_equal: MV,
  svg_element: OV
} = window.__gradio__svelte__internal, {
  SvelteComponent: DV,
  append: FV,
  attr: RV,
  detach: UV,
  init: GV,
  insert: jV,
  noop: VV,
  safe_not_equal: zV,
  svg_element: XV
} = window.__gradio__svelte__internal, {
  SvelteComponent: lm,
  append: jo,
  attr: Te,
  detach: sm,
  init: _m,
  insert: rm,
  noop: Vo,
  safe_not_equal: um,
  set_style: Oe,
  svg_element: In
} = window.__gradio__svelte__internal;
function fm(e) {
  let t, n, o, i;
  return {
    c() {
      t = In("svg"), n = In("g"), o = In("path"), i = In("path"), Te(o, "d", "M18,6L6.087,17.913"), Oe(o, "fill", "none"), Oe(o, "fill-rule", "nonzero"), Oe(o, "stroke-width", "2px"), Te(n, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), Te(i, "d", "M4.364,4.364L19.636,19.636"), Oe(i, "fill", "none"), Oe(i, "fill-rule", "nonzero"), Oe(i, "stroke-width", "2px"), Te(t, "width", "100%"), Te(t, "height", "100%"), Te(t, "viewBox", "0 0 24 24"), Te(t, "version", "1.1"), Te(t, "xmlns", "http://www.w3.org/2000/svg"), Te(t, "xmlns:xlink", "http://www.w3.org/1999/xlink"), Te(t, "xml:space", "preserve"), Te(t, "stroke", "currentColor"), Oe(t, "fill-rule", "evenodd"), Oe(t, "clip-rule", "evenodd"), Oe(t, "stroke-linecap", "round"), Oe(t, "stroke-linejoin", "round");
    },
    m(a, s) {
      rm(a, t, s), jo(t, n), jo(n, o), jo(t, i);
    },
    p: Vo,
    i: Vo,
    o: Vo,
    d(a) {
      a && sm(t);
    }
  };
}
class dm extends lm {
  constructor(t) {
    super(), _m(this, t, null, fm, um, {});
  }
}
const {
  SvelteComponent: ZV,
  append: WV,
  attr: JV,
  detach: QV,
  init: YV,
  insert: KV,
  noop: xV,
  safe_not_equal: ez,
  svg_element: tz
} = window.__gradio__svelte__internal, {
  SvelteComponent: nz,
  append: oz,
  attr: iz,
  detach: az,
  init: lz,
  insert: sz,
  noop: _z,
  safe_not_equal: rz,
  svg_element: uz
} = window.__gradio__svelte__internal, {
  SvelteComponent: fz,
  append: dz,
  attr: cz,
  detach: pz,
  init: mz,
  insert: hz,
  noop: $z,
  safe_not_equal: vz,
  svg_element: gz
} = window.__gradio__svelte__internal, {
  SvelteComponent: wz,
  append: bz,
  attr: Sz,
  detach: Cz,
  init: qz,
  insert: yz,
  noop: kz,
  safe_not_equal: Ez,
  svg_element: Tz
} = window.__gradio__svelte__internal, {
  SvelteComponent: Bz,
  append: Hz,
  attr: Az,
  detach: Nz,
  init: Pz,
  insert: Lz,
  noop: Iz,
  safe_not_equal: Mz,
  svg_element: Oz
} = window.__gradio__svelte__internal, {
  SvelteComponent: Dz,
  append: Fz,
  attr: Rz,
  detach: Uz,
  init: Gz,
  insert: jz,
  noop: Vz,
  safe_not_equal: zz,
  svg_element: Xz
} = window.__gradio__svelte__internal, {
  SvelteComponent: Zz,
  append: Wz,
  attr: Jz,
  detach: Qz,
  init: Yz,
  insert: Kz,
  noop: xz,
  safe_not_equal: eX,
  svg_element: tX
} = window.__gradio__svelte__internal, {
  SvelteComponent: nX,
  append: oX,
  attr: iX,
  detach: aX,
  init: lX,
  insert: sX,
  noop: _X,
  safe_not_equal: rX,
  svg_element: uX
} = window.__gradio__svelte__internal, {
  SvelteComponent: fX,
  append: dX,
  attr: cX,
  detach: pX,
  init: mX,
  insert: hX,
  noop: $X,
  safe_not_equal: vX,
  svg_element: gX
} = window.__gradio__svelte__internal, {
  SvelteComponent: wX,
  append: bX,
  attr: SX,
  detach: CX,
  init: qX,
  insert: yX,
  noop: kX,
  safe_not_equal: EX,
  svg_element: TX
} = window.__gradio__svelte__internal, {
  SvelteComponent: BX,
  append: HX,
  attr: AX,
  detach: NX,
  init: PX,
  insert: LX,
  noop: IX,
  safe_not_equal: MX,
  svg_element: OX
} = window.__gradio__svelte__internal, {
  SvelteComponent: DX,
  append: FX,
  attr: RX,
  detach: UX,
  init: GX,
  insert: jX,
  noop: VX,
  safe_not_equal: zX,
  svg_element: XX
} = window.__gradio__svelte__internal, {
  SvelteComponent: ZX,
  append: WX,
  attr: JX,
  detach: QX,
  init: YX,
  insert: KX,
  noop: xX,
  safe_not_equal: eZ,
  svg_element: tZ
} = window.__gradio__svelte__internal, {
  SvelteComponent: nZ,
  append: oZ,
  attr: iZ,
  detach: aZ,
  init: lZ,
  insert: sZ,
  noop: _Z,
  safe_not_equal: rZ,
  svg_element: uZ
} = window.__gradio__svelte__internal, {
  SvelteComponent: fZ,
  append: dZ,
  attr: cZ,
  detach: pZ,
  init: mZ,
  insert: hZ,
  noop: $Z,
  safe_not_equal: vZ,
  svg_element: gZ
} = window.__gradio__svelte__internal, {
  SvelteComponent: wZ,
  append: bZ,
  attr: SZ,
  detach: CZ,
  init: qZ,
  insert: yZ,
  noop: kZ,
  safe_not_equal: EZ,
  svg_element: TZ
} = window.__gradio__svelte__internal, {
  SvelteComponent: BZ,
  append: HZ,
  attr: AZ,
  detach: NZ,
  init: PZ,
  insert: LZ,
  noop: IZ,
  safe_not_equal: MZ,
  svg_element: OZ
} = window.__gradio__svelte__internal, {
  SvelteComponent: DZ,
  append: FZ,
  attr: RZ,
  detach: UZ,
  init: GZ,
  insert: jZ,
  noop: VZ,
  safe_not_equal: zZ,
  svg_element: XZ
} = window.__gradio__svelte__internal, {
  SvelteComponent: ZZ,
  append: WZ,
  attr: JZ,
  detach: QZ,
  init: YZ,
  insert: KZ,
  noop: xZ,
  safe_not_equal: eW,
  svg_element: tW
} = window.__gradio__svelte__internal, {
  SvelteComponent: nW,
  append: oW,
  attr: iW,
  detach: aW,
  init: lW,
  insert: sW,
  noop: _W,
  safe_not_equal: rW,
  svg_element: uW
} = window.__gradio__svelte__internal, {
  SvelteComponent: fW,
  append: dW,
  attr: cW,
  detach: pW,
  init: mW,
  insert: hW,
  noop: $W,
  safe_not_equal: vW,
  svg_element: gW
} = window.__gradio__svelte__internal, {
  SvelteComponent: wW,
  append: bW,
  attr: SW,
  detach: CW,
  init: qW,
  insert: yW,
  noop: kW,
  safe_not_equal: EW,
  svg_element: TW
} = window.__gradio__svelte__internal, {
  SvelteComponent: BW,
  append: HW,
  attr: AW,
  detach: NW,
  init: PW,
  insert: LW,
  noop: IW,
  safe_not_equal: MW,
  svg_element: OW
} = window.__gradio__svelte__internal, {
  SvelteComponent: DW,
  append: FW,
  attr: RW,
  detach: UW,
  init: GW,
  insert: jW,
  noop: VW,
  safe_not_equal: zW,
  svg_element: XW
} = window.__gradio__svelte__internal, {
  SvelteComponent: ZW,
  append: WW,
  attr: JW,
  detach: QW,
  init: YW,
  insert: KW,
  noop: xW,
  safe_not_equal: eJ,
  svg_element: tJ
} = window.__gradio__svelte__internal, {
  SvelteComponent: nJ,
  append: oJ,
  attr: iJ,
  detach: aJ,
  init: lJ,
  insert: sJ,
  noop: _J,
  safe_not_equal: rJ,
  svg_element: uJ
} = window.__gradio__svelte__internal, {
  SvelteComponent: fJ,
  append: dJ,
  attr: cJ,
  detach: pJ,
  init: mJ,
  insert: hJ,
  noop: $J,
  safe_not_equal: vJ,
  svg_element: gJ
} = window.__gradio__svelte__internal, {
  SvelteComponent: wJ,
  append: bJ,
  attr: SJ,
  detach: CJ,
  init: qJ,
  insert: yJ,
  noop: kJ,
  safe_not_equal: EJ,
  svg_element: TJ
} = window.__gradio__svelte__internal, {
  SvelteComponent: BJ,
  append: HJ,
  attr: AJ,
  detach: NJ,
  init: PJ,
  insert: LJ,
  noop: IJ,
  safe_not_equal: MJ,
  svg_element: OJ
} = window.__gradio__svelte__internal, {
  SvelteComponent: DJ,
  append: FJ,
  attr: RJ,
  detach: UJ,
  init: GJ,
  insert: jJ,
  noop: VJ,
  safe_not_equal: zJ,
  set_style: XJ,
  svg_element: ZJ
} = window.__gradio__svelte__internal, {
  SvelteComponent: WJ,
  append: JJ,
  attr: QJ,
  detach: YJ,
  init: KJ,
  insert: xJ,
  noop: eQ,
  safe_not_equal: tQ,
  svg_element: nQ
} = window.__gradio__svelte__internal, {
  SvelteComponent: oQ,
  append: iQ,
  attr: aQ,
  detach: lQ,
  init: sQ,
  insert: _Q,
  noop: rQ,
  safe_not_equal: uQ,
  svg_element: fQ
} = window.__gradio__svelte__internal, {
  SvelteComponent: dQ,
  append: cQ,
  attr: pQ,
  detach: mQ,
  init: hQ,
  insert: $Q,
  noop: vQ,
  safe_not_equal: gQ,
  svg_element: wQ
} = window.__gradio__svelte__internal, {
  SvelteComponent: bQ,
  append: SQ,
  attr: CQ,
  detach: qQ,
  init: yQ,
  insert: kQ,
  noop: EQ,
  safe_not_equal: TQ,
  svg_element: BQ
} = window.__gradio__svelte__internal, {
  SvelteComponent: HQ,
  append: AQ,
  attr: NQ,
  detach: PQ,
  init: LQ,
  insert: IQ,
  noop: MQ,
  safe_not_equal: OQ,
  svg_element: DQ
} = window.__gradio__svelte__internal, {
  SvelteComponent: FQ,
  append: RQ,
  attr: UQ,
  detach: GQ,
  init: jQ,
  insert: VQ,
  noop: zQ,
  safe_not_equal: XQ,
  svg_element: ZQ
} = window.__gradio__svelte__internal, {
  SvelteComponent: WQ,
  append: JQ,
  attr: QQ,
  detach: YQ,
  init: KQ,
  insert: xQ,
  noop: eY,
  safe_not_equal: tY,
  svg_element: nY
} = window.__gradio__svelte__internal, {
  SvelteComponent: oY,
  append: iY,
  attr: aY,
  detach: lY,
  init: sY,
  insert: _Y,
  noop: rY,
  safe_not_equal: uY,
  svg_element: fY
} = window.__gradio__svelte__internal, {
  SvelteComponent: dY,
  append: cY,
  attr: pY,
  detach: mY,
  init: hY,
  insert: $Y,
  noop: vY,
  safe_not_equal: gY,
  svg_element: wY,
  text: bY
} = window.__gradio__svelte__internal, {
  SvelteComponent: SY,
  append: CY,
  attr: qY,
  detach: yY,
  init: kY,
  insert: EY,
  noop: TY,
  safe_not_equal: BY,
  svg_element: HY
} = window.__gradio__svelte__internal, {
  SvelteComponent: AY,
  append: NY,
  attr: PY,
  detach: LY,
  init: IY,
  insert: MY,
  noop: OY,
  safe_not_equal: DY,
  svg_element: FY
} = window.__gradio__svelte__internal, {
  SvelteComponent: RY,
  append: UY,
  attr: GY,
  detach: jY,
  init: VY,
  insert: zY,
  noop: XY,
  safe_not_equal: ZY,
  svg_element: WY
} = window.__gradio__svelte__internal, {
  SvelteComponent: JY,
  append: QY,
  attr: YY,
  detach: KY,
  init: xY,
  insert: eK,
  noop: tK,
  safe_not_equal: nK,
  svg_element: oK
} = window.__gradio__svelte__internal, {
  SvelteComponent: iK,
  append: aK,
  attr: lK,
  detach: sK,
  init: _K,
  insert: rK,
  noop: uK,
  safe_not_equal: fK,
  svg_element: dK
} = window.__gradio__svelte__internal, {
  SvelteComponent: cK,
  append: pK,
  attr: mK,
  detach: hK,
  init: $K,
  insert: vK,
  noop: gK,
  safe_not_equal: wK,
  svg_element: bK,
  text: SK
} = window.__gradio__svelte__internal, {
  SvelteComponent: CK,
  append: qK,
  attr: yK,
  detach: kK,
  init: EK,
  insert: TK,
  noop: BK,
  safe_not_equal: HK,
  svg_element: AK,
  text: NK
} = window.__gradio__svelte__internal, {
  SvelteComponent: PK,
  append: LK,
  attr: IK,
  detach: MK,
  init: OK,
  insert: DK,
  noop: FK,
  safe_not_equal: RK,
  svg_element: UK,
  text: GK
} = window.__gradio__svelte__internal, {
  SvelteComponent: jK,
  append: VK,
  attr: zK,
  detach: XK,
  init: ZK,
  insert: WK,
  noop: JK,
  safe_not_equal: QK,
  svg_element: YK
} = window.__gradio__svelte__internal, {
  SvelteComponent: KK,
  append: xK,
  attr: ex,
  detach: tx,
  init: nx,
  insert: ox,
  noop: ix,
  safe_not_equal: ax,
  svg_element: lx
} = window.__gradio__svelte__internal, {
  SvelteComponent: cm,
  append: ht,
  attr: Ne,
  binding_callbacks: wl,
  check_outros: gi,
  create_component: k_,
  create_slot: E_,
  destroy_component: T_,
  destroy_each: B_,
  detach: L,
  element: je,
  empty: xt,
  ensure_array_like: lo,
  get_all_dirty_from_scope: H_,
  get_slot_changes: A_,
  group_outros: wi,
  init: pm,
  insert: I,
  mount_component: N_,
  noop: bi,
  safe_not_equal: mm,
  set_data: Se,
  set_style: lt,
  space: we,
  text: ee,
  toggle_class: ve,
  transition_in: Ae,
  transition_out: Ve,
  update_slot_base: P_
} = window.__gradio__svelte__internal, { tick: hm } = window.__gradio__svelte__internal, { onDestroy: $m } = window.__gradio__svelte__internal, { createEventDispatcher: vm } = window.__gradio__svelte__internal, gm = (e) => ({}), bl = (e) => ({}), wm = (e) => ({}), Sl = (e) => ({});
function Cl(e, t, n) {
  const o = e.slice();
  return o[40] = t[n], o[42] = n, o;
}
function ql(e, t, n) {
  const o = e.slice();
  return o[40] = t[n], o;
}
function bm(e) {
  let t, n, o, i, a = (
    /*i18n*/
    e[1]("common.error") + ""
  ), s, _, l;
  n = new Jp({
    props: {
      Icon: dm,
      label: (
        /*i18n*/
        e[1]("common.clear")
      ),
      disabled: !1
    }
  }), n.$on(
    "click",
    /*click_handler*/
    e[32]
  );
  const r = (
    /*#slots*/
    e[30].error
  ), u = E_(
    r,
    e,
    /*$$scope*/
    e[29],
    bl
  );
  return {
    c() {
      t = je("div"), k_(n.$$.fragment), o = we(), i = je("span"), s = ee(a), _ = we(), u && u.c(), Ne(t, "class", "clear-status svelte-16nch4a"), Ne(i, "class", "error svelte-16nch4a");
    },
    m(f, d) {
      I(f, t, d), N_(n, t, null), I(f, o, d), I(f, i, d), ht(i, s), I(f, _, d), u && u.m(f, d), l = !0;
    },
    p(f, d) {
      const c = {};
      d[0] & /*i18n*/
      2 && (c.label = /*i18n*/
      f[1]("common.clear")), n.$set(c), (!l || d[0] & /*i18n*/
      2) && a !== (a = /*i18n*/
      f[1]("common.error") + "") && Se(s, a), u && u.p && (!l || d[0] & /*$$scope*/
      536870912) && P_(
        u,
        r,
        f,
        /*$$scope*/
        f[29],
        l ? A_(
          r,
          /*$$scope*/
          f[29],
          d,
          gm
        ) : H_(
          /*$$scope*/
          f[29]
        ),
        bl
      );
    },
    i(f) {
      l || (Ae(n.$$.fragment, f), Ae(u, f), l = !0);
    },
    o(f) {
      Ve(n.$$.fragment, f), Ve(u, f), l = !1;
    },
    d(f) {
      f && (L(t), L(o), L(i), L(_)), T_(n), u && u.d(f);
    }
  };
}
function Sm(e) {
  let t, n, o, i, a, s, _, l, r, u = (
    /*variant*/
    e[8] === "default" && /*show_eta_bar*/
    e[18] && /*show_progress*/
    e[6] === "full" && yl(e)
  );
  function f(p, h) {
    if (
      /*progress*/
      p[7]
    ) return ym;
    if (
      /*queue_position*/
      p[2] !== null && /*queue_size*/
      p[3] !== void 0 && /*queue_position*/
      p[2] >= 0
    ) return qm;
    if (
      /*queue_position*/
      p[2] === 0
    ) return Cm;
  }
  let d = f(e), c = d && d(e), m = (
    /*timer*/
    e[5] && Tl(e)
  );
  const w = [Bm, Tm], b = [];
  function v(p, h) {
    return (
      /*last_progress_level*/
      p[15] != null ? 0 : (
        /*show_progress*/
        p[6] === "full" ? 1 : -1
      )
    );
  }
  ~(a = v(e)) && (s = b[a] = w[a](e));
  let g = !/*timer*/
  e[5] && Il(e);
  return {
    c() {
      u && u.c(), t = we(), n = je("div"), c && c.c(), o = we(), m && m.c(), i = we(), s && s.c(), _ = we(), g && g.c(), l = xt(), Ne(n, "class", "progress-text svelte-16nch4a"), ve(
        n,
        "meta-text-center",
        /*variant*/
        e[8] === "center"
      ), ve(
        n,
        "meta-text",
        /*variant*/
        e[8] === "default"
      );
    },
    m(p, h) {
      u && u.m(p, h), I(p, t, h), I(p, n, h), c && c.m(n, null), ht(n, o), m && m.m(n, null), I(p, i, h), ~a && b[a].m(p, h), I(p, _, h), g && g.m(p, h), I(p, l, h), r = !0;
    },
    p(p, h) {
      /*variant*/
      p[8] === "default" && /*show_eta_bar*/
      p[18] && /*show_progress*/
      p[6] === "full" ? u ? u.p(p, h) : (u = yl(p), u.c(), u.m(t.parentNode, t)) : u && (u.d(1), u = null), d === (d = f(p)) && c ? c.p(p, h) : (c && c.d(1), c = d && d(p), c && (c.c(), c.m(n, o))), /*timer*/
      p[5] ? m ? m.p(p, h) : (m = Tl(p), m.c(), m.m(n, null)) : m && (m.d(1), m = null), (!r || h[0] & /*variant*/
      256) && ve(
        n,
        "meta-text-center",
        /*variant*/
        p[8] === "center"
      ), (!r || h[0] & /*variant*/
      256) && ve(
        n,
        "meta-text",
        /*variant*/
        p[8] === "default"
      );
      let S = a;
      a = v(p), a === S ? ~a && b[a].p(p, h) : (s && (wi(), Ve(b[S], 1, 1, () => {
        b[S] = null;
      }), gi()), ~a ? (s = b[a], s ? s.p(p, h) : (s = b[a] = w[a](p), s.c()), Ae(s, 1), s.m(_.parentNode, _)) : s = null), /*timer*/
      p[5] ? g && (wi(), Ve(g, 1, 1, () => {
        g = null;
      }), gi()) : g ? (g.p(p, h), h[0] & /*timer*/
      32 && Ae(g, 1)) : (g = Il(p), g.c(), Ae(g, 1), g.m(l.parentNode, l));
    },
    i(p) {
      r || (Ae(s), Ae(g), r = !0);
    },
    o(p) {
      Ve(s), Ve(g), r = !1;
    },
    d(p) {
      p && (L(t), L(n), L(i), L(_), L(l)), u && u.d(p), c && c.d(), m && m.d(), ~a && b[a].d(p), g && g.d(p);
    }
  };
}
function yl(e) {
  let t, n = `translateX(${/*eta_level*/
  (e[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      t = je("div"), Ne(t, "class", "eta-bar svelte-16nch4a"), lt(t, "transform", n);
    },
    m(o, i) {
      I(o, t, i);
    },
    p(o, i) {
      i[0] & /*eta_level*/
      131072 && n !== (n = `translateX(${/*eta_level*/
      (o[17] || 0) * 100 - 100}%)`) && lt(t, "transform", n);
    },
    d(o) {
      o && L(t);
    }
  };
}
function Cm(e) {
  let t;
  return {
    c() {
      t = ee("processing |");
    },
    m(n, o) {
      I(n, t, o);
    },
    p: bi,
    d(n) {
      n && L(t);
    }
  };
}
function qm(e) {
  let t, n = (
    /*queue_position*/
    e[2] + 1 + ""
  ), o, i, a, s;
  return {
    c() {
      t = ee("queue: "), o = ee(n), i = ee("/"), a = ee(
        /*queue_size*/
        e[3]
      ), s = ee(" |");
    },
    m(_, l) {
      I(_, t, l), I(_, o, l), I(_, i, l), I(_, a, l), I(_, s, l);
    },
    p(_, l) {
      l[0] & /*queue_position*/
      4 && n !== (n = /*queue_position*/
      _[2] + 1 + "") && Se(o, n), l[0] & /*queue_size*/
      8 && Se(
        a,
        /*queue_size*/
        _[3]
      );
    },
    d(_) {
      _ && (L(t), L(o), L(i), L(a), L(s));
    }
  };
}
function ym(e) {
  let t, n = lo(
    /*progress*/
    e[7]
  ), o = [];
  for (let i = 0; i < n.length; i += 1)
    o[i] = El(ql(e, n, i));
  return {
    c() {
      for (let i = 0; i < o.length; i += 1)
        o[i].c();
      t = xt();
    },
    m(i, a) {
      for (let s = 0; s < o.length; s += 1)
        o[s] && o[s].m(i, a);
      I(i, t, a);
    },
    p(i, a) {
      if (a[0] & /*progress*/
      128) {
        n = lo(
          /*progress*/
          i[7]
        );
        let s;
        for (s = 0; s < n.length; s += 1) {
          const _ = ql(i, n, s);
          o[s] ? o[s].p(_, a) : (o[s] = El(_), o[s].c(), o[s].m(t.parentNode, t));
        }
        for (; s < o.length; s += 1)
          o[s].d(1);
        o.length = n.length;
      }
    },
    d(i) {
      i && L(t), B_(o, i);
    }
  };
}
function kl(e) {
  let t, n = (
    /*p*/
    e[40].unit + ""
  ), o, i, a = " ", s;
  function _(u, f) {
    return (
      /*p*/
      u[40].length != null ? Em : km
    );
  }
  let l = _(e), r = l(e);
  return {
    c() {
      r.c(), t = we(), o = ee(n), i = ee(" | "), s = ee(a);
    },
    m(u, f) {
      r.m(u, f), I(u, t, f), I(u, o, f), I(u, i, f), I(u, s, f);
    },
    p(u, f) {
      l === (l = _(u)) && r ? r.p(u, f) : (r.d(1), r = l(u), r && (r.c(), r.m(t.parentNode, t))), f[0] & /*progress*/
      128 && n !== (n = /*p*/
      u[40].unit + "") && Se(o, n);
    },
    d(u) {
      u && (L(t), L(o), L(i), L(s)), r.d(u);
    }
  };
}
function km(e) {
  let t = Lt(
    /*p*/
    e[40].index || 0
  ) + "", n;
  return {
    c() {
      n = ee(t);
    },
    m(o, i) {
      I(o, n, i);
    },
    p(o, i) {
      i[0] & /*progress*/
      128 && t !== (t = Lt(
        /*p*/
        o[40].index || 0
      ) + "") && Se(n, t);
    },
    d(o) {
      o && L(n);
    }
  };
}
function Em(e) {
  let t = Lt(
    /*p*/
    e[40].index || 0
  ) + "", n, o, i = Lt(
    /*p*/
    e[40].length
  ) + "", a;
  return {
    c() {
      n = ee(t), o = ee("/"), a = ee(i);
    },
    m(s, _) {
      I(s, n, _), I(s, o, _), I(s, a, _);
    },
    p(s, _) {
      _[0] & /*progress*/
      128 && t !== (t = Lt(
        /*p*/
        s[40].index || 0
      ) + "") && Se(n, t), _[0] & /*progress*/
      128 && i !== (i = Lt(
        /*p*/
        s[40].length
      ) + "") && Se(a, i);
    },
    d(s) {
      s && (L(n), L(o), L(a));
    }
  };
}
function El(e) {
  let t, n = (
    /*p*/
    e[40].index != null && kl(e)
  );
  return {
    c() {
      n && n.c(), t = xt();
    },
    m(o, i) {
      n && n.m(o, i), I(o, t, i);
    },
    p(o, i) {
      /*p*/
      o[40].index != null ? n ? n.p(o, i) : (n = kl(o), n.c(), n.m(t.parentNode, t)) : n && (n.d(1), n = null);
    },
    d(o) {
      o && L(t), n && n.d(o);
    }
  };
}
function Tl(e) {
  let t, n = (
    /*eta*/
    e[0] ? `/${/*formatted_eta*/
    e[19]}` : ""
  ), o, i;
  return {
    c() {
      t = ee(
        /*formatted_timer*/
        e[20]
      ), o = ee(n), i = ee("s");
    },
    m(a, s) {
      I(a, t, s), I(a, o, s), I(a, i, s);
    },
    p(a, s) {
      s[0] & /*formatted_timer*/
      1048576 && Se(
        t,
        /*formatted_timer*/
        a[20]
      ), s[0] & /*eta, formatted_eta*/
      524289 && n !== (n = /*eta*/
      a[0] ? `/${/*formatted_eta*/
      a[19]}` : "") && Se(o, n);
    },
    d(a) {
      a && (L(t), L(o), L(i));
    }
  };
}
function Tm(e) {
  let t, n;
  return t = new am({
    props: { margin: (
      /*variant*/
      e[8] === "default"
    ) }
  }), {
    c() {
      k_(t.$$.fragment);
    },
    m(o, i) {
      N_(t, o, i), n = !0;
    },
    p(o, i) {
      const a = {};
      i[0] & /*variant*/
      256 && (a.margin = /*variant*/
      o[8] === "default"), t.$set(a);
    },
    i(o) {
      n || (Ae(t.$$.fragment, o), n = !0);
    },
    o(o) {
      Ve(t.$$.fragment, o), n = !1;
    },
    d(o) {
      T_(t, o);
    }
  };
}
function Bm(e) {
  let t, n, o, i, a, s = `${/*last_progress_level*/
  e[15] * 100}%`, _ = (
    /*progress*/
    e[7] != null && Bl(e)
  );
  return {
    c() {
      t = je("div"), n = je("div"), _ && _.c(), o = we(), i = je("div"), a = je("div"), Ne(n, "class", "progress-level-inner svelte-16nch4a"), Ne(a, "class", "progress-bar svelte-16nch4a"), lt(a, "width", s), Ne(i, "class", "progress-bar-wrap svelte-16nch4a"), Ne(t, "class", "progress-level svelte-16nch4a");
    },
    m(l, r) {
      I(l, t, r), ht(t, n), _ && _.m(n, null), ht(t, o), ht(t, i), ht(i, a), e[31](a);
    },
    p(l, r) {
      /*progress*/
      l[7] != null ? _ ? _.p(l, r) : (_ = Bl(l), _.c(), _.m(n, null)) : _ && (_.d(1), _ = null), r[0] & /*last_progress_level*/
      32768 && s !== (s = `${/*last_progress_level*/
      l[15] * 100}%`) && lt(a, "width", s);
    },
    i: bi,
    o: bi,
    d(l) {
      l && L(t), _ && _.d(), e[31](null);
    }
  };
}
function Bl(e) {
  let t, n = lo(
    /*progress*/
    e[7]
  ), o = [];
  for (let i = 0; i < n.length; i += 1)
    o[i] = Ll(Cl(e, n, i));
  return {
    c() {
      for (let i = 0; i < o.length; i += 1)
        o[i].c();
      t = xt();
    },
    m(i, a) {
      for (let s = 0; s < o.length; s += 1)
        o[s] && o[s].m(i, a);
      I(i, t, a);
    },
    p(i, a) {
      if (a[0] & /*progress_level, progress*/
      16512) {
        n = lo(
          /*progress*/
          i[7]
        );
        let s;
        for (s = 0; s < n.length; s += 1) {
          const _ = Cl(i, n, s);
          o[s] ? o[s].p(_, a) : (o[s] = Ll(_), o[s].c(), o[s].m(t.parentNode, t));
        }
        for (; s < o.length; s += 1)
          o[s].d(1);
        o.length = n.length;
      }
    },
    d(i) {
      i && L(t), B_(o, i);
    }
  };
}
function Hl(e) {
  let t, n, o, i, a = (
    /*i*/
    e[42] !== 0 && Hm()
  ), s = (
    /*p*/
    e[40].desc != null && Al(e)
  ), _ = (
    /*p*/
    e[40].desc != null && /*progress_level*/
    e[14] && /*progress_level*/
    e[14][
      /*i*/
      e[42]
    ] != null && Nl()
  ), l = (
    /*progress_level*/
    e[14] != null && Pl(e)
  );
  return {
    c() {
      a && a.c(), t = we(), s && s.c(), n = we(), _ && _.c(), o = we(), l && l.c(), i = xt();
    },
    m(r, u) {
      a && a.m(r, u), I(r, t, u), s && s.m(r, u), I(r, n, u), _ && _.m(r, u), I(r, o, u), l && l.m(r, u), I(r, i, u);
    },
    p(r, u) {
      /*p*/
      r[40].desc != null ? s ? s.p(r, u) : (s = Al(r), s.c(), s.m(n.parentNode, n)) : s && (s.d(1), s = null), /*p*/
      r[40].desc != null && /*progress_level*/
      r[14] && /*progress_level*/
      r[14][
        /*i*/
        r[42]
      ] != null ? _ || (_ = Nl(), _.c(), _.m(o.parentNode, o)) : _ && (_.d(1), _ = null), /*progress_level*/
      r[14] != null ? l ? l.p(r, u) : (l = Pl(r), l.c(), l.m(i.parentNode, i)) : l && (l.d(1), l = null);
    },
    d(r) {
      r && (L(t), L(n), L(o), L(i)), a && a.d(r), s && s.d(r), _ && _.d(r), l && l.d(r);
    }
  };
}
function Hm(e) {
  let t;
  return {
    c() {
      t = ee(" /");
    },
    m(n, o) {
      I(n, t, o);
    },
    d(n) {
      n && L(t);
    }
  };
}
function Al(e) {
  let t = (
    /*p*/
    e[40].desc + ""
  ), n;
  return {
    c() {
      n = ee(t);
    },
    m(o, i) {
      I(o, n, i);
    },
    p(o, i) {
      i[0] & /*progress*/
      128 && t !== (t = /*p*/
      o[40].desc + "") && Se(n, t);
    },
    d(o) {
      o && L(n);
    }
  };
}
function Nl(e) {
  let t;
  return {
    c() {
      t = ee("-");
    },
    m(n, o) {
      I(n, t, o);
    },
    d(n) {
      n && L(t);
    }
  };
}
function Pl(e) {
  let t = (100 * /*progress_level*/
  (e[14][
    /*i*/
    e[42]
  ] || 0)).toFixed(1) + "", n, o;
  return {
    c() {
      n = ee(t), o = ee("%");
    },
    m(i, a) {
      I(i, n, a), I(i, o, a);
    },
    p(i, a) {
      a[0] & /*progress_level*/
      16384 && t !== (t = (100 * /*progress_level*/
      (i[14][
        /*i*/
        i[42]
      ] || 0)).toFixed(1) + "") && Se(n, t);
    },
    d(i) {
      i && (L(n), L(o));
    }
  };
}
function Ll(e) {
  let t, n = (
    /*p*/
    (e[40].desc != null || /*progress_level*/
    e[14] && /*progress_level*/
    e[14][
      /*i*/
      e[42]
    ] != null) && Hl(e)
  );
  return {
    c() {
      n && n.c(), t = xt();
    },
    m(o, i) {
      n && n.m(o, i), I(o, t, i);
    },
    p(o, i) {
      /*p*/
      o[40].desc != null || /*progress_level*/
      o[14] && /*progress_level*/
      o[14][
        /*i*/
        o[42]
      ] != null ? n ? n.p(o, i) : (n = Hl(o), n.c(), n.m(t.parentNode, t)) : n && (n.d(1), n = null);
    },
    d(o) {
      o && L(t), n && n.d(o);
    }
  };
}
function Il(e) {
  let t, n, o, i;
  const a = (
    /*#slots*/
    e[30]["additional-loading-text"]
  ), s = E_(
    a,
    e,
    /*$$scope*/
    e[29],
    Sl
  );
  return {
    c() {
      t = je("p"), n = ee(
        /*loading_text*/
        e[9]
      ), o = we(), s && s.c(), Ne(t, "class", "loading svelte-16nch4a");
    },
    m(_, l) {
      I(_, t, l), ht(t, n), I(_, o, l), s && s.m(_, l), i = !0;
    },
    p(_, l) {
      (!i || l[0] & /*loading_text*/
      512) && Se(
        n,
        /*loading_text*/
        _[9]
      ), s && s.p && (!i || l[0] & /*$$scope*/
      536870912) && P_(
        s,
        a,
        _,
        /*$$scope*/
        _[29],
        i ? A_(
          a,
          /*$$scope*/
          _[29],
          l,
          wm
        ) : H_(
          /*$$scope*/
          _[29]
        ),
        Sl
      );
    },
    i(_) {
      i || (Ae(s, _), i = !0);
    },
    o(_) {
      Ve(s, _), i = !1;
    },
    d(_) {
      _ && (L(t), L(o)), s && s.d(_);
    }
  };
}
function Am(e) {
  let t, n, o, i, a;
  const s = [Sm, bm], _ = [];
  function l(r, u) {
    return (
      /*status*/
      r[4] === "pending" ? 0 : (
        /*status*/
        r[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(n = l(e)) && (o = _[n] = s[n](e)), {
    c() {
      t = je("div"), o && o.c(), Ne(t, "class", i = "wrap " + /*variant*/
      e[8] + " " + /*show_progress*/
      e[6] + " svelte-16nch4a"), ve(t, "hide", !/*status*/
      e[4] || /*status*/
      e[4] === "complete" || /*show_progress*/
      e[6] === "hidden"), ve(
        t,
        "translucent",
        /*variant*/
        e[8] === "center" && /*status*/
        (e[4] === "pending" || /*status*/
        e[4] === "error") || /*translucent*/
        e[11] || /*show_progress*/
        e[6] === "minimal"
      ), ve(
        t,
        "generating",
        /*status*/
        e[4] === "generating"
      ), ve(
        t,
        "border",
        /*border*/
        e[12]
      ), lt(
        t,
        "position",
        /*absolute*/
        e[10] ? "absolute" : "static"
      ), lt(
        t,
        "padding",
        /*absolute*/
        e[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(r, u) {
      I(r, t, u), ~n && _[n].m(t, null), e[33](t), a = !0;
    },
    p(r, u) {
      let f = n;
      n = l(r), n === f ? ~n && _[n].p(r, u) : (o && (wi(), Ve(_[f], 1, 1, () => {
        _[f] = null;
      }), gi()), ~n ? (o = _[n], o ? o.p(r, u) : (o = _[n] = s[n](r), o.c()), Ae(o, 1), o.m(t, null)) : o = null), (!a || u[0] & /*variant, show_progress*/
      320 && i !== (i = "wrap " + /*variant*/
      r[8] + " " + /*show_progress*/
      r[6] + " svelte-16nch4a")) && Ne(t, "class", i), (!a || u[0] & /*variant, show_progress, status, show_progress*/
      336) && ve(t, "hide", !/*status*/
      r[4] || /*status*/
      r[4] === "complete" || /*show_progress*/
      r[6] === "hidden"), (!a || u[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && ve(
        t,
        "translucent",
        /*variant*/
        r[8] === "center" && /*status*/
        (r[4] === "pending" || /*status*/
        r[4] === "error") || /*translucent*/
        r[11] || /*show_progress*/
        r[6] === "minimal"
      ), (!a || u[0] & /*variant, show_progress, status*/
      336) && ve(
        t,
        "generating",
        /*status*/
        r[4] === "generating"
      ), (!a || u[0] & /*variant, show_progress, border*/
      4416) && ve(
        t,
        "border",
        /*border*/
        r[12]
      ), u[0] & /*absolute*/
      1024 && lt(
        t,
        "position",
        /*absolute*/
        r[10] ? "absolute" : "static"
      ), u[0] & /*absolute*/
      1024 && lt(
        t,
        "padding",
        /*absolute*/
        r[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(r) {
      a || (Ae(o), a = !0);
    },
    o(r) {
      Ve(o), a = !1;
    },
    d(r) {
      r && L(t), ~n && _[n].d(), e[33](null);
    }
  };
}
let Mn = [], zo = !1;
async function Nm(e, t = !0) {
  if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && t !== !0)) {
    if (Mn.push(e), !zo) zo = !0;
    else return;
    await hm(), requestAnimationFrame(() => {
      let n = [0, 0];
      for (let o = 0; o < Mn.length; o++) {
        const a = Mn[o].getBoundingClientRect();
        (o === 0 || a.top + window.scrollY <= n[0]) && (n[0] = a.top + window.scrollY, n[1] = o);
      }
      window.scrollTo({ top: n[0] - 20, behavior: "smooth" }), zo = !1, Mn = [];
    });
  }
}
function Pm(e, t, n) {
  let o, { $$slots: i = {}, $$scope: a } = t;
  const s = vm();
  let { i18n: _ } = t, { eta: l = null } = t, { queue_position: r } = t, { queue_size: u } = t, { status: f } = t, { scroll_to_output: d = !1 } = t, { timer: c = !0 } = t, { show_progress: m = "full" } = t, { message: w = null } = t, { progress: b = null } = t, { variant: v = "default" } = t, { loading_text: g = "Loading..." } = t, { absolute: p = !0 } = t, { translucent: h = !1 } = t, { border: S = !1 } = t, { autoscroll: $ } = t, y, C = !1, T = 0, P = 0, E = null, Y = null, R = 0, Z = null, U, H = null, Q = !0;
  const A = () => {
    n(0, l = n(27, E = n(19, Le = null))), n(25, T = performance.now()), n(26, P = 0), C = !0, ae();
  };
  function ae() {
    requestAnimationFrame(() => {
      n(26, P = (performance.now() - T) / 1e3), C && ae();
    });
  }
  function B() {
    n(26, P = 0), n(0, l = n(27, E = n(19, Le = null))), C && (C = !1);
  }
  $m(() => {
    C && B();
  });
  let Le = null;
  function _t(N) {
    wl[N ? "unshift" : "push"](() => {
      H = N, n(16, H), n(7, b), n(14, Z), n(15, U);
    });
  }
  const q = () => {
    s("clear_status");
  };
  function ko(N) {
    wl[N ? "unshift" : "push"](() => {
      y = N, n(13, y);
    });
  }
  return e.$$set = (N) => {
    "i18n" in N && n(1, _ = N.i18n), "eta" in N && n(0, l = N.eta), "queue_position" in N && n(2, r = N.queue_position), "queue_size" in N && n(3, u = N.queue_size), "status" in N && n(4, f = N.status), "scroll_to_output" in N && n(22, d = N.scroll_to_output), "timer" in N && n(5, c = N.timer), "show_progress" in N && n(6, m = N.show_progress), "message" in N && n(23, w = N.message), "progress" in N && n(7, b = N.progress), "variant" in N && n(8, v = N.variant), "loading_text" in N && n(9, g = N.loading_text), "absolute" in N && n(10, p = N.absolute), "translucent" in N && n(11, h = N.translucent), "border" in N && n(12, S = N.border), "autoscroll" in N && n(24, $ = N.autoscroll), "$$scope" in N && n(29, a = N.$$scope);
  }, e.$$.update = () => {
    e.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    436207617 && (l === null && n(0, l = E), l != null && E !== l && (n(28, Y = (performance.now() - T) / 1e3 + l), n(19, Le = Y.toFixed(1)), n(27, E = l))), e.$$.dirty[0] & /*eta_from_start, timer_diff*/
    335544320 && n(17, R = Y === null || Y <= 0 || !P ? null : Math.min(P / Y, 1)), e.$$.dirty[0] & /*progress*/
    128 && b != null && n(18, Q = !1), e.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (b != null ? n(14, Z = b.map((N) => {
      if (N.index != null && N.length != null)
        return N.index / N.length;
      if (N.progress != null)
        return N.progress;
    })) : n(14, Z = null), Z ? (n(15, U = Z[Z.length - 1]), H && (U === 0 ? n(16, H.style.transition = "0", H) : n(16, H.style.transition = "150ms", H))) : n(15, U = void 0)), e.$$.dirty[0] & /*status*/
    16 && (f === "pending" ? A() : B()), e.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    20979728 && y && d && (f === "pending" || f === "complete") && Nm(y, $), e.$$.dirty[0] & /*status, message*/
    8388624, e.$$.dirty[0] & /*timer_diff*/
    67108864 && n(20, o = P.toFixed(1));
  }, [
    l,
    _,
    r,
    u,
    f,
    c,
    m,
    b,
    v,
    g,
    p,
    h,
    S,
    y,
    Z,
    U,
    H,
    R,
    Q,
    Le,
    o,
    s,
    d,
    w,
    $,
    T,
    P,
    E,
    Y,
    a,
    i,
    _t,
    q,
    ko
  ];
}
let Lm = class extends cm {
  constructor(t) {
    super(), pm(
      this,
      t,
      Pm,
      Am,
      mm,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 22,
        timer: 5,
        show_progress: 6,
        message: 23,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 24
      },
      null,
      [-1, -1]
    );
  }
};
const {
  SvelteComponent: _x,
  add_render_callback: rx,
  append: ux,
  attr: fx,
  bubble: dx,
  check_outros: cx,
  create_component: px,
  create_in_transition: mx,
  create_out_transition: hx,
  destroy_component: $x,
  detach: vx,
  element: gx,
  group_outros: wx,
  init: bx,
  insert: Sx,
  listen: Cx,
  mount_component: qx,
  run_all: yx,
  safe_not_equal: kx,
  set_data: Ex,
  space: Tx,
  stop_propagation: Bx,
  text: Hx,
  transition_in: Ax,
  transition_out: Nx
} = window.__gradio__svelte__internal, { createEventDispatcher: Px, onMount: Lx } = window.__gradio__svelte__internal, {
  SvelteComponent: Ix,
  append: Mx,
  attr: Ox,
  bubble: Dx,
  check_outros: Fx,
  create_animation: Rx,
  create_component: Ux,
  destroy_component: Gx,
  detach: jx,
  element: Vx,
  ensure_array_like: zx,
  fix_and_outro_and_destroy_block: Xx,
  fix_position: Zx,
  group_outros: Wx,
  init: Jx,
  insert: Qx,
  mount_component: Yx,
  noop: Kx,
  safe_not_equal: xx,
  set_style: eee,
  space: tee,
  transition_in: nee,
  transition_out: oee,
  update_keyed_each: iee
} = window.__gradio__svelte__internal, {
  SvelteComponent: Im,
  append: On,
  attr: Et,
  detach: Mm,
  element: Xo,
  init: Om,
  insert: Dm,
  listen: Zo,
  noop: Ml,
  run_all: Fm,
  safe_not_equal: Rm,
  set_data: Um,
  space: Gm,
  text: jm,
  toggle_class: Ol
} = window.__gradio__svelte__internal, { createEventDispatcher: Vm } = window.__gradio__svelte__internal;
function zm(e) {
  let t, n, o, i, a, s, _;
  return {
    c() {
      t = Xo("label"), n = Xo("input"), o = Gm(), i = Xo("span"), a = jm(
        /*label*/
        e[1]
      ), n.disabled = /*disabled*/
      e[2], Et(n, "type", "checkbox"), Et(n, "name", "test"), Et(n, "data-testid", "checkbox"), Et(n, "class", "svelte-15y2hcz"), Et(i, "class", "ml-2 svelte-15y2hcz"), Et(t, "class", "svelte-15y2hcz"), Ol(
        t,
        "disabled",
        /*disabled*/
        e[2]
      );
    },
    m(l, r) {
      Dm(l, t, r), On(t, n), n.checked = /*value*/
      e[0], On(t, o), On(t, i), On(i, a), s || (_ = [
        Zo(
          n,
          "change",
          /*input_change_handler*/
          e[6]
        ),
        Zo(
          n,
          "keydown",
          /*handle_enter*/
          e[3]
        ),
        Zo(
          n,
          "input",
          /*handle_input*/
          e[4]
        )
      ], s = !0);
    },
    p(l, [r]) {
      r & /*disabled*/
      4 && (n.disabled = /*disabled*/
      l[2]), r & /*value*/
      1 && (n.checked = /*value*/
      l[0]), r & /*label*/
      2 && Um(
        a,
        /*label*/
        l[1]
      ), r & /*disabled*/
      4 && Ol(
        t,
        "disabled",
        /*disabled*/
        l[2]
      );
    },
    i: Ml,
    o: Ml,
    d(l) {
      l && Mm(t), s = !1, Fm(_);
    }
  };
}
function Xm(e, t, n) {
  let o, { value: i = !1 } = t, { label: a = "Checkbox" } = t, { interactive: s } = t;
  const _ = Vm();
  async function l(f) {
    f.key === "Enter" && (n(0, i = !i), _("select", {
      index: 0,
      value: f.currentTarget.checked,
      selected: f.currentTarget.checked
    }));
  }
  async function r(f) {
    n(0, i = f.currentTarget.checked), _("select", {
      index: 0,
      value: f.currentTarget.checked,
      selected: f.currentTarget.checked
    });
  }
  function u() {
    i = this.checked, n(0, i);
  }
  return e.$$set = (f) => {
    "value" in f && n(0, i = f.value), "label" in f && n(1, a = f.label), "interactive" in f && n(5, s = f.interactive);
  }, e.$$.update = () => {
    e.$$.dirty & /*value*/
    1 && _("change", i), e.$$.dirty & /*interactive*/
    32 && n(2, o = !s);
  }, [
    i,
    a,
    o,
    l,
    r,
    s,
    u
  ];
}
class Zm extends Im {
  constructor(t) {
    super(), Om(this, t, Xm, zm, Rm, { value: 0, label: 1, interactive: 5 });
  }
}
const {
  SvelteComponent: Wm,
  add_flush_callback: Jm,
  assign: Qm,
  bind: Ym,
  binding_callbacks: Km,
  check_outros: xm,
  create_component: so,
  destroy_component: _o,
  detach: Si,
  get_spread_object: eh,
  get_spread_update: th,
  group_outros: nh,
  init: oh,
  insert: Ci,
  mount_component: ro,
  safe_not_equal: ih,
  set_data: ah,
  space: Dl,
  text: lh,
  transition_in: pt,
  transition_out: It
} = window.__gradio__svelte__internal, { afterUpdate: sh } = window.__gradio__svelte__internal;
function Fl(e) {
  let t, n;
  return t = new Pp({
    props: {
      $$slots: { default: [_h] },
      $$scope: { ctx: e }
    }
  }), {
    c() {
      so(t.$$.fragment);
    },
    m(o, i) {
      ro(t, o, i), n = !0;
    },
    p(o, i) {
      const a = {};
      i & /*$$scope, info*/
      131104 && (a.$$scope = { dirty: i, ctx: o }), t.$set(a);
    },
    i(o) {
      n || (pt(t.$$.fragment, o), n = !0);
    },
    o(o) {
      It(t.$$.fragment, o), n = !1;
    },
    d(o) {
      _o(t, o);
    }
  };
}
function _h(e) {
  let t;
  return {
    c() {
      t = lh(
        /*info*/
        e[5]
      );
    },
    m(n, o) {
      Ci(n, t, o);
    },
    p(n, o) {
      o & /*info*/
      32 && ah(
        t,
        /*info*/
        n[5]
      );
    },
    d(n) {
      n && Si(t);
    }
  };
}
function rh(e) {
  let t, n, o, i, a, s;
  const _ = [
    {
      autoscroll: (
        /*gradio*/
        e[10].autoscroll
      )
    },
    { i18n: (
      /*gradio*/
      e[10].i18n
    ) },
    /*loading_status*/
    e[9]
  ];
  let l = {};
  for (let d = 0; d < _.length; d += 1)
    l = Qm(l, _[d]);
  t = new Lm({ props: l }), t.$on(
    "clear_status",
    /*clear_status_handler*/
    e[14]
  );
  let r = (
    /*info*/
    e[5] && Fl(e)
  );
  function u(d) {
    e[15](d);
  }
  let f = {
    label: (
      /*label*/
      e[4]
    ),
    interactive: (
      /*interactive*/
      e[11]
    )
  };
  return (
    /*value*/
    e[0] !== void 0 && (f.value = /*value*/
    e[0]), i = new Zm({ props: f }), Km.push(() => Ym(i, "value", u)), i.$on(
      "change",
      /*handle_change*/
      e[12]
    ), i.$on(
      "select",
      /*select_handler*/
      e[16]
    ), {
      c() {
        so(t.$$.fragment), n = Dl(), r && r.c(), o = Dl(), so(i.$$.fragment);
      },
      m(d, c) {
        ro(t, d, c), Ci(d, n, c), r && r.m(d, c), Ci(d, o, c), ro(i, d, c), s = !0;
      },
      p(d, c) {
        const m = c & /*gradio, loading_status*/
        1536 ? th(_, [
          c & /*gradio*/
          1024 && {
            autoscroll: (
              /*gradio*/
              d[10].autoscroll
            )
          },
          c & /*gradio*/
          1024 && { i18n: (
            /*gradio*/
            d[10].i18n
          ) },
          c & /*loading_status*/
          512 && eh(
            /*loading_status*/
            d[9]
          )
        ]) : {};
        t.$set(m), /*info*/
        d[5] ? r ? (r.p(d, c), c & /*info*/
        32 && pt(r, 1)) : (r = Fl(d), r.c(), pt(r, 1), r.m(o.parentNode, o)) : r && (nh(), It(r, 1, 1, () => {
          r = null;
        }), xm());
        const w = {};
        c & /*label*/
        16 && (w.label = /*label*/
        d[4]), c & /*interactive*/
        2048 && (w.interactive = /*interactive*/
        d[11]), !a && c & /*value*/
        1 && (a = !0, w.value = /*value*/
        d[0], Jm(() => a = !1)), i.$set(w);
      },
      i(d) {
        s || (pt(t.$$.fragment, d), pt(r), pt(i.$$.fragment, d), s = !0);
      },
      o(d) {
        It(t.$$.fragment, d), It(r), It(i.$$.fragment, d), s = !1;
      },
      d(d) {
        d && (Si(n), Si(o)), _o(t, d), r && r.d(d), _o(i, d);
      }
    }
  );
}
function uh(e) {
  let t, n;
  return t = new $p({
    props: {
      visible: (
        /*visible*/
        e[3]
      ),
      elem_id: (
        /*elem_id*/
        e[1]
      ),
      elem_classes: (
        /*elem_classes*/
        e[2]
      ),
      container: (
        /*container*/
        e[6]
      ),
      scale: (
        /*scale*/
        e[7]
      ),
      min_width: (
        /*min_width*/
        e[8]
      ),
      $$slots: { default: [rh] },
      $$scope: { ctx: e }
    }
  }), {
    c() {
      so(t.$$.fragment);
    },
    m(o, i) {
      ro(t, o, i), n = !0;
    },
    p(o, [i]) {
      const a = {};
      i & /*visible*/
      8 && (a.visible = /*visible*/
      o[3]), i & /*elem_id*/
      2 && (a.elem_id = /*elem_id*/
      o[1]), i & /*elem_classes*/
      4 && (a.elem_classes = /*elem_classes*/
      o[2]), i & /*container*/
      64 && (a.container = /*container*/
      o[6]), i & /*scale*/
      128 && (a.scale = /*scale*/
      o[7]), i & /*min_width*/
      256 && (a.min_width = /*min_width*/
      o[8]), i & /*$$scope, label, interactive, value, gradio, info, loading_status*/
      134705 && (a.$$scope = { dirty: i, ctx: o }), t.$set(a);
    },
    i(o) {
      n || (pt(t.$$.fragment, o), n = !0);
    },
    o(o) {
      It(t.$$.fragment, o), n = !1;
    },
    d(o) {
      _o(t, o);
    }
  };
}
function fh(e, t, n) {
  let { elem_id: o = "" } = t, { elem_classes: i = [] } = t, { visible: a = !0 } = t, { value: s = !1 } = t, { value_is_output: _ = !1 } = t, { label: l = "Checkbox" } = t, { info: r = void 0 } = t, { container: u = !0 } = t, { scale: f = null } = t, { min_width: d = void 0 } = t, { loading_status: c } = t, { gradio: m } = t, { interactive: w } = t;
  function b() {
    m.dispatch("change"), _ || m.dispatch("input");
  }
  sh(() => {
    n(13, _ = !1);
  });
  const v = () => m.dispatch("clear_status", c);
  function g(h) {
    s = h, n(0, s);
  }
  const p = (h) => m.dispatch("select", h.detail);
  return e.$$set = (h) => {
    "elem_id" in h && n(1, o = h.elem_id), "elem_classes" in h && n(2, i = h.elem_classes), "visible" in h && n(3, a = h.visible), "value" in h && n(0, s = h.value), "value_is_output" in h && n(13, _ = h.value_is_output), "label" in h && n(4, l = h.label), "info" in h && n(5, r = h.info), "container" in h && n(6, u = h.container), "scale" in h && n(7, f = h.scale), "min_width" in h && n(8, d = h.min_width), "loading_status" in h && n(9, c = h.loading_status), "gradio" in h && n(10, m = h.gradio), "interactive" in h && n(11, w = h.interactive);
  }, [
    s,
    o,
    i,
    a,
    l,
    r,
    u,
    f,
    d,
    c,
    m,
    w,
    b,
    _,
    v,
    g,
    p
  ];
}
let dh = class extends Wm {
  constructor(t) {
    super(), oh(this, t, fh, uh, ih, {
      elem_id: 1,
      elem_classes: 2,
      visible: 3,
      value: 0,
      value_is_output: 13,
      label: 4,
      info: 5,
      container: 6,
      scale: 7,
      min_width: 8,
      loading_status: 9,
      gradio: 10,
      interactive: 11
    });
  }
};
const {
  SvelteComponent: ch,
  assign: ph,
  create_slot: mh,
  detach: hh,
  element: $h,
  get_all_dirty_from_scope: vh,
  get_slot_changes: gh,
  get_spread_update: wh,
  init: bh,
  insert: Sh,
  safe_not_equal: Ch,
  set_dynamic_element_data: Rl,
  set_style: ce,
  toggle_class: tt,
  transition_in: L_,
  transition_out: I_,
  update_slot_base: qh
} = window.__gradio__svelte__internal;
function yh(e) {
  let t, n, o;
  const i = (
    /*#slots*/
    e[18].default
  ), a = mh(
    i,
    e,
    /*$$scope*/
    e[17],
    null
  );
  let s = [
    { "data-testid": (
      /*test_id*/
      e[7]
    ) },
    { id: (
      /*elem_id*/
      e[2]
    ) },
    {
      class: n = "block " + /*elem_classes*/
      e[3].join(" ") + " svelte-1t38q2d"
    }
  ], _ = {};
  for (let l = 0; l < s.length; l += 1)
    _ = ph(_, s[l]);
  return {
    c() {
      t = $h(
        /*tag*/
        e[14]
      ), a && a.c(), Rl(
        /*tag*/
        e[14]
      )(t, _), tt(
        t,
        "hidden",
        /*visible*/
        e[10] === !1
      ), tt(
        t,
        "padded",
        /*padding*/
        e[6]
      ), tt(
        t,
        "border_focus",
        /*border_mode*/
        e[5] === "focus"
      ), tt(t, "hide-container", !/*explicit_call*/
      e[8] && !/*container*/
      e[9]), ce(
        t,
        "height",
        /*get_dimension*/
        e[15](
          /*height*/
          e[0]
        )
      ), ce(t, "width", typeof /*width*/
      e[1] == "number" ? `calc(min(${/*width*/
      e[1]}px, 100%))` : (
        /*get_dimension*/
        e[15](
          /*width*/
          e[1]
        )
      )), ce(
        t,
        "border-style",
        /*variant*/
        e[4]
      ), ce(
        t,
        "overflow",
        /*allow_overflow*/
        e[11] ? "visible" : "hidden"
      ), ce(
        t,
        "flex-grow",
        /*scale*/
        e[12]
      ), ce(t, "min-width", `calc(min(${/*min_width*/
      e[13]}px, 100%))`), ce(t, "border-width", "var(--block-border-width)");
    },
    m(l, r) {
      Sh(l, t, r), a && a.m(t, null), o = !0;
    },
    p(l, r) {
      a && a.p && (!o || r & /*$$scope*/
      131072) && qh(
        a,
        i,
        l,
        /*$$scope*/
        l[17],
        o ? gh(
          i,
          /*$$scope*/
          l[17],
          r,
          null
        ) : vh(
          /*$$scope*/
          l[17]
        ),
        null
      ), Rl(
        /*tag*/
        l[14]
      )(t, _ = wh(s, [
        (!o || r & /*test_id*/
        128) && { "data-testid": (
          /*test_id*/
          l[7]
        ) },
        (!o || r & /*elem_id*/
        4) && { id: (
          /*elem_id*/
          l[2]
        ) },
        (!o || r & /*elem_classes*/
        8 && n !== (n = "block " + /*elem_classes*/
        l[3].join(" ") + " svelte-1t38q2d")) && { class: n }
      ])), tt(
        t,
        "hidden",
        /*visible*/
        l[10] === !1
      ), tt(
        t,
        "padded",
        /*padding*/
        l[6]
      ), tt(
        t,
        "border_focus",
        /*border_mode*/
        l[5] === "focus"
      ), tt(t, "hide-container", !/*explicit_call*/
      l[8] && !/*container*/
      l[9]), r & /*height*/
      1 && ce(
        t,
        "height",
        /*get_dimension*/
        l[15](
          /*height*/
          l[0]
        )
      ), r & /*width*/
      2 && ce(t, "width", typeof /*width*/
      l[1] == "number" ? `calc(min(${/*width*/
      l[1]}px, 100%))` : (
        /*get_dimension*/
        l[15](
          /*width*/
          l[1]
        )
      )), r & /*variant*/
      16 && ce(
        t,
        "border-style",
        /*variant*/
        l[4]
      ), r & /*allow_overflow*/
      2048 && ce(
        t,
        "overflow",
        /*allow_overflow*/
        l[11] ? "visible" : "hidden"
      ), r & /*scale*/
      4096 && ce(
        t,
        "flex-grow",
        /*scale*/
        l[12]
      ), r & /*min_width*/
      8192 && ce(t, "min-width", `calc(min(${/*min_width*/
      l[13]}px, 100%))`);
    },
    i(l) {
      o || (L_(a, l), o = !0);
    },
    o(l) {
      I_(a, l), o = !1;
    },
    d(l) {
      l && hh(t), a && a.d(l);
    }
  };
}
function kh(e) {
  let t, n = (
    /*tag*/
    e[14] && yh(e)
  );
  return {
    c() {
      n && n.c();
    },
    m(o, i) {
      n && n.m(o, i), t = !0;
    },
    p(o, [i]) {
      /*tag*/
      o[14] && n.p(o, i);
    },
    i(o) {
      t || (L_(n, o), t = !0);
    },
    o(o) {
      I_(n, o), t = !1;
    },
    d(o) {
      n && n.d(o);
    }
  };
}
function Eh(e, t, n) {
  let { $$slots: o = {}, $$scope: i } = t, { height: a = void 0 } = t, { width: s = void 0 } = t, { elem_id: _ = "" } = t, { elem_classes: l = [] } = t, { variant: r = "solid" } = t, { border_mode: u = "base" } = t, { padding: f = !0 } = t, { type: d = "normal" } = t, { test_id: c = void 0 } = t, { explicit_call: m = !1 } = t, { container: w = !0 } = t, { visible: b = !0 } = t, { allow_overflow: v = !0 } = t, { scale: g = null } = t, { min_width: p = 0 } = t, h = d === "fieldset" ? "fieldset" : "div";
  const S = ($) => {
    if ($ !== void 0) {
      if (typeof $ == "number")
        return $ + "px";
      if (typeof $ == "string")
        return $;
    }
  };
  return e.$$set = ($) => {
    "height" in $ && n(0, a = $.height), "width" in $ && n(1, s = $.width), "elem_id" in $ && n(2, _ = $.elem_id), "elem_classes" in $ && n(3, l = $.elem_classes), "variant" in $ && n(4, r = $.variant), "border_mode" in $ && n(5, u = $.border_mode), "padding" in $ && n(6, f = $.padding), "type" in $ && n(16, d = $.type), "test_id" in $ && n(7, c = $.test_id), "explicit_call" in $ && n(8, m = $.explicit_call), "container" in $ && n(9, w = $.container), "visible" in $ && n(10, b = $.visible), "allow_overflow" in $ && n(11, v = $.allow_overflow), "scale" in $ && n(12, g = $.scale), "min_width" in $ && n(13, p = $.min_width), "$$scope" in $ && n(17, i = $.$$scope);
  }, [
    a,
    s,
    _,
    l,
    r,
    u,
    f,
    c,
    m,
    w,
    b,
    v,
    g,
    p,
    h,
    S,
    d,
    i,
    o
  ];
}
class Th extends ch {
  constructor(t) {
    super(), bh(this, t, Eh, kh, Ch, {
      height: 0,
      width: 1,
      elem_id: 2,
      elem_classes: 3,
      variant: 4,
      border_mode: 5,
      padding: 6,
      type: 16,
      test_id: 7,
      explicit_call: 8,
      container: 9,
      visible: 10,
      allow_overflow: 11,
      scale: 12,
      min_width: 13
    });
  }
}
const {
  SvelteComponent: Bh,
  attr: Hh,
  create_slot: Ah,
  detach: Nh,
  element: Ph,
  get_all_dirty_from_scope: Lh,
  get_slot_changes: Ih,
  init: Mh,
  insert: Oh,
  safe_not_equal: Dh,
  transition_in: Fh,
  transition_out: Rh,
  update_slot_base: Uh
} = window.__gradio__svelte__internal;
function Gh(e) {
  let t, n;
  const o = (
    /*#slots*/
    e[1].default
  ), i = Ah(
    o,
    e,
    /*$$scope*/
    e[0],
    null
  );
  return {
    c() {
      t = Ph("div"), i && i.c(), Hh(t, "class", "svelte-1hnfib2");
    },
    m(a, s) {
      Oh(a, t, s), i && i.m(t, null), n = !0;
    },
    p(a, [s]) {
      i && i.p && (!n || s & /*$$scope*/
      1) && Uh(
        i,
        o,
        a,
        /*$$scope*/
        a[0],
        n ? Ih(
          o,
          /*$$scope*/
          a[0],
          s,
          null
        ) : Lh(
          /*$$scope*/
          a[0]
        ),
        null
      );
    },
    i(a) {
      n || (Fh(i, a), n = !0);
    },
    o(a) {
      Rh(i, a), n = !1;
    },
    d(a) {
      a && Nh(t), i && i.d(a);
    }
  };
}
function jh(e, t, n) {
  let { $$slots: o = {}, $$scope: i } = t;
  return e.$$set = (a) => {
    "$$scope" in a && n(0, i = a.$$scope);
  }, [i, o];
}
class Vh extends Bh {
  constructor(t) {
    super(), Mh(this, t, jh, Gh, Dh, {});
  }
}
const {
  SvelteComponent: zh,
  attr: Ul,
  check_outros: Xh,
  create_component: Zh,
  create_slot: Wh,
  destroy_component: Jh,
  detach: Wn,
  element: Qh,
  empty: Yh,
  get_all_dirty_from_scope: Kh,
  get_slot_changes: xh,
  group_outros: e1,
  init: t1,
  insert: Jn,
  mount_component: n1,
  safe_not_equal: o1,
  set_data: i1,
  space: a1,
  text: l1,
  toggle_class: Tt,
  transition_in: sn,
  transition_out: Qn,
  update_slot_base: s1
} = window.__gradio__svelte__internal;
function Gl(e) {
  let t, n;
  return t = new Vh({
    props: {
      $$slots: { default: [_1] },
      $$scope: { ctx: e }
    }
  }), {
    c() {
      Zh(t.$$.fragment);
    },
    m(o, i) {
      n1(t, o, i), n = !0;
    },
    p(o, i) {
      const a = {};
      i & /*$$scope, info*/
      10 && (a.$$scope = { dirty: i, ctx: o }), t.$set(a);
    },
    i(o) {
      n || (sn(t.$$.fragment, o), n = !0);
    },
    o(o) {
      Qn(t.$$.fragment, o), n = !1;
    },
    d(o) {
      Jh(t, o);
    }
  };
}
function _1(e) {
  let t;
  return {
    c() {
      t = l1(
        /*info*/
        e[1]
      );
    },
    m(n, o) {
      Jn(n, t, o);
    },
    p(n, o) {
      o & /*info*/
      2 && i1(
        t,
        /*info*/
        n[1]
      );
    },
    d(n) {
      n && Wn(t);
    }
  };
}
function r1(e) {
  let t, n, o, i;
  const a = (
    /*#slots*/
    e[2].default
  ), s = Wh(
    a,
    e,
    /*$$scope*/
    e[3],
    null
  );
  let _ = (
    /*info*/
    e[1] && Gl(e)
  );
  return {
    c() {
      t = Qh("span"), s && s.c(), n = a1(), _ && _.c(), o = Yh(), Ul(t, "data-testid", "block-info"), Ul(t, "class", "svelte-22c38v"), Tt(t, "sr-only", !/*show_label*/
      e[0]), Tt(t, "hide", !/*show_label*/
      e[0]), Tt(
        t,
        "has-info",
        /*info*/
        e[1] != null
      );
    },
    m(l, r) {
      Jn(l, t, r), s && s.m(t, null), Jn(l, n, r), _ && _.m(l, r), Jn(l, o, r), i = !0;
    },
    p(l, [r]) {
      s && s.p && (!i || r & /*$$scope*/
      8) && s1(
        s,
        a,
        l,
        /*$$scope*/
        l[3],
        i ? xh(
          a,
          /*$$scope*/
          l[3],
          r,
          null
        ) : Kh(
          /*$$scope*/
          l[3]
        ),
        null
      ), (!i || r & /*show_label*/
      1) && Tt(t, "sr-only", !/*show_label*/
      l[0]), (!i || r & /*show_label*/
      1) && Tt(t, "hide", !/*show_label*/
      l[0]), (!i || r & /*info*/
      2) && Tt(
        t,
        "has-info",
        /*info*/
        l[1] != null
      ), /*info*/
      l[1] ? _ ? (_.p(l, r), r & /*info*/
      2 && sn(_, 1)) : (_ = Gl(l), _.c(), sn(_, 1), _.m(o.parentNode, o)) : _ && (e1(), Qn(_, 1, 1, () => {
        _ = null;
      }), Xh());
    },
    i(l) {
      i || (sn(s, l), sn(_), i = !0);
    },
    o(l) {
      Qn(s, l), Qn(_), i = !1;
    },
    d(l) {
      l && (Wn(t), Wn(n), Wn(o)), s && s.d(l), _ && _.d(l);
    }
  };
}
function u1(e, t, n) {
  let { $$slots: o = {}, $$scope: i } = t, { show_label: a = !0 } = t, { info: s = void 0 } = t;
  return e.$$set = (_) => {
    "show_label" in _ && n(0, a = _.show_label), "info" in _ && n(1, s = _.info), "$$scope" in _ && n(3, i = _.$$scope);
  }, [a, s, o, i];
}
class f1 extends zh {
  constructor(t) {
    super(), t1(this, t, u1, r1, o1, { show_label: 0, info: 1 });
  }
}
const {
  SvelteComponent: lee,
  append: see,
  attr: _ee,
  create_component: ree,
  destroy_component: uee,
  detach: fee,
  element: dee,
  init: cee,
  insert: pee,
  mount_component: mee,
  safe_not_equal: hee,
  set_data: $ee,
  space: vee,
  text: gee,
  toggle_class: wee,
  transition_in: bee,
  transition_out: See
} = window.__gradio__svelte__internal, {
  SvelteComponent: Cee,
  append: qee,
  attr: yee,
  bubble: kee,
  create_component: Eee,
  destroy_component: Tee,
  detach: Bee,
  element: Hee,
  init: Aee,
  insert: Nee,
  listen: Pee,
  mount_component: Lee,
  safe_not_equal: Iee,
  set_data: Mee,
  set_style: Oee,
  space: Dee,
  text: Fee,
  toggle_class: Ree,
  transition_in: Uee,
  transition_out: Gee
} = window.__gradio__svelte__internal, {
  SvelteComponent: jee,
  append: Vee,
  attr: zee,
  binding_callbacks: Xee,
  create_slot: Zee,
  detach: Wee,
  element: Jee,
  get_all_dirty_from_scope: Qee,
  get_slot_changes: Yee,
  init: Kee,
  insert: xee,
  safe_not_equal: ete,
  toggle_class: tte,
  transition_in: nte,
  transition_out: ote,
  update_slot_base: ite
} = window.__gradio__svelte__internal, {
  SvelteComponent: ate,
  append: lte,
  attr: ste,
  detach: _te,
  init: rte,
  insert: ute,
  noop: fte,
  safe_not_equal: dte,
  svg_element: cte
} = window.__gradio__svelte__internal, {
  SvelteComponent: pte,
  append: mte,
  attr: hte,
  detach: $te,
  init: vte,
  insert: gte,
  noop: wte,
  safe_not_equal: bte,
  svg_element: Ste
} = window.__gradio__svelte__internal, {
  SvelteComponent: Cte,
  append: qte,
  attr: yte,
  detach: kte,
  init: Ete,
  insert: Tte,
  noop: Bte,
  safe_not_equal: Hte,
  svg_element: Ate
} = window.__gradio__svelte__internal, {
  SvelteComponent: Nte,
  append: Pte,
  attr: Lte,
  detach: Ite,
  init: Mte,
  insert: Ote,
  noop: Dte,
  safe_not_equal: Fte,
  svg_element: Rte
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ute,
  append: Gte,
  attr: jte,
  detach: Vte,
  init: zte,
  insert: Xte,
  noop: Zte,
  safe_not_equal: Wte,
  svg_element: Jte
} = window.__gradio__svelte__internal, {
  SvelteComponent: Qte,
  append: Yte,
  attr: Kte,
  detach: xte,
  init: ene,
  insert: tne,
  noop: nne,
  safe_not_equal: one,
  svg_element: ine
} = window.__gradio__svelte__internal, {
  SvelteComponent: ane,
  append: lne,
  attr: sne,
  detach: _ne,
  init: rne,
  insert: une,
  noop: fne,
  safe_not_equal: dne,
  svg_element: cne
} = window.__gradio__svelte__internal, {
  SvelteComponent: pne,
  append: mne,
  attr: hne,
  detach: $ne,
  init: vne,
  insert: gne,
  noop: wne,
  safe_not_equal: bne,
  svg_element: Sne
} = window.__gradio__svelte__internal, {
  SvelteComponent: Cne,
  append: qne,
  attr: yne,
  detach: kne,
  init: Ene,
  insert: Tne,
  noop: Bne,
  safe_not_equal: Hne,
  set_style: Ane,
  svg_element: Nne
} = window.__gradio__svelte__internal, {
  SvelteComponent: Pne,
  append: Lne,
  attr: Ine,
  detach: Mne,
  init: One,
  insert: Dne,
  noop: Fne,
  safe_not_equal: Rne,
  svg_element: Une
} = window.__gradio__svelte__internal, {
  SvelteComponent: Gne,
  append: jne,
  attr: Vne,
  detach: zne,
  init: Xne,
  insert: Zne,
  noop: Wne,
  safe_not_equal: Jne,
  svg_element: Qne
} = window.__gradio__svelte__internal, {
  SvelteComponent: Yne,
  append: Kne,
  attr: xne,
  detach: eoe,
  init: toe,
  insert: noe,
  noop: ooe,
  safe_not_equal: ioe,
  svg_element: aoe
} = window.__gradio__svelte__internal, {
  SvelteComponent: loe,
  append: soe,
  attr: _oe,
  detach: roe,
  init: uoe,
  insert: foe,
  noop: doe,
  safe_not_equal: coe,
  svg_element: poe
} = window.__gradio__svelte__internal, {
  SvelteComponent: moe,
  append: hoe,
  attr: $oe,
  detach: voe,
  init: goe,
  insert: woe,
  noop: boe,
  safe_not_equal: Soe,
  svg_element: Coe
} = window.__gradio__svelte__internal, {
  SvelteComponent: qoe,
  append: yoe,
  attr: koe,
  detach: Eoe,
  init: Toe,
  insert: Boe,
  noop: Hoe,
  safe_not_equal: Aoe,
  svg_element: Noe
} = window.__gradio__svelte__internal, {
  SvelteComponent: Poe,
  append: Loe,
  attr: Ioe,
  detach: Moe,
  init: Ooe,
  insert: Doe,
  noop: Foe,
  safe_not_equal: Roe,
  svg_element: Uoe
} = window.__gradio__svelte__internal, {
  SvelteComponent: Goe,
  append: joe,
  attr: Voe,
  detach: zoe,
  init: Xoe,
  insert: Zoe,
  noop: Woe,
  safe_not_equal: Joe,
  svg_element: Qoe
} = window.__gradio__svelte__internal, {
  SvelteComponent: Yoe,
  append: Koe,
  attr: xoe,
  detach: eie,
  init: tie,
  insert: nie,
  noop: oie,
  safe_not_equal: iie,
  svg_element: aie
} = window.__gradio__svelte__internal, {
  SvelteComponent: lie,
  append: sie,
  attr: _ie,
  detach: rie,
  init: uie,
  insert: fie,
  noop: die,
  safe_not_equal: cie,
  svg_element: pie
} = window.__gradio__svelte__internal, {
  SvelteComponent: mie,
  append: hie,
  attr: $ie,
  detach: vie,
  init: gie,
  insert: wie,
  noop: bie,
  safe_not_equal: Sie,
  svg_element: Cie
} = window.__gradio__svelte__internal, {
  SvelteComponent: qie,
  append: yie,
  attr: kie,
  detach: Eie,
  init: Tie,
  insert: Bie,
  noop: Hie,
  safe_not_equal: Aie,
  svg_element: Nie
} = window.__gradio__svelte__internal, {
  SvelteComponent: Pie,
  append: Lie,
  attr: Iie,
  detach: Mie,
  init: Oie,
  insert: Die,
  noop: Fie,
  safe_not_equal: Rie,
  svg_element: Uie
} = window.__gradio__svelte__internal, {
  SvelteComponent: Gie,
  append: jie,
  attr: Vie,
  detach: zie,
  init: Xie,
  insert: Zie,
  noop: Wie,
  safe_not_equal: Jie,
  svg_element: Qie
} = window.__gradio__svelte__internal, {
  SvelteComponent: Yie,
  append: Kie,
  attr: xie,
  detach: eae,
  init: tae,
  insert: nae,
  noop: oae,
  safe_not_equal: iae,
  svg_element: aae
} = window.__gradio__svelte__internal, {
  SvelteComponent: lae,
  append: sae,
  attr: _ae,
  detach: rae,
  init: uae,
  insert: fae,
  noop: dae,
  safe_not_equal: cae,
  svg_element: pae
} = window.__gradio__svelte__internal, {
  SvelteComponent: mae,
  append: hae,
  attr: $ae,
  detach: vae,
  init: gae,
  insert: wae,
  noop: bae,
  safe_not_equal: Sae,
  svg_element: Cae
} = window.__gradio__svelte__internal, {
  SvelteComponent: qae,
  append: yae,
  attr: kae,
  detach: Eae,
  init: Tae,
  insert: Bae,
  noop: Hae,
  safe_not_equal: Aae,
  svg_element: Nae
} = window.__gradio__svelte__internal, {
  SvelteComponent: Pae,
  append: Lae,
  attr: Iae,
  detach: Mae,
  init: Oae,
  insert: Dae,
  noop: Fae,
  safe_not_equal: Rae,
  svg_element: Uae
} = window.__gradio__svelte__internal, {
  SvelteComponent: Gae,
  append: jae,
  attr: Vae,
  detach: zae,
  init: Xae,
  insert: Zae,
  noop: Wae,
  safe_not_equal: Jae,
  svg_element: Qae
} = window.__gradio__svelte__internal, {
  SvelteComponent: Yae,
  append: Kae,
  attr: xae,
  detach: ele,
  init: tle,
  insert: nle,
  noop: ole,
  safe_not_equal: ile,
  svg_element: ale
} = window.__gradio__svelte__internal, {
  SvelteComponent: lle,
  append: sle,
  attr: _le,
  detach: rle,
  init: ule,
  insert: fle,
  noop: dle,
  safe_not_equal: cle,
  svg_element: ple
} = window.__gradio__svelte__internal, {
  SvelteComponent: mle,
  append: hle,
  attr: $le,
  detach: vle,
  init: gle,
  insert: wle,
  noop: ble,
  safe_not_equal: Sle,
  svg_element: Cle
} = window.__gradio__svelte__internal, {
  SvelteComponent: qle,
  append: yle,
  attr: kle,
  detach: Ele,
  init: Tle,
  insert: Ble,
  noop: Hle,
  safe_not_equal: Ale,
  svg_element: Nle
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ple,
  append: Lle,
  attr: Ile,
  detach: Mle,
  init: Ole,
  insert: Dle,
  noop: Fle,
  safe_not_equal: Rle,
  svg_element: Ule
} = window.__gradio__svelte__internal, {
  SvelteComponent: Gle,
  append: jle,
  attr: Vle,
  detach: zle,
  init: Xle,
  insert: Zle,
  noop: Wle,
  safe_not_equal: Jle,
  svg_element: Qle
} = window.__gradio__svelte__internal, {
  SvelteComponent: Yle,
  append: Kle,
  attr: xle,
  detach: ese,
  init: tse,
  insert: nse,
  noop: ose,
  safe_not_equal: ise,
  svg_element: ase
} = window.__gradio__svelte__internal, {
  SvelteComponent: lse,
  append: sse,
  attr: _se,
  detach: rse,
  init: use,
  insert: fse,
  noop: dse,
  safe_not_equal: cse,
  set_style: pse,
  svg_element: mse
} = window.__gradio__svelte__internal, {
  SvelteComponent: hse,
  append: $se,
  attr: vse,
  detach: gse,
  init: wse,
  insert: bse,
  noop: Sse,
  safe_not_equal: Cse,
  svg_element: qse
} = window.__gradio__svelte__internal, {
  SvelteComponent: yse,
  append: kse,
  attr: Ese,
  detach: Tse,
  init: Bse,
  insert: Hse,
  noop: Ase,
  safe_not_equal: Nse,
  svg_element: Pse
} = window.__gradio__svelte__internal, {
  SvelteComponent: Lse,
  append: Ise,
  attr: Mse,
  detach: Ose,
  init: Dse,
  insert: Fse,
  noop: Rse,
  safe_not_equal: Use,
  svg_element: Gse
} = window.__gradio__svelte__internal, {
  SvelteComponent: jse,
  append: Vse,
  attr: zse,
  detach: Xse,
  init: Zse,
  insert: Wse,
  noop: Jse,
  safe_not_equal: Qse,
  svg_element: Yse
} = window.__gradio__svelte__internal, {
  SvelteComponent: Kse,
  append: xse,
  attr: e_e,
  detach: t_e,
  init: n_e,
  insert: o_e,
  noop: i_e,
  safe_not_equal: a_e,
  svg_element: l_e
} = window.__gradio__svelte__internal, {
  SvelteComponent: s_e,
  append: __e,
  attr: r_e,
  detach: u_e,
  init: f_e,
  insert: d_e,
  noop: c_e,
  safe_not_equal: p_e,
  svg_element: m_e
} = window.__gradio__svelte__internal, {
  SvelteComponent: h_e,
  append: $_e,
  attr: v_e,
  detach: g_e,
  init: w_e,
  insert: b_e,
  noop: S_e,
  safe_not_equal: C_e,
  svg_element: q_e
} = window.__gradio__svelte__internal, {
  SvelteComponent: y_e,
  append: k_e,
  attr: E_e,
  detach: T_e,
  init: B_e,
  insert: H_e,
  noop: A_e,
  safe_not_equal: N_e,
  svg_element: P_e
} = window.__gradio__svelte__internal, {
  SvelteComponent: L_e,
  append: I_e,
  attr: M_e,
  detach: O_e,
  init: D_e,
  insert: F_e,
  noop: R_e,
  safe_not_equal: U_e,
  svg_element: G_e,
  text: j_e
} = window.__gradio__svelte__internal, {
  SvelteComponent: V_e,
  append: z_e,
  attr: X_e,
  detach: Z_e,
  init: W_e,
  insert: J_e,
  noop: Q_e,
  safe_not_equal: Y_e,
  svg_element: K_e
} = window.__gradio__svelte__internal, {
  SvelteComponent: x_e,
  append: ere,
  attr: tre,
  detach: nre,
  init: ore,
  insert: ire,
  noop: are,
  safe_not_equal: lre,
  svg_element: sre
} = window.__gradio__svelte__internal, {
  SvelteComponent: _re,
  append: rre,
  attr: ure,
  detach: fre,
  init: dre,
  insert: cre,
  noop: pre,
  safe_not_equal: mre,
  svg_element: hre
} = window.__gradio__svelte__internal, {
  SvelteComponent: $re,
  append: vre,
  attr: gre,
  detach: wre,
  init: bre,
  insert: Sre,
  noop: Cre,
  safe_not_equal: qre,
  svg_element: yre
} = window.__gradio__svelte__internal, {
  SvelteComponent: kre,
  append: Ere,
  attr: Tre,
  detach: Bre,
  init: Hre,
  insert: Are,
  noop: Nre,
  safe_not_equal: Pre,
  svg_element: Lre
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ire,
  append: Mre,
  attr: Ore,
  detach: Dre,
  init: Fre,
  insert: Rre,
  noop: Ure,
  safe_not_equal: Gre,
  svg_element: jre,
  text: Vre
} = window.__gradio__svelte__internal, {
  SvelteComponent: zre,
  append: Xre,
  attr: Zre,
  detach: Wre,
  init: Jre,
  insert: Qre,
  noop: Yre,
  safe_not_equal: Kre,
  svg_element: xre,
  text: eue
} = window.__gradio__svelte__internal, {
  SvelteComponent: tue,
  append: nue,
  attr: oue,
  detach: iue,
  init: aue,
  insert: lue,
  noop: sue,
  safe_not_equal: _ue,
  svg_element: rue,
  text: uue
} = window.__gradio__svelte__internal, {
  SvelteComponent: fue,
  append: due,
  attr: cue,
  detach: pue,
  init: mue,
  insert: hue,
  noop: $ue,
  safe_not_equal: vue,
  svg_element: gue
} = window.__gradio__svelte__internal, {
  SvelteComponent: wue,
  append: bue,
  attr: Sue,
  detach: Cue,
  init: que,
  insert: yue,
  noop: kue,
  safe_not_equal: Eue,
  svg_element: Tue
} = window.__gradio__svelte__internal, {
  SvelteComponent: Bue,
  create_component: Hue,
  destroy_component: Aue,
  init: Nue,
  mount_component: Pue,
  safe_not_equal: Lue,
  transition_in: Iue,
  transition_out: Mue
} = window.__gradio__svelte__internal, { createEventDispatcher: Oue } = window.__gradio__svelte__internal, {
  SvelteComponent: Due,
  append: Fue,
  attr: Rue,
  check_outros: Uue,
  create_component: Gue,
  destroy_component: jue,
  detach: Vue,
  element: zue,
  group_outros: Xue,
  init: Zue,
  insert: Wue,
  mount_component: Jue,
  safe_not_equal: Que,
  set_data: Yue,
  space: Kue,
  text: xue,
  toggle_class: efe,
  transition_in: tfe,
  transition_out: nfe
} = window.__gradio__svelte__internal, {
  SvelteComponent: ofe,
  attr: ife,
  create_slot: afe,
  detach: lfe,
  element: sfe,
  get_all_dirty_from_scope: _fe,
  get_slot_changes: rfe,
  init: ufe,
  insert: ffe,
  safe_not_equal: dfe,
  toggle_class: cfe,
  transition_in: pfe,
  transition_out: mfe,
  update_slot_base: hfe
} = window.__gradio__svelte__internal, {
  SvelteComponent: $fe,
  append: vfe,
  attr: gfe,
  check_outros: wfe,
  create_component: bfe,
  destroy_component: Sfe,
  detach: Cfe,
  element: qfe,
  empty: yfe,
  group_outros: kfe,
  init: Efe,
  insert: Tfe,
  listen: Bfe,
  mount_component: Hfe,
  safe_not_equal: Afe,
  space: Nfe,
  toggle_class: Pfe,
  transition_in: Lfe,
  transition_out: Ife
} = window.__gradio__svelte__internal;
function Mt(e) {
  let t = ["", "k", "M", "G", "T", "P", "E", "Z"], n = 0;
  for (; e > 1e3 && n < t.length - 1; )
    e /= 1e3, n++;
  let o = t[n];
  return (Number.isInteger(e) ? e : e.toFixed(1)) + o;
}
const {
  SvelteComponent: d1,
  append: Be,
  attr: X,
  component_subscribe: jl,
  detach: c1,
  element: p1,
  init: m1,
  insert: h1,
  noop: Vl,
  safe_not_equal: $1,
  set_style: Dn,
  svg_element: He,
  toggle_class: zl
} = window.__gradio__svelte__internal, { onMount: v1 } = window.__gradio__svelte__internal;
function g1(e) {
  let t, n, o, i, a, s, _, l, r, u, f, d;
  return {
    c() {
      t = p1("div"), n = He("svg"), o = He("g"), i = He("path"), a = He("path"), s = He("path"), _ = He("path"), l = He("g"), r = He("path"), u = He("path"), f = He("path"), d = He("path"), X(i, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), X(i, "fill", "#FF7C00"), X(i, "fill-opacity", "0.4"), X(i, "class", "svelte-43sxxs"), X(a, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), X(a, "fill", "#FF7C00"), X(a, "class", "svelte-43sxxs"), X(s, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), X(s, "fill", "#FF7C00"), X(s, "fill-opacity", "0.4"), X(s, "class", "svelte-43sxxs"), X(_, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), X(_, "fill", "#FF7C00"), X(_, "class", "svelte-43sxxs"), Dn(o, "transform", "translate(" + /*$top*/
      e[1][0] + "px, " + /*$top*/
      e[1][1] + "px)"), X(r, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), X(r, "fill", "#FF7C00"), X(r, "fill-opacity", "0.4"), X(r, "class", "svelte-43sxxs"), X(u, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), X(u, "fill", "#FF7C00"), X(u, "class", "svelte-43sxxs"), X(f, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), X(f, "fill", "#FF7C00"), X(f, "fill-opacity", "0.4"), X(f, "class", "svelte-43sxxs"), X(d, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), X(d, "fill", "#FF7C00"), X(d, "class", "svelte-43sxxs"), Dn(l, "transform", "translate(" + /*$bottom*/
      e[2][0] + "px, " + /*$bottom*/
      e[2][1] + "px)"), X(n, "viewBox", "-1200 -1200 3000 3000"), X(n, "fill", "none"), X(n, "xmlns", "http://www.w3.org/2000/svg"), X(n, "class", "svelte-43sxxs"), X(t, "class", "svelte-43sxxs"), zl(
        t,
        "margin",
        /*margin*/
        e[0]
      );
    },
    m(c, m) {
      h1(c, t, m), Be(t, n), Be(n, o), Be(o, i), Be(o, a), Be(o, s), Be(o, _), Be(n, l), Be(l, r), Be(l, u), Be(l, f), Be(l, d);
    },
    p(c, [m]) {
      m & /*$top*/
      2 && Dn(o, "transform", "translate(" + /*$top*/
      c[1][0] + "px, " + /*$top*/
      c[1][1] + "px)"), m & /*$bottom*/
      4 && Dn(l, "transform", "translate(" + /*$bottom*/
      c[2][0] + "px, " + /*$bottom*/
      c[2][1] + "px)"), m & /*margin*/
      1 && zl(
        t,
        "margin",
        /*margin*/
        c[0]
      );
    },
    i: Vl,
    o: Vl,
    d(c) {
      c && c1(t);
    }
  };
}
function w1(e, t, n) {
  let o, i, { margin: a = !0 } = t;
  const s = Ut([0, 0]);
  jl(e, s, (d) => n(1, o = d));
  const _ = Ut([0, 0]);
  jl(e, _, (d) => n(2, i = d));
  let l;
  async function r() {
    await Promise.all([s.set([125, 140]), _.set([-125, -140])]), await Promise.all([s.set([-125, 140]), _.set([125, -140])]), await Promise.all([s.set([-125, 0]), _.set([125, -0])]), await Promise.all([s.set([125, 0]), _.set([-125, 0])]);
  }
  async function u() {
    await r(), l || u();
  }
  async function f() {
    await Promise.all([s.set([125, 0]), _.set([-125, 0])]), u();
  }
  return v1(() => (f(), () => l = !0)), e.$$set = (d) => {
    "margin" in d && n(0, a = d.margin);
  }, [a, o, i, s, _];
}
class b1 extends d1 {
  constructor(t) {
    super(), m1(this, t, w1, g1, $1, { margin: 0 });
  }
}
const {
  SvelteComponent: S1,
  append: $t,
  attr: ze,
  binding_callbacks: Xl,
  check_outros: M_,
  create_component: C1,
  create_slot: q1,
  destroy_component: y1,
  destroy_each: O_,
  detach: D,
  element: Qe,
  empty: en,
  ensure_array_like: uo,
  get_all_dirty_from_scope: k1,
  get_slot_changes: E1,
  group_outros: D_,
  init: T1,
  insert: F,
  mount_component: B1,
  noop: qi,
  safe_not_equal: H1,
  set_data: Ce,
  set_style: st,
  space: Xe,
  text: te,
  toggle_class: ge,
  transition_in: Wt,
  transition_out: Jt,
  update_slot_base: A1
} = window.__gradio__svelte__internal, { tick: N1 } = window.__gradio__svelte__internal, { onDestroy: P1 } = window.__gradio__svelte__internal, L1 = (e) => ({}), Zl = (e) => ({});
function Wl(e, t, n) {
  const o = e.slice();
  return o[38] = t[n], o[40] = n, o;
}
function Jl(e, t, n) {
  const o = e.slice();
  return o[38] = t[n], o;
}
function I1(e) {
  let t, n = (
    /*i18n*/
    e[1]("common.error") + ""
  ), o, i, a;
  const s = (
    /*#slots*/
    e[29].error
  ), _ = q1(
    s,
    e,
    /*$$scope*/
    e[28],
    Zl
  );
  return {
    c() {
      t = Qe("span"), o = te(n), i = Xe(), _ && _.c(), ze(t, "class", "error svelte-1yserjw");
    },
    m(l, r) {
      F(l, t, r), $t(t, o), F(l, i, r), _ && _.m(l, r), a = !0;
    },
    p(l, r) {
      (!a || r[0] & /*i18n*/
      2) && n !== (n = /*i18n*/
      l[1]("common.error") + "") && Ce(o, n), _ && _.p && (!a || r[0] & /*$$scope*/
      268435456) && A1(
        _,
        s,
        l,
        /*$$scope*/
        l[28],
        a ? E1(
          s,
          /*$$scope*/
          l[28],
          r,
          L1
        ) : k1(
          /*$$scope*/
          l[28]
        ),
        Zl
      );
    },
    i(l) {
      a || (Wt(_, l), a = !0);
    },
    o(l) {
      Jt(_, l), a = !1;
    },
    d(l) {
      l && (D(t), D(i)), _ && _.d(l);
    }
  };
}
function M1(e) {
  let t, n, o, i, a, s, _, l, r, u = (
    /*variant*/
    e[8] === "default" && /*show_eta_bar*/
    e[18] && /*show_progress*/
    e[6] === "full" && Ql(e)
  );
  function f(p, h) {
    if (
      /*progress*/
      p[7]
    ) return F1;
    if (
      /*queue_position*/
      p[2] !== null && /*queue_size*/
      p[3] !== void 0 && /*queue_position*/
      p[2] >= 0
    ) return D1;
    if (
      /*queue_position*/
      p[2] === 0
    ) return O1;
  }
  let d = f(e), c = d && d(e), m = (
    /*timer*/
    e[5] && xl(e)
  );
  const w = [j1, G1], b = [];
  function v(p, h) {
    return (
      /*last_progress_level*/
      p[15] != null ? 0 : (
        /*show_progress*/
        p[6] === "full" ? 1 : -1
      )
    );
  }
  ~(a = v(e)) && (s = b[a] = w[a](e));
  let g = !/*timer*/
  e[5] && ls(e);
  return {
    c() {
      u && u.c(), t = Xe(), n = Qe("div"), c && c.c(), o = Xe(), m && m.c(), i = Xe(), s && s.c(), _ = Xe(), g && g.c(), l = en(), ze(n, "class", "progress-text svelte-1yserjw"), ge(
        n,
        "meta-text-center",
        /*variant*/
        e[8] === "center"
      ), ge(
        n,
        "meta-text",
        /*variant*/
        e[8] === "default"
      );
    },
    m(p, h) {
      u && u.m(p, h), F(p, t, h), F(p, n, h), c && c.m(n, null), $t(n, o), m && m.m(n, null), F(p, i, h), ~a && b[a].m(p, h), F(p, _, h), g && g.m(p, h), F(p, l, h), r = !0;
    },
    p(p, h) {
      /*variant*/
      p[8] === "default" && /*show_eta_bar*/
      p[18] && /*show_progress*/
      p[6] === "full" ? u ? u.p(p, h) : (u = Ql(p), u.c(), u.m(t.parentNode, t)) : u && (u.d(1), u = null), d === (d = f(p)) && c ? c.p(p, h) : (c && c.d(1), c = d && d(p), c && (c.c(), c.m(n, o))), /*timer*/
      p[5] ? m ? m.p(p, h) : (m = xl(p), m.c(), m.m(n, null)) : m && (m.d(1), m = null), (!r || h[0] & /*variant*/
      256) && ge(
        n,
        "meta-text-center",
        /*variant*/
        p[8] === "center"
      ), (!r || h[0] & /*variant*/
      256) && ge(
        n,
        "meta-text",
        /*variant*/
        p[8] === "default"
      );
      let S = a;
      a = v(p), a === S ? ~a && b[a].p(p, h) : (s && (D_(), Jt(b[S], 1, 1, () => {
        b[S] = null;
      }), M_()), ~a ? (s = b[a], s ? s.p(p, h) : (s = b[a] = w[a](p), s.c()), Wt(s, 1), s.m(_.parentNode, _)) : s = null), /*timer*/
      p[5] ? g && (g.d(1), g = null) : g ? g.p(p, h) : (g = ls(p), g.c(), g.m(l.parentNode, l));
    },
    i(p) {
      r || (Wt(s), r = !0);
    },
    o(p) {
      Jt(s), r = !1;
    },
    d(p) {
      p && (D(t), D(n), D(i), D(_), D(l)), u && u.d(p), c && c.d(), m && m.d(), ~a && b[a].d(p), g && g.d(p);
    }
  };
}
function Ql(e) {
  let t, n = `translateX(${/*eta_level*/
  (e[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      t = Qe("div"), ze(t, "class", "eta-bar svelte-1yserjw"), st(t, "transform", n);
    },
    m(o, i) {
      F(o, t, i);
    },
    p(o, i) {
      i[0] & /*eta_level*/
      131072 && n !== (n = `translateX(${/*eta_level*/
      (o[17] || 0) * 100 - 100}%)`) && st(t, "transform", n);
    },
    d(o) {
      o && D(t);
    }
  };
}
function O1(e) {
  let t;
  return {
    c() {
      t = te("processing |");
    },
    m(n, o) {
      F(n, t, o);
    },
    p: qi,
    d(n) {
      n && D(t);
    }
  };
}
function D1(e) {
  let t, n = (
    /*queue_position*/
    e[2] + 1 + ""
  ), o, i, a, s;
  return {
    c() {
      t = te("queue: "), o = te(n), i = te("/"), a = te(
        /*queue_size*/
        e[3]
      ), s = te(" |");
    },
    m(_, l) {
      F(_, t, l), F(_, o, l), F(_, i, l), F(_, a, l), F(_, s, l);
    },
    p(_, l) {
      l[0] & /*queue_position*/
      4 && n !== (n = /*queue_position*/
      _[2] + 1 + "") && Ce(o, n), l[0] & /*queue_size*/
      8 && Ce(
        a,
        /*queue_size*/
        _[3]
      );
    },
    d(_) {
      _ && (D(t), D(o), D(i), D(a), D(s));
    }
  };
}
function F1(e) {
  let t, n = uo(
    /*progress*/
    e[7]
  ), o = [];
  for (let i = 0; i < n.length; i += 1)
    o[i] = Kl(Jl(e, n, i));
  return {
    c() {
      for (let i = 0; i < o.length; i += 1)
        o[i].c();
      t = en();
    },
    m(i, a) {
      for (let s = 0; s < o.length; s += 1)
        o[s] && o[s].m(i, a);
      F(i, t, a);
    },
    p(i, a) {
      if (a[0] & /*progress*/
      128) {
        n = uo(
          /*progress*/
          i[7]
        );
        let s;
        for (s = 0; s < n.length; s += 1) {
          const _ = Jl(i, n, s);
          o[s] ? o[s].p(_, a) : (o[s] = Kl(_), o[s].c(), o[s].m(t.parentNode, t));
        }
        for (; s < o.length; s += 1)
          o[s].d(1);
        o.length = n.length;
      }
    },
    d(i) {
      i && D(t), O_(o, i);
    }
  };
}
function Yl(e) {
  let t, n = (
    /*p*/
    e[38].unit + ""
  ), o, i, a = " ", s;
  function _(u, f) {
    return (
      /*p*/
      u[38].length != null ? U1 : R1
    );
  }
  let l = _(e), r = l(e);
  return {
    c() {
      r.c(), t = Xe(), o = te(n), i = te(" | "), s = te(a);
    },
    m(u, f) {
      r.m(u, f), F(u, t, f), F(u, o, f), F(u, i, f), F(u, s, f);
    },
    p(u, f) {
      l === (l = _(u)) && r ? r.p(u, f) : (r.d(1), r = l(u), r && (r.c(), r.m(t.parentNode, t))), f[0] & /*progress*/
      128 && n !== (n = /*p*/
      u[38].unit + "") && Ce(o, n);
    },
    d(u) {
      u && (D(t), D(o), D(i), D(s)), r.d(u);
    }
  };
}
function R1(e) {
  let t = Mt(
    /*p*/
    e[38].index || 0
  ) + "", n;
  return {
    c() {
      n = te(t);
    },
    m(o, i) {
      F(o, n, i);
    },
    p(o, i) {
      i[0] & /*progress*/
      128 && t !== (t = Mt(
        /*p*/
        o[38].index || 0
      ) + "") && Ce(n, t);
    },
    d(o) {
      o && D(n);
    }
  };
}
function U1(e) {
  let t = Mt(
    /*p*/
    e[38].index || 0
  ) + "", n, o, i = Mt(
    /*p*/
    e[38].length
  ) + "", a;
  return {
    c() {
      n = te(t), o = te("/"), a = te(i);
    },
    m(s, _) {
      F(s, n, _), F(s, o, _), F(s, a, _);
    },
    p(s, _) {
      _[0] & /*progress*/
      128 && t !== (t = Mt(
        /*p*/
        s[38].index || 0
      ) + "") && Ce(n, t), _[0] & /*progress*/
      128 && i !== (i = Mt(
        /*p*/
        s[38].length
      ) + "") && Ce(a, i);
    },
    d(s) {
      s && (D(n), D(o), D(a));
    }
  };
}
function Kl(e) {
  let t, n = (
    /*p*/
    e[38].index != null && Yl(e)
  );
  return {
    c() {
      n && n.c(), t = en();
    },
    m(o, i) {
      n && n.m(o, i), F(o, t, i);
    },
    p(o, i) {
      /*p*/
      o[38].index != null ? n ? n.p(o, i) : (n = Yl(o), n.c(), n.m(t.parentNode, t)) : n && (n.d(1), n = null);
    },
    d(o) {
      o && D(t), n && n.d(o);
    }
  };
}
function xl(e) {
  let t, n = (
    /*eta*/
    e[0] ? `/${/*formatted_eta*/
    e[19]}` : ""
  ), o, i;
  return {
    c() {
      t = te(
        /*formatted_timer*/
        e[20]
      ), o = te(n), i = te("s");
    },
    m(a, s) {
      F(a, t, s), F(a, o, s), F(a, i, s);
    },
    p(a, s) {
      s[0] & /*formatted_timer*/
      1048576 && Ce(
        t,
        /*formatted_timer*/
        a[20]
      ), s[0] & /*eta, formatted_eta*/
      524289 && n !== (n = /*eta*/
      a[0] ? `/${/*formatted_eta*/
      a[19]}` : "") && Ce(o, n);
    },
    d(a) {
      a && (D(t), D(o), D(i));
    }
  };
}
function G1(e) {
  let t, n;
  return t = new b1({
    props: { margin: (
      /*variant*/
      e[8] === "default"
    ) }
  }), {
    c() {
      C1(t.$$.fragment);
    },
    m(o, i) {
      B1(t, o, i), n = !0;
    },
    p(o, i) {
      const a = {};
      i[0] & /*variant*/
      256 && (a.margin = /*variant*/
      o[8] === "default"), t.$set(a);
    },
    i(o) {
      n || (Wt(t.$$.fragment, o), n = !0);
    },
    o(o) {
      Jt(t.$$.fragment, o), n = !1;
    },
    d(o) {
      y1(t, o);
    }
  };
}
function j1(e) {
  let t, n, o, i, a, s = `${/*last_progress_level*/
  e[15] * 100}%`, _ = (
    /*progress*/
    e[7] != null && es(e)
  );
  return {
    c() {
      t = Qe("div"), n = Qe("div"), _ && _.c(), o = Xe(), i = Qe("div"), a = Qe("div"), ze(n, "class", "progress-level-inner svelte-1yserjw"), ze(a, "class", "progress-bar svelte-1yserjw"), st(a, "width", s), ze(i, "class", "progress-bar-wrap svelte-1yserjw"), ze(t, "class", "progress-level svelte-1yserjw");
    },
    m(l, r) {
      F(l, t, r), $t(t, n), _ && _.m(n, null), $t(t, o), $t(t, i), $t(i, a), e[30](a);
    },
    p(l, r) {
      /*progress*/
      l[7] != null ? _ ? _.p(l, r) : (_ = es(l), _.c(), _.m(n, null)) : _ && (_.d(1), _ = null), r[0] & /*last_progress_level*/
      32768 && s !== (s = `${/*last_progress_level*/
      l[15] * 100}%`) && st(a, "width", s);
    },
    i: qi,
    o: qi,
    d(l) {
      l && D(t), _ && _.d(), e[30](null);
    }
  };
}
function es(e) {
  let t, n = uo(
    /*progress*/
    e[7]
  ), o = [];
  for (let i = 0; i < n.length; i += 1)
    o[i] = as(Wl(e, n, i));
  return {
    c() {
      for (let i = 0; i < o.length; i += 1)
        o[i].c();
      t = en();
    },
    m(i, a) {
      for (let s = 0; s < o.length; s += 1)
        o[s] && o[s].m(i, a);
      F(i, t, a);
    },
    p(i, a) {
      if (a[0] & /*progress_level, progress*/
      16512) {
        n = uo(
          /*progress*/
          i[7]
        );
        let s;
        for (s = 0; s < n.length; s += 1) {
          const _ = Wl(i, n, s);
          o[s] ? o[s].p(_, a) : (o[s] = as(_), o[s].c(), o[s].m(t.parentNode, t));
        }
        for (; s < o.length; s += 1)
          o[s].d(1);
        o.length = n.length;
      }
    },
    d(i) {
      i && D(t), O_(o, i);
    }
  };
}
function ts(e) {
  let t, n, o, i, a = (
    /*i*/
    e[40] !== 0 && V1()
  ), s = (
    /*p*/
    e[38].desc != null && ns(e)
  ), _ = (
    /*p*/
    e[38].desc != null && /*progress_level*/
    e[14] && /*progress_level*/
    e[14][
      /*i*/
      e[40]
    ] != null && os()
  ), l = (
    /*progress_level*/
    e[14] != null && is(e)
  );
  return {
    c() {
      a && a.c(), t = Xe(), s && s.c(), n = Xe(), _ && _.c(), o = Xe(), l && l.c(), i = en();
    },
    m(r, u) {
      a && a.m(r, u), F(r, t, u), s && s.m(r, u), F(r, n, u), _ && _.m(r, u), F(r, o, u), l && l.m(r, u), F(r, i, u);
    },
    p(r, u) {
      /*p*/
      r[38].desc != null ? s ? s.p(r, u) : (s = ns(r), s.c(), s.m(n.parentNode, n)) : s && (s.d(1), s = null), /*p*/
      r[38].desc != null && /*progress_level*/
      r[14] && /*progress_level*/
      r[14][
        /*i*/
        r[40]
      ] != null ? _ || (_ = os(), _.c(), _.m(o.parentNode, o)) : _ && (_.d(1), _ = null), /*progress_level*/
      r[14] != null ? l ? l.p(r, u) : (l = is(r), l.c(), l.m(i.parentNode, i)) : l && (l.d(1), l = null);
    },
    d(r) {
      r && (D(t), D(n), D(o), D(i)), a && a.d(r), s && s.d(r), _ && _.d(r), l && l.d(r);
    }
  };
}
function V1(e) {
  let t;
  return {
    c() {
      t = te(" /");
    },
    m(n, o) {
      F(n, t, o);
    },
    d(n) {
      n && D(t);
    }
  };
}
function ns(e) {
  let t = (
    /*p*/
    e[38].desc + ""
  ), n;
  return {
    c() {
      n = te(t);
    },
    m(o, i) {
      F(o, n, i);
    },
    p(o, i) {
      i[0] & /*progress*/
      128 && t !== (t = /*p*/
      o[38].desc + "") && Ce(n, t);
    },
    d(o) {
      o && D(n);
    }
  };
}
function os(e) {
  let t;
  return {
    c() {
      t = te("-");
    },
    m(n, o) {
      F(n, t, o);
    },
    d(n) {
      n && D(t);
    }
  };
}
function is(e) {
  let t = (100 * /*progress_level*/
  (e[14][
    /*i*/
    e[40]
  ] || 0)).toFixed(1) + "", n, o;
  return {
    c() {
      n = te(t), o = te("%");
    },
    m(i, a) {
      F(i, n, a), F(i, o, a);
    },
    p(i, a) {
      a[0] & /*progress_level*/
      16384 && t !== (t = (100 * /*progress_level*/
      (i[14][
        /*i*/
        i[40]
      ] || 0)).toFixed(1) + "") && Ce(n, t);
    },
    d(i) {
      i && (D(n), D(o));
    }
  };
}
function as(e) {
  let t, n = (
    /*p*/
    (e[38].desc != null || /*progress_level*/
    e[14] && /*progress_level*/
    e[14][
      /*i*/
      e[40]
    ] != null) && ts(e)
  );
  return {
    c() {
      n && n.c(), t = en();
    },
    m(o, i) {
      n && n.m(o, i), F(o, t, i);
    },
    p(o, i) {
      /*p*/
      o[38].desc != null || /*progress_level*/
      o[14] && /*progress_level*/
      o[14][
        /*i*/
        o[40]
      ] != null ? n ? n.p(o, i) : (n = ts(o), n.c(), n.m(t.parentNode, t)) : n && (n.d(1), n = null);
    },
    d(o) {
      o && D(t), n && n.d(o);
    }
  };
}
function ls(e) {
  let t, n;
  return {
    c() {
      t = Qe("p"), n = te(
        /*loading_text*/
        e[9]
      ), ze(t, "class", "loading svelte-1yserjw");
    },
    m(o, i) {
      F(o, t, i), $t(t, n);
    },
    p(o, i) {
      i[0] & /*loading_text*/
      512 && Ce(
        n,
        /*loading_text*/
        o[9]
      );
    },
    d(o) {
      o && D(t);
    }
  };
}
function z1(e) {
  let t, n, o, i, a;
  const s = [M1, I1], _ = [];
  function l(r, u) {
    return (
      /*status*/
      r[4] === "pending" ? 0 : (
        /*status*/
        r[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(n = l(e)) && (o = _[n] = s[n](e)), {
    c() {
      t = Qe("div"), o && o.c(), ze(t, "class", i = "wrap " + /*variant*/
      e[8] + " " + /*show_progress*/
      e[6] + " svelte-1yserjw"), ge(t, "hide", !/*status*/
      e[4] || /*status*/
      e[4] === "complete" || /*show_progress*/
      e[6] === "hidden"), ge(
        t,
        "translucent",
        /*variant*/
        e[8] === "center" && /*status*/
        (e[4] === "pending" || /*status*/
        e[4] === "error") || /*translucent*/
        e[11] || /*show_progress*/
        e[6] === "minimal"
      ), ge(
        t,
        "generating",
        /*status*/
        e[4] === "generating"
      ), ge(
        t,
        "border",
        /*border*/
        e[12]
      ), st(
        t,
        "position",
        /*absolute*/
        e[10] ? "absolute" : "static"
      ), st(
        t,
        "padding",
        /*absolute*/
        e[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(r, u) {
      F(r, t, u), ~n && _[n].m(t, null), e[31](t), a = !0;
    },
    p(r, u) {
      let f = n;
      n = l(r), n === f ? ~n && _[n].p(r, u) : (o && (D_(), Jt(_[f], 1, 1, () => {
        _[f] = null;
      }), M_()), ~n ? (o = _[n], o ? o.p(r, u) : (o = _[n] = s[n](r), o.c()), Wt(o, 1), o.m(t, null)) : o = null), (!a || u[0] & /*variant, show_progress*/
      320 && i !== (i = "wrap " + /*variant*/
      r[8] + " " + /*show_progress*/
      r[6] + " svelte-1yserjw")) && ze(t, "class", i), (!a || u[0] & /*variant, show_progress, status, show_progress*/
      336) && ge(t, "hide", !/*status*/
      r[4] || /*status*/
      r[4] === "complete" || /*show_progress*/
      r[6] === "hidden"), (!a || u[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && ge(
        t,
        "translucent",
        /*variant*/
        r[8] === "center" && /*status*/
        (r[4] === "pending" || /*status*/
        r[4] === "error") || /*translucent*/
        r[11] || /*show_progress*/
        r[6] === "minimal"
      ), (!a || u[0] & /*variant, show_progress, status*/
      336) && ge(
        t,
        "generating",
        /*status*/
        r[4] === "generating"
      ), (!a || u[0] & /*variant, show_progress, border*/
      4416) && ge(
        t,
        "border",
        /*border*/
        r[12]
      ), u[0] & /*absolute*/
      1024 && st(
        t,
        "position",
        /*absolute*/
        r[10] ? "absolute" : "static"
      ), u[0] & /*absolute*/
      1024 && st(
        t,
        "padding",
        /*absolute*/
        r[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(r) {
      a || (Wt(o), a = !0);
    },
    o(r) {
      Jt(o), a = !1;
    },
    d(r) {
      r && D(t), ~n && _[n].d(), e[31](null);
    }
  };
}
let Fn = [], Wo = !1;
async function X1(e, t = !0) {
  if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && t !== !0)) {
    if (Fn.push(e), !Wo) Wo = !0;
    else return;
    await N1(), requestAnimationFrame(() => {
      let n = [0, 0];
      for (let o = 0; o < Fn.length; o++) {
        const a = Fn[o].getBoundingClientRect();
        (o === 0 || a.top + window.scrollY <= n[0]) && (n[0] = a.top + window.scrollY, n[1] = o);
      }
      window.scrollTo({ top: n[0] - 20, behavior: "smooth" }), Wo = !1, Fn = [];
    });
  }
}
function Z1(e, t, n) {
  let o, { $$slots: i = {}, $$scope: a } = t, { i18n: s } = t, { eta: _ = null } = t, { queue_position: l } = t, { queue_size: r } = t, { status: u } = t, { scroll_to_output: f = !1 } = t, { timer: d = !0 } = t, { show_progress: c = "full" } = t, { message: m = null } = t, { progress: w = null } = t, { variant: b = "default" } = t, { loading_text: v = "Loading..." } = t, { absolute: g = !0 } = t, { translucent: p = !1 } = t, { border: h = !1 } = t, { autoscroll: S } = t, $, y = !1, C = 0, T = 0, P = null, E = null, Y = 0, R = null, Z, U = null, H = !0;
  const Q = () => {
    n(0, _ = n(26, P = n(19, B = null))), n(24, C = performance.now()), n(25, T = 0), y = !0, A();
  };
  function A() {
    requestAnimationFrame(() => {
      n(25, T = (performance.now() - C) / 1e3), y && A();
    });
  }
  function ae() {
    n(25, T = 0), n(0, _ = n(26, P = n(19, B = null))), y && (y = !1);
  }
  P1(() => {
    y && ae();
  });
  let B = null;
  function Le(q) {
    Xl[q ? "unshift" : "push"](() => {
      U = q, n(16, U), n(7, w), n(14, R), n(15, Z);
    });
  }
  function _t(q) {
    Xl[q ? "unshift" : "push"](() => {
      $ = q, n(13, $);
    });
  }
  return e.$$set = (q) => {
    "i18n" in q && n(1, s = q.i18n), "eta" in q && n(0, _ = q.eta), "queue_position" in q && n(2, l = q.queue_position), "queue_size" in q && n(3, r = q.queue_size), "status" in q && n(4, u = q.status), "scroll_to_output" in q && n(21, f = q.scroll_to_output), "timer" in q && n(5, d = q.timer), "show_progress" in q && n(6, c = q.show_progress), "message" in q && n(22, m = q.message), "progress" in q && n(7, w = q.progress), "variant" in q && n(8, b = q.variant), "loading_text" in q && n(9, v = q.loading_text), "absolute" in q && n(10, g = q.absolute), "translucent" in q && n(11, p = q.translucent), "border" in q && n(12, h = q.border), "autoscroll" in q && n(23, S = q.autoscroll), "$$scope" in q && n(28, a = q.$$scope);
  }, e.$$.update = () => {
    e.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    218103809 && (_ === null && n(0, _ = P), _ != null && P !== _ && (n(27, E = (performance.now() - C) / 1e3 + _), n(19, B = E.toFixed(1)), n(26, P = _))), e.$$.dirty[0] & /*eta_from_start, timer_diff*/
    167772160 && n(17, Y = E === null || E <= 0 || !T ? null : Math.min(T / E, 1)), e.$$.dirty[0] & /*progress*/
    128 && w != null && n(18, H = !1), e.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (w != null ? n(14, R = w.map((q) => {
      if (q.index != null && q.length != null)
        return q.index / q.length;
      if (q.progress != null)
        return q.progress;
    })) : n(14, R = null), R ? (n(15, Z = R[R.length - 1]), U && (Z === 0 ? n(16, U.style.transition = "0", U) : n(16, U.style.transition = "150ms", U))) : n(15, Z = void 0)), e.$$.dirty[0] & /*status*/
    16 && (u === "pending" ? Q() : ae()), e.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    10493968 && $ && f && (u === "pending" || u === "complete") && X1($, S), e.$$.dirty[0] & /*status, message*/
    4194320, e.$$.dirty[0] & /*timer_diff*/
    33554432 && n(20, o = T.toFixed(1));
  }, [
    _,
    s,
    l,
    r,
    u,
    d,
    c,
    w,
    b,
    v,
    g,
    p,
    h,
    $,
    R,
    Z,
    U,
    Y,
    H,
    B,
    o,
    f,
    m,
    S,
    C,
    T,
    P,
    E,
    a,
    i,
    Le,
    _t
  ];
}
class W1 extends S1 {
  constructor(t) {
    super(), T1(
      this,
      t,
      Z1,
      z1,
      H1,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 21,
        timer: 5,
        show_progress: 6,
        message: 22,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 23
      },
      null,
      [-1, -1]
    );
  }
}
const {
  SvelteComponent: Mfe,
  append: Ofe,
  attr: Dfe,
  detach: Ffe,
  init: Rfe,
  insert: Ufe,
  noop: Gfe,
  safe_not_equal: jfe,
  svg_element: Vfe
} = window.__gradio__svelte__internal, {
  SvelteComponent: zfe,
  append: Xfe,
  attr: Zfe,
  detach: Wfe,
  init: Jfe,
  insert: Qfe,
  noop: Yfe,
  safe_not_equal: Kfe,
  svg_element: xfe
} = window.__gradio__svelte__internal, {
  SvelteComponent: ede,
  append: tde,
  attr: nde,
  detach: ode,
  init: ide,
  insert: ade,
  noop: lde,
  safe_not_equal: sde,
  svg_element: _de
} = window.__gradio__svelte__internal, {
  SvelteComponent: rde,
  append: ude,
  attr: fde,
  detach: dde,
  init: cde,
  insert: pde,
  noop: mde,
  safe_not_equal: hde,
  svg_element: $de
} = window.__gradio__svelte__internal, {
  SvelteComponent: vde,
  append: gde,
  attr: wde,
  detach: bde,
  init: Sde,
  insert: Cde,
  noop: qde,
  safe_not_equal: yde,
  svg_element: kde
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ede,
  append: Tde,
  attr: Bde,
  detach: Hde,
  init: Ade,
  insert: Nde,
  noop: Pde,
  safe_not_equal: Lde,
  svg_element: Ide
} = window.__gradio__svelte__internal, {
  SvelteComponent: Mde,
  append: Ode,
  attr: Dde,
  detach: Fde,
  init: Rde,
  insert: Ude,
  noop: Gde,
  safe_not_equal: jde,
  svg_element: Vde
} = window.__gradio__svelte__internal, {
  SvelteComponent: zde,
  append: Xde,
  attr: Zde,
  detach: Wde,
  init: Jde,
  insert: Qde,
  noop: Yde,
  safe_not_equal: Kde,
  svg_element: xde
} = window.__gradio__svelte__internal, {
  SvelteComponent: ece,
  append: tce,
  attr: nce,
  detach: oce,
  init: ice,
  insert: ace,
  noop: lce,
  safe_not_equal: sce,
  set_style: _ce,
  svg_element: rce
} = window.__gradio__svelte__internal, {
  SvelteComponent: uce,
  append: fce,
  attr: dce,
  detach: cce,
  init: pce,
  insert: mce,
  noop: hce,
  safe_not_equal: $ce,
  svg_element: vce
} = window.__gradio__svelte__internal, {
  SvelteComponent: gce,
  append: wce,
  attr: bce,
  detach: Sce,
  init: Cce,
  insert: qce,
  noop: yce,
  safe_not_equal: kce,
  svg_element: Ece
} = window.__gradio__svelte__internal, {
  SvelteComponent: Tce,
  append: Bce,
  attr: Hce,
  detach: Ace,
  init: Nce,
  insert: Pce,
  noop: Lce,
  safe_not_equal: Ice,
  svg_element: Mce
} = window.__gradio__svelte__internal, {
  SvelteComponent: Oce,
  append: Dce,
  attr: Fce,
  detach: Rce,
  init: Uce,
  insert: Gce,
  noop: jce,
  safe_not_equal: Vce,
  svg_element: zce
} = window.__gradio__svelte__internal, {
  SvelteComponent: Xce,
  append: Zce,
  attr: Wce,
  detach: Jce,
  init: Qce,
  insert: Yce,
  noop: Kce,
  safe_not_equal: xce,
  svg_element: epe
} = window.__gradio__svelte__internal, {
  SvelteComponent: tpe,
  append: npe,
  attr: ope,
  detach: ipe,
  init: ape,
  insert: lpe,
  noop: spe,
  safe_not_equal: _pe,
  svg_element: rpe
} = window.__gradio__svelte__internal, {
  SvelteComponent: upe,
  append: fpe,
  attr: dpe,
  detach: cpe,
  init: ppe,
  insert: mpe,
  noop: hpe,
  safe_not_equal: $pe,
  svg_element: vpe
} = window.__gradio__svelte__internal, {
  SvelteComponent: gpe,
  append: wpe,
  attr: bpe,
  detach: Spe,
  init: Cpe,
  insert: qpe,
  noop: ype,
  safe_not_equal: kpe,
  svg_element: Epe
} = window.__gradio__svelte__internal, {
  SvelteComponent: Tpe,
  append: Bpe,
  attr: Hpe,
  detach: Ape,
  init: Npe,
  insert: Ppe,
  noop: Lpe,
  safe_not_equal: Ipe,
  svg_element: Mpe
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ope,
  append: Dpe,
  attr: Fpe,
  detach: Rpe,
  init: Upe,
  insert: Gpe,
  noop: jpe,
  safe_not_equal: Vpe,
  svg_element: zpe
} = window.__gradio__svelte__internal, {
  SvelteComponent: Xpe,
  append: Zpe,
  attr: Wpe,
  detach: Jpe,
  init: Qpe,
  insert: Ype,
  noop: Kpe,
  safe_not_equal: xpe,
  svg_element: eme
} = window.__gradio__svelte__internal, {
  SvelteComponent: tme,
  append: nme,
  attr: ome,
  detach: ime,
  init: ame,
  insert: lme,
  noop: sme,
  safe_not_equal: _me,
  svg_element: rme
} = window.__gradio__svelte__internal, {
  SvelteComponent: ume,
  append: fme,
  attr: dme,
  detach: cme,
  init: pme,
  insert: mme,
  noop: hme,
  safe_not_equal: $me,
  svg_element: vme
} = window.__gradio__svelte__internal, {
  SvelteComponent: gme,
  append: wme,
  attr: bme,
  detach: Sme,
  init: Cme,
  insert: qme,
  noop: yme,
  safe_not_equal: kme,
  svg_element: Eme
} = window.__gradio__svelte__internal, {
  SvelteComponent: Tme,
  append: Bme,
  attr: Hme,
  detach: Ame,
  init: Nme,
  insert: Pme,
  noop: Lme,
  safe_not_equal: Ime,
  svg_element: Mme
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ome,
  append: Dme,
  attr: Fme,
  detach: Rme,
  init: Ume,
  insert: Gme,
  noop: jme,
  safe_not_equal: Vme,
  svg_element: zme
} = window.__gradio__svelte__internal, {
  SvelteComponent: Xme,
  append: Zme,
  attr: Wme,
  detach: Jme,
  init: Qme,
  insert: Yme,
  noop: Kme,
  safe_not_equal: xme,
  svg_element: ehe
} = window.__gradio__svelte__internal, {
  SvelteComponent: the,
  append: nhe,
  attr: ohe,
  detach: ihe,
  init: ahe,
  insert: lhe,
  noop: she,
  safe_not_equal: _he,
  svg_element: rhe
} = window.__gradio__svelte__internal, {
  SvelteComponent: uhe,
  append: fhe,
  attr: dhe,
  detach: che,
  init: phe,
  insert: mhe,
  noop: hhe,
  safe_not_equal: $he,
  svg_element: vhe
} = window.__gradio__svelte__internal, {
  SvelteComponent: ghe,
  append: whe,
  attr: bhe,
  detach: She,
  init: Che,
  insert: qhe,
  noop: yhe,
  safe_not_equal: khe,
  svg_element: Ehe
} = window.__gradio__svelte__internal, {
  SvelteComponent: The,
  append: Bhe,
  attr: Hhe,
  detach: Ahe,
  init: Nhe,
  insert: Phe,
  noop: Lhe,
  safe_not_equal: Ihe,
  svg_element: Mhe
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ohe,
  append: Dhe,
  attr: Fhe,
  detach: Rhe,
  init: Uhe,
  insert: Ghe,
  noop: jhe,
  safe_not_equal: Vhe,
  svg_element: zhe
} = window.__gradio__svelte__internal, {
  SvelteComponent: Xhe,
  append: Zhe,
  attr: Whe,
  detach: Jhe,
  init: Qhe,
  insert: Yhe,
  noop: Khe,
  safe_not_equal: xhe,
  svg_element: e1e
} = window.__gradio__svelte__internal, {
  SvelteComponent: t1e,
  append: n1e,
  attr: o1e,
  detach: i1e,
  init: a1e,
  insert: l1e,
  noop: s1e,
  safe_not_equal: _1e,
  svg_element: r1e
} = window.__gradio__svelte__internal, {
  SvelteComponent: u1e,
  append: f1e,
  attr: d1e,
  detach: c1e,
  init: p1e,
  insert: m1e,
  noop: h1e,
  safe_not_equal: $1e,
  svg_element: v1e
} = window.__gradio__svelte__internal, {
  SvelteComponent: g1e,
  append: w1e,
  attr: b1e,
  detach: S1e,
  init: C1e,
  insert: q1e,
  noop: y1e,
  safe_not_equal: k1e,
  svg_element: E1e
} = window.__gradio__svelte__internal, {
  SvelteComponent: T1e,
  append: B1e,
  attr: H1e,
  detach: A1e,
  init: N1e,
  insert: P1e,
  noop: L1e,
  safe_not_equal: I1e,
  svg_element: M1e
} = window.__gradio__svelte__internal, {
  SvelteComponent: O1e,
  append: D1e,
  attr: F1e,
  detach: R1e,
  init: U1e,
  insert: G1e,
  noop: j1e,
  safe_not_equal: V1e,
  svg_element: z1e
} = window.__gradio__svelte__internal, {
  SvelteComponent: X1e,
  append: Z1e,
  attr: W1e,
  detach: J1e,
  init: Q1e,
  insert: Y1e,
  noop: K1e,
  safe_not_equal: x1e,
  svg_element: e0e
} = window.__gradio__svelte__internal, {
  SvelteComponent: t0e,
  append: n0e,
  attr: o0e,
  detach: i0e,
  init: a0e,
  insert: l0e,
  noop: s0e,
  safe_not_equal: _0e,
  set_style: r0e,
  svg_element: u0e
} = window.__gradio__svelte__internal, {
  SvelteComponent: f0e,
  append: d0e,
  attr: c0e,
  detach: p0e,
  init: m0e,
  insert: h0e,
  noop: $0e,
  safe_not_equal: v0e,
  svg_element: g0e
} = window.__gradio__svelte__internal, {
  SvelteComponent: w0e,
  append: b0e,
  attr: S0e,
  detach: C0e,
  init: q0e,
  insert: y0e,
  noop: k0e,
  safe_not_equal: E0e,
  svg_element: T0e
} = window.__gradio__svelte__internal, {
  SvelteComponent: B0e,
  append: H0e,
  attr: A0e,
  detach: N0e,
  init: P0e,
  insert: L0e,
  noop: I0e,
  safe_not_equal: M0e,
  svg_element: O0e
} = window.__gradio__svelte__internal, {
  SvelteComponent: D0e,
  append: F0e,
  attr: R0e,
  detach: U0e,
  init: G0e,
  insert: j0e,
  noop: V0e,
  safe_not_equal: z0e,
  svg_element: X0e
} = window.__gradio__svelte__internal, {
  SvelteComponent: Z0e,
  append: W0e,
  attr: J0e,
  detach: Q0e,
  init: Y0e,
  insert: K0e,
  noop: x0e,
  safe_not_equal: e$e,
  svg_element: t$e
} = window.__gradio__svelte__internal, {
  SvelteComponent: n$e,
  append: o$e,
  attr: i$e,
  detach: a$e,
  init: l$e,
  insert: s$e,
  noop: _$e,
  safe_not_equal: r$e,
  svg_element: u$e
} = window.__gradio__svelte__internal, {
  SvelteComponent: f$e,
  append: d$e,
  attr: c$e,
  detach: p$e,
  init: m$e,
  insert: h$e,
  noop: $$e,
  safe_not_equal: v$e,
  svg_element: g$e
} = window.__gradio__svelte__internal, {
  SvelteComponent: w$e,
  append: b$e,
  attr: S$e,
  detach: C$e,
  init: q$e,
  insert: y$e,
  noop: k$e,
  safe_not_equal: E$e,
  svg_element: T$e
} = window.__gradio__svelte__internal, {
  SvelteComponent: B$e,
  append: H$e,
  attr: A$e,
  detach: N$e,
  init: P$e,
  insert: L$e,
  noop: I$e,
  safe_not_equal: M$e,
  svg_element: O$e,
  text: D$e
} = window.__gradio__svelte__internal, {
  SvelteComponent: F$e,
  append: R$e,
  attr: U$e,
  detach: G$e,
  init: j$e,
  insert: V$e,
  noop: z$e,
  safe_not_equal: X$e,
  svg_element: Z$e
} = window.__gradio__svelte__internal, {
  SvelteComponent: W$e,
  append: J$e,
  attr: Q$e,
  detach: Y$e,
  init: K$e,
  insert: x$e,
  noop: eve,
  safe_not_equal: tve,
  svg_element: nve
} = window.__gradio__svelte__internal, {
  SvelteComponent: ove,
  append: ive,
  attr: ave,
  detach: lve,
  init: sve,
  insert: _ve,
  noop: rve,
  safe_not_equal: uve,
  svg_element: fve
} = window.__gradio__svelte__internal, {
  SvelteComponent: dve,
  append: cve,
  attr: pve,
  detach: mve,
  init: hve,
  insert: $ve,
  noop: vve,
  safe_not_equal: gve,
  svg_element: wve
} = window.__gradio__svelte__internal, {
  SvelteComponent: bve,
  append: Sve,
  attr: Cve,
  detach: qve,
  init: yve,
  insert: kve,
  noop: Eve,
  safe_not_equal: Tve,
  svg_element: Bve
} = window.__gradio__svelte__internal, {
  SvelteComponent: Hve,
  append: Ave,
  attr: Nve,
  detach: Pve,
  init: Lve,
  insert: Ive,
  noop: Mve,
  safe_not_equal: Ove,
  svg_element: Dve,
  text: Fve
} = window.__gradio__svelte__internal, {
  SvelteComponent: Rve,
  append: Uve,
  attr: Gve,
  detach: jve,
  init: Vve,
  insert: zve,
  noop: Xve,
  safe_not_equal: Zve,
  svg_element: Wve,
  text: Jve
} = window.__gradio__svelte__internal, {
  SvelteComponent: Qve,
  append: Yve,
  attr: Kve,
  detach: xve,
  init: ege,
  insert: tge,
  noop: nge,
  safe_not_equal: oge,
  svg_element: ige,
  text: age
} = window.__gradio__svelte__internal, {
  SvelteComponent: lge,
  append: sge,
  attr: _ge,
  detach: rge,
  init: uge,
  insert: fge,
  noop: dge,
  safe_not_equal: cge,
  svg_element: pge
} = window.__gradio__svelte__internal, {
  SvelteComponent: mge,
  append: hge,
  attr: $ge,
  detach: vge,
  init: gge,
  insert: wge,
  noop: bge,
  safe_not_equal: Sge,
  svg_element: Cge
} = window.__gradio__svelte__internal, {
  SvelteComponent: qge,
  add_render_callback: yge,
  append: kge,
  attr: Ege,
  bubble: Tge,
  check_outros: Bge,
  create_component: Hge,
  create_in_transition: Age,
  create_out_transition: Nge,
  destroy_component: Pge,
  detach: Lge,
  element: Ige,
  group_outros: Mge,
  init: Oge,
  insert: Dge,
  listen: Fge,
  mount_component: Rge,
  run_all: Uge,
  safe_not_equal: Gge,
  set_data: jge,
  space: Vge,
  stop_propagation: zge,
  text: Xge,
  transition_in: Zge,
  transition_out: Wge
} = window.__gradio__svelte__internal, { createEventDispatcher: Jge, onMount: Qge } = window.__gradio__svelte__internal, {
  SvelteComponent: Yge,
  append: Kge,
  attr: xge,
  bubble: e2e,
  check_outros: t2e,
  create_animation: n2e,
  create_component: o2e,
  destroy_component: i2e,
  detach: a2e,
  element: l2e,
  ensure_array_like: s2e,
  fix_and_outro_and_destroy_block: _2e,
  fix_position: r2e,
  group_outros: u2e,
  init: f2e,
  insert: d2e,
  mount_component: c2e,
  noop: p2e,
  safe_not_equal: m2e,
  set_style: h2e,
  space: $2e,
  transition_in: v2e,
  transition_out: g2e,
  update_keyed_each: w2e
} = window.__gradio__svelte__internal, {
  SvelteComponent: J1,
  append: Rn,
  attr: ut,
  detach: Q1,
  element: Jo,
  init: Y1,
  init_binding_group: K1,
  insert: x1,
  listen: e0,
  noop: ss,
  safe_not_equal: t0,
  set_data: n0,
  set_input_value: _s,
  space: o0,
  text: i0,
  toggle_class: Un
} = window.__gradio__svelte__internal, { createEventDispatcher: a0 } = window.__gradio__svelte__internal;
function l0(e) {
  let t, n, o = !1, i, a, s, _, l, r, u;
  return l = K1(
    /*$$binding_groups*/
    e[6][0]
  ), {
    c() {
      t = Jo("label"), n = Jo("input"), i = o0(), a = Jo("span"), s = i0(
        /*display_value*/
        e[1]
      ), n.disabled = /*disabled*/
      e[3], ut(n, "type", "radio"), ut(n, "name", "radio-" + ++s0), n.__value = /*internal_value*/
      e[2], _s(n, n.__value), ut(n, "class", "svelte-1b796z"), ut(a, "class", "ml-2 svelte-1b796z"), ut(t, "data-testid", _ = /*display_value*/
      e[1] + "-radio-label"), ut(t, "class", "svelte-1b796z"), Un(
        t,
        "disabled",
        /*disabled*/
        e[3]
      ), Un(
        t,
        "selected",
        /*is_selected*/
        e[4]
      ), l.p(n);
    },
    m(f, d) {
      x1(f, t, d), Rn(t, n), n.checked = n.__value === /*selected*/
      e[0], Rn(t, i), Rn(t, a), Rn(a, s), r || (u = e0(
        n,
        "change",
        /*input_change_handler*/
        e[5]
      ), r = !0);
    },
    p(f, [d]) {
      d & /*disabled*/
      8 && (n.disabled = /*disabled*/
      f[3]), d & /*internal_value*/
      4 && (n.__value = /*internal_value*/
      f[2], _s(n, n.__value), o = !0), (o || d & /*selected*/
      1) && (n.checked = n.__value === /*selected*/
      f[0]), d & /*display_value*/
      2 && n0(
        s,
        /*display_value*/
        f[1]
      ), d & /*display_value*/
      2 && _ !== (_ = /*display_value*/
      f[1] + "-radio-label") && ut(t, "data-testid", _), d & /*disabled*/
      8 && Un(
        t,
        "disabled",
        /*disabled*/
        f[3]
      ), d & /*is_selected*/
      16 && Un(
        t,
        "selected",
        /*is_selected*/
        f[4]
      );
    },
    i: ss,
    o: ss,
    d(f) {
      f && Q1(t), l.r(), r = !1, u();
    }
  };
}
let s0 = 0;
function _0(e, t, n) {
  let { display_value: o } = t, { internal_value: i } = t, { disabled: a = !1 } = t, { selected: s = null } = t;
  const _ = a0();
  let l = !1;
  async function r(d, c) {
    n(4, l = d === c), l && _("input", c);
  }
  const u = [[]];
  function f() {
    s = this.__value, n(0, s);
  }
  return e.$$set = (d) => {
    "display_value" in d && n(1, o = d.display_value), "internal_value" in d && n(2, i = d.internal_value), "disabled" in d && n(3, a = d.disabled), "selected" in d && n(0, s = d.selected);
  }, e.$$.update = () => {
    e.$$.dirty & /*selected, internal_value*/
    5 && r(s, i);
  }, [
    s,
    o,
    i,
    a,
    l,
    f,
    u
  ];
}
class r0 extends J1 {
  constructor(t) {
    super(), Y1(this, t, _0, l0, t0, {
      display_value: 1,
      internal_value: 2,
      disabled: 3,
      selected: 0
    });
  }
}
const {
  SvelteComponent: b2e,
  attr: S2e,
  detach: C2e,
  element: q2e,
  init: y2e,
  insert: k2e,
  noop: E2e,
  safe_not_equal: T2e,
  toggle_class: B2e
} = window.__gradio__svelte__internal, {
  SvelteComponent: u0,
  add_flush_callback: f0,
  assign: d0,
  attr: c0,
  bind: p0,
  binding_callbacks: m0,
  check_outros: h0,
  create_component: fo,
  destroy_component: co,
  detach: fn,
  element: $0,
  empty: v0,
  ensure_array_like: rs,
  get_spread_object: g0,
  get_spread_update: w0,
  group_outros: b0,
  init: S0,
  insert: dn,
  mount_component: po,
  outro_and_destroy_block: C0,
  safe_not_equal: q0,
  set_data: y0,
  space: us,
  text: k0,
  transition_in: cn,
  transition_out: pn,
  update_keyed_each: E0
} = window.__gradio__svelte__internal, { afterUpdate: T0 } = window.__gradio__svelte__internal;
function fs(e, t, n) {
  const o = e.slice();
  return o[19] = t[n][0], o[20] = t[n][1], o[22] = n, o;
}
function B0(e) {
  let t;
  return {
    c() {
      t = k0(
        /*label*/
        e[2]
      );
    },
    m(n, o) {
      dn(n, t, o);
    },
    p(n, o) {
      o & /*label*/
      4 && y0(
        t,
        /*label*/
        n[2]
      );
    },
    d(n) {
      n && fn(t);
    }
  };
}
function ds(e, t) {
  let n, o, i, a;
  function s(r) {
    t[16](r);
  }
  function _() {
    return (
      /*input_handler*/
      t[17](
        /*internal_value*/
        t[20],
        /*i*/
        t[22]
      )
    );
  }
  let l = {
    display_value: (
      /*display_value*/
      t[19]
    ),
    internal_value: (
      /*internal_value*/
      t[20]
    ),
    disabled: (
      /*disabled*/
      t[13]
    )
  };
  return (
    /*value*/
    t[0] !== void 0 && (l.selected = /*value*/
    t[0]), o = new r0({ props: l }), m0.push(() => p0(o, "selected", s)), o.$on("input", _), {
      key: e,
      first: null,
      c() {
        n = v0(), fo(o.$$.fragment), this.first = n;
      },
      m(r, u) {
        dn(r, n, u), po(o, r, u), a = !0;
      },
      p(r, u) {
        t = r;
        const f = {};
        u & /*choices*/
        128 && (f.display_value = /*display_value*/
        t[19]), u & /*choices*/
        128 && (f.internal_value = /*internal_value*/
        t[20]), u & /*disabled*/
        8192 && (f.disabled = /*disabled*/
        t[13]), !i && u & /*value*/
        1 && (i = !0, f.selected = /*value*/
        t[0], f0(() => i = !1)), o.$set(f);
      },
      i(r) {
        a || (cn(o.$$.fragment, r), a = !0);
      },
      o(r) {
        pn(o.$$.fragment, r), a = !1;
      },
      d(r) {
        r && fn(n), co(o, r);
      }
    }
  );
}
function H0(e) {
  let t, n, o, i, a, s = [], _ = /* @__PURE__ */ new Map(), l;
  const r = [
    { autoscroll: (
      /*gradio*/
      e[1].autoscroll
    ) },
    { i18n: (
      /*gradio*/
      e[1].i18n
    ) },
    /*loading_status*/
    e[12]
  ];
  let u = {};
  for (let c = 0; c < r.length; c += 1)
    u = d0(u, r[c]);
  t = new W1({ props: u }), o = new f1({
    props: {
      show_label: (
        /*show_label*/
        e[8]
      ),
      info: (
        /*info*/
        e[3]
      ),
      $$slots: { default: [B0] },
      $$scope: { ctx: e }
    }
  });
  let f = rs(
    /*choices*/
    e[7]
  );
  const d = (c) => (
    /*i*/
    c[22]
  );
  for (let c = 0; c < f.length; c += 1) {
    let m = fs(e, f, c), w = d(m);
    _.set(w, s[c] = ds(w, m));
  }
  return {
    c() {
      fo(t.$$.fragment), n = us(), fo(o.$$.fragment), i = us(), a = $0("div");
      for (let c = 0; c < s.length; c += 1)
        s[c].c();
      c0(a, "class", "wrap svelte-1wdncym");
    },
    m(c, m) {
      po(t, c, m), dn(c, n, m), po(o, c, m), dn(c, i, m), dn(c, a, m);
      for (let w = 0; w < s.length; w += 1)
        s[w] && s[w].m(a, null);
      l = !0;
    },
    p(c, m) {
      const w = m & /*gradio, loading_status*/
      4098 ? w0(r, [
        m & /*gradio*/
        2 && { autoscroll: (
          /*gradio*/
          c[1].autoscroll
        ) },
        m & /*gradio*/
        2 && { i18n: (
          /*gradio*/
          c[1].i18n
        ) },
        m & /*loading_status*/
        4096 && g0(
          /*loading_status*/
          c[12]
        )
      ]) : {};
      t.$set(w);
      const b = {};
      m & /*show_label*/
      256 && (b.show_label = /*show_label*/
      c[8]), m & /*info*/
      8 && (b.info = /*info*/
      c[3]), m & /*$$scope, label*/
      8388612 && (b.$$scope = { dirty: m, ctx: c }), o.$set(b), m & /*choices, disabled, value, gradio*/
      8323 && (f = rs(
        /*choices*/
        c[7]
      ), b0(), s = E0(s, m, d, 1, c, f, _, a, C0, ds, null, fs), h0());
    },
    i(c) {
      if (!l) {
        cn(t.$$.fragment, c), cn(o.$$.fragment, c);
        for (let m = 0; m < f.length; m += 1)
          cn(s[m]);
        l = !0;
      }
    },
    o(c) {
      pn(t.$$.fragment, c), pn(o.$$.fragment, c);
      for (let m = 0; m < s.length; m += 1)
        pn(s[m]);
      l = !1;
    },
    d(c) {
      c && (fn(n), fn(i), fn(a)), co(t, c), co(o, c);
      for (let m = 0; m < s.length; m += 1)
        s[m].d();
    }
  };
}
function A0(e) {
  let t, n;
  return t = new Th({
    props: {
      visible: (
        /*visible*/
        e[6]
      ),
      type: "fieldset",
      elem_id: (
        /*elem_id*/
        e[4]
      ),
      elem_classes: (
        /*elem_classes*/
        e[5]
      ),
      container: (
        /*container*/
        e[9]
      ),
      scale: (
        /*scale*/
        e[10]
      ),
      min_width: (
        /*min_width*/
        e[11]
      ),
      $$slots: { default: [H0] },
      $$scope: { ctx: e }
    }
  }), {
    c() {
      fo(t.$$.fragment);
    },
    m(o, i) {
      po(t, o, i), n = !0;
    },
    p(o, [i]) {
      const a = {};
      i & /*visible*/
      64 && (a.visible = /*visible*/
      o[6]), i & /*elem_id*/
      16 && (a.elem_id = /*elem_id*/
      o[4]), i & /*elem_classes*/
      32 && (a.elem_classes = /*elem_classes*/
      o[5]), i & /*container*/
      512 && (a.container = /*container*/
      o[9]), i & /*scale*/
      1024 && (a.scale = /*scale*/
      o[10]), i & /*min_width*/
      2048 && (a.min_width = /*min_width*/
      o[11]), i & /*$$scope, choices, disabled, value, gradio, show_label, info, label, loading_status*/
      8401295 && (a.$$scope = { dirty: i, ctx: o }), t.$set(a);
    },
    i(o) {
      n || (cn(t.$$.fragment, o), n = !0);
    },
    o(o) {
      pn(t.$$.fragment, o), n = !1;
    },
    d(o) {
      co(t, o);
    }
  };
}
function N0(e, t, n) {
  let o, { gradio: i } = t, { label: a = i.i18n("radio.radio") } = t, { info: s = void 0 } = t, { elem_id: _ = "" } = t, { elem_classes: l = [] } = t, { visible: r = !0 } = t, { value: u = null } = t, { value_is_output: f = !1 } = t, { choices: d = [] } = t, { show_label: c = !0 } = t, { container: m = !1 } = t, { scale: w = null } = t, { min_width: b = void 0 } = t, { loading_status: v } = t, { interactive: g = !0 } = t;
  function p() {
    i.dispatch("change"), f || i.dispatch("input");
  }
  T0(() => {
    n(14, f = !1);
  });
  function h($) {
    u = $, n(0, u);
  }
  const S = ($, y) => i.dispatch("select", { value: $, index: y });
  return e.$$set = ($) => {
    "gradio" in $ && n(1, i = $.gradio), "label" in $ && n(2, a = $.label), "info" in $ && n(3, s = $.info), "elem_id" in $ && n(4, _ = $.elem_id), "elem_classes" in $ && n(5, l = $.elem_classes), "visible" in $ && n(6, r = $.visible), "value" in $ && n(0, u = $.value), "value_is_output" in $ && n(14, f = $.value_is_output), "choices" in $ && n(7, d = $.choices), "show_label" in $ && n(8, c = $.show_label), "container" in $ && n(9, m = $.container), "scale" in $ && n(10, w = $.scale), "min_width" in $ && n(11, b = $.min_width), "loading_status" in $ && n(12, v = $.loading_status), "interactive" in $ && n(15, g = $.interactive);
  }, e.$$.update = () => {
    e.$$.dirty & /*value*/
    1 && p(), e.$$.dirty & /*interactive*/
    32768 && n(13, o = !g);
  }, [
    u,
    i,
    a,
    s,
    _,
    l,
    r,
    d,
    c,
    m,
    w,
    b,
    v,
    o,
    f,
    g,
    h,
    S
  ];
}
let P0 = class extends u0 {
  constructor(t) {
    super(), S0(this, t, N0, A0, q0, {
      gradio: 1,
      label: 2,
      info: 3,
      elem_id: 4,
      elem_classes: 5,
      visible: 6,
      value: 0,
      value_is_output: 14,
      choices: 7,
      show_label: 8,
      container: 9,
      scale: 10,
      min_width: 11,
      loading_status: 12,
      interactive: 15
    });
  }
};
const {
  SvelteComponent: L0,
  add_flush_callback: yi,
  append: nt,
  attr: ft,
  bind: ki,
  binding_callbacks: Ei,
  create_component: Ti,
  destroy_component: Bi,
  detach: Qo,
  element: Bt,
  init: I0,
  insert: Yo,
  listen: M0,
  mount_component: Hi,
  safe_not_equal: O0,
  set_input_value: cs,
  space: on,
  transition_in: Ai,
  transition_out: Ni
} = window.__gradio__svelte__internal;
function D0(e) {
  let t, n, o, i, a, s, _, l, r, u, f, d, c, m, w, b, v, g;
  function p(y) {
    e[4](y);
  }
  let h = {
    gradio: (
      /*gradio*/
      e[3]
    ),
    label: "Prompt type",
    choices: [["positive", "positive"], ["negative", "negative"]],
    interactive: !0
  };
  /*cond*/
  e[0].prompt_type !== void 0 && (h.value = /*cond*/
  e[0].prompt_type), i = new P0({ props: h }), Ei.push(() => ki(i, "value", p));
  function S(y) {
    e[5](y);
  }
  let $ = {
    gradio: (
      /*gradio*/
      e[3]
    ),
    label: "Invert condition",
    interactive: !0
  };
  return (
    /*cond*/
    e[0].invert !== void 0 && ($.value = /*cond*/
    e[0].invert), _ = new dh({ props: $ }), Ei.push(() => ki(_, "value", S)), {
      c() {
        t = Bt("div"), n = on(), o = Bt("div"), Ti(i.$$.fragment), s = on(), Ti(_.$$.fragment), r = on(), u = Bt("div"), f = on(), d = Bt("div"), c = Bt("span"), c.textContent = "Condition prompt", m = on(), w = Bt("input"), ft(t, "class", "break svelte-10z4w66"), ft(u, "class", "break svelte-10z4w66"), ft(w, "type", "text"), ft(w, "placeholder", ", to separate"), ft(w, "class", "svelte-10z4w66"), ft(d, "class", "input-group svelte-10z4w66"), ft(o, "class", "input-group highlight-field svelte-10z4w66");
      },
      m(y, C) {
        Yo(y, t, C), Yo(y, n, C), Yo(y, o, C), Hi(i, o, null), nt(o, s), Hi(_, o, null), nt(o, r), nt(o, u), nt(o, f), nt(o, d), nt(d, c), nt(d, m), nt(d, w), cs(
          w,
          /*cond*/
          e[0].prompt
        ), b = !0, v || (g = M0(
          w,
          "input",
          /*input_input_handler*/
          e[6]
        ), v = !0);
      },
      p(y, C) {
        const T = {};
        C & /*gradio*/
        8 && (T.gradio = /*gradio*/
        y[3]), !a && C & /*cond*/
        1 && (a = !0, T.value = /*cond*/
        y[0].prompt_type, yi(() => a = !1)), i.$set(T);
        const P = {};
        C & /*gradio*/
        8 && (P.gradio = /*gradio*/
        y[3]), !l && C & /*cond*/
        1 && (l = !0, P.value = /*cond*/
        y[0].invert, yi(() => l = !1)), _.$set(P), C & /*cond*/
        1 && w.value !== /*cond*/
        y[0].prompt && cs(
          w,
          /*cond*/
          y[0].prompt
        );
      },
      i(y) {
        b || (Ai(i.$$.fragment, y), Ai(_.$$.fragment, y), b = !0);
      },
      o(y) {
        Ni(i.$$.fragment, y), Ni(_.$$.fragment, y), b = !1;
      },
      d(y) {
        y && (Qo(t), Qo(n), Qo(o)), Bi(i), Bi(_), v = !1, g();
      }
    }
  );
}
function F0(e) {
  let t, n, o;
  function i(s) {
    e[7](s);
  }
  let a = {
    theme: "if-prompt",
    onDelete: (
      /*onDelete*/
      e[2]
    ),
    otherConditions: (
      /*otherConditions*/
      e[1]
    ),
    gradio: (
      /*gradio*/
      e[3]
    ),
    $$slots: { default: [D0] },
    $$scope: { ctx: e }
  };
  return (
    /*cond*/
    e[0] !== void 0 && (a.cond = /*cond*/
    e[0]), t = new r_({ props: a }), Ei.push(() => ki(t, "cond", i)), {
      c() {
        Ti(t.$$.fragment);
      },
      m(s, _) {
        Hi(t, s, _), o = !0;
      },
      p(s, [_]) {
        const l = {};
        _ & /*onDelete*/
        4 && (l.onDelete = /*onDelete*/
        s[2]), _ & /*otherConditions*/
        2 && (l.otherConditions = /*otherConditions*/
        s[1]), _ & /*gradio*/
        8 && (l.gradio = /*gradio*/
        s[3]), _ & /*$$scope, cond, gradio*/
        265 && (l.$$scope = { dirty: _, ctx: s }), !n && _ & /*cond*/
        1 && (n = !0, l.cond = /*cond*/
        s[0], yi(() => n = !1)), t.$set(l);
      },
      i(s) {
        o || (Ai(t.$$.fragment, s), o = !0);
      },
      o(s) {
        Ni(t.$$.fragment, s), o = !1;
      },
      d(s) {
        Bi(t, s);
      }
    }
  );
}
function R0(e, t, n) {
  let { cond: o } = t, { otherConditions: i } = t, { onDelete: a } = t, { gradio: s } = t;
  function _(f) {
    e.$$.not_equal(o.prompt_type, f) && (o.prompt_type = f, n(0, o));
  }
  function l(f) {
    e.$$.not_equal(o.invert, f) && (o.invert = f, n(0, o));
  }
  function r() {
    o.prompt = this.value, n(0, o);
  }
  function u(f) {
    o = f, n(0, o);
  }
  return e.$$set = (f) => {
    "cond" in f && n(0, o = f.cond), "otherConditions" in f && n(1, i = f.otherConditions), "onDelete" in f && n(2, a = f.onDelete), "gradio" in f && n(3, s = f.gradio);
  }, [
    o,
    i,
    a,
    s,
    _,
    l,
    r,
    u
  ];
}
class U0 extends L0 {
  constructor(t) {
    super(), I0(this, t, R0, F0, O0, {
      cond: 0,
      otherConditions: 1,
      onDelete: 2,
      gradio: 3
    });
  }
}
const {
  SvelteComponent: G0,
  add_flush_callback: Ui,
  append: wn,
  attr: vt,
  bind: Gi,
  binding_callbacks: ji,
  check_outros: mo,
  create_component: Vi,
  destroy_component: zi,
  destroy_each: j0,
  detach: bn,
  element: ho,
  empty: V0,
  ensure_array_like: ps,
  group_outros: $o,
  init: z0,
  insert: Sn,
  listen: X0,
  mount_component: Xi,
  safe_not_equal: Z0,
  set_data: W0,
  space: vo,
  text: J0,
  transition_in: re,
  transition_out: Pe
} = window.__gradio__svelte__internal;
function ms(e, t, n) {
  const o = e.slice();
  o[21] = t[n], o[24] = t, o[25] = n;
  const i = (
    /*safe_value*/
    o[4].filter(function(..._) {
      return (
        /*func_2*/
        e[17](
          /*i*/
          o[25],
          ..._
        )
      );
    }).map((s) => s.key)
  );
  o[22] = i;
  const a = (
    /*otherConditions*/
    o[22].map((s) => [s, s])
  );
  return o[23] = a, o;
}
function hs(e) {
  let t, n;
  return {
    c() {
      t = ho("div"), n = J0(
        /*label*/
        e[0]
      ), vt(t, "class", "component-label svelte-gfqmaf");
    },
    m(o, i) {
      Sn(o, t, i), wn(t, n);
    },
    p(o, i) {
      i & /*label*/
      1 && W0(
        n,
        /*label*/
        o[0]
      );
    },
    d(o) {
      o && bn(t);
    }
  };
}
function $s(e) {
  let t, n, o;
  function i() {
    return (
      /*func*/
      e[13](
        /*i*/
        e[25]
      )
    );
  }
  function a(_) {
    e[14](
      _,
      /*cond*/
      e[21],
      /*each_value*/
      e[24],
      /*i*/
      e[25]
    );
  }
  let s = {
    otherConditions: (
      /*oc*/
      e[23]
    ),
    gradio: (
      /*mockGradio*/
      e[7]
    ),
    onDelete: i
  };
  return (
    /*cond*/
    e[21] !== void 0 && (s.cond = /*cond*/
    e[21]), t = new tp({ props: s }), ji.push(() => Gi(t, "cond", a)), {
      c() {
        Vi(t.$$.fragment);
      },
      m(_, l) {
        Xi(t, _, l), o = !0;
      },
      p(_, l) {
        e = _;
        const r = {};
        l & /*safe_value*/
        16 && (r.otherConditions = /*oc*/
        e[23]), l & /*mockGradio*/
        128 && (r.gradio = /*mockGradio*/
        e[7]), !n && l & /*typed_value*/
        64 && (n = !0, r.cond = /*cond*/
        e[21], Ui(() => n = !1)), t.$set(r);
      },
      i(_) {
        o || (re(t.$$.fragment, _), o = !0);
      },
      o(_) {
        Pe(t.$$.fragment, _), o = !1;
      },
      d(_) {
        zi(t, _);
      }
    }
  );
}
function vs(e) {
  let t, n, o;
  function i() {
    return (
      /*func_1*/
      e[15](
        /*i*/
        e[25]
      )
    );
  }
  function a(_) {
    e[16](
      _,
      /*cond*/
      e[21],
      /*each_value*/
      e[24],
      /*i*/
      e[25]
    );
  }
  let s = {
    otherConditions: (
      /*oc*/
      e[23]
    ),
    gradio: (
      /*mockGradio*/
      e[7]
    ),
    onDelete: i
  };
  return (
    /*cond*/
    e[21] !== void 0 && (s.cond = /*cond*/
    e[21]), t = new U0({ props: s }), ji.push(() => Gi(t, "cond", a)), {
      c() {
        Vi(t.$$.fragment);
      },
      m(_, l) {
        Xi(t, _, l), o = !0;
      },
      p(_, l) {
        e = _;
        const r = {};
        l & /*safe_value*/
        16 && (r.otherConditions = /*oc*/
        e[23]), l & /*mockGradio*/
        128 && (r.gradio = /*mockGradio*/
        e[7]), !n && l & /*typed_value*/
        64 && (n = !0, r.cond = /*cond*/
        e[21], Ui(() => n = !1)), t.$set(r);
      },
      i(_) {
        o || (re(t.$$.fragment, _), o = !0);
      },
      o(_) {
        Pe(t.$$.fragment, _), o = !1;
      },
      d(_) {
        zi(t, _);
      }
    }
  );
}
function gs(e) {
  let t = Gn(
    /*cond*/
    e[21],
    "percentage"
  ), n, o = Gn(
    /*cond*/
    e[21],
    "if_prompt"
  ), i, a, s = t && $s(e), _ = o && vs(e);
  return {
    c() {
      s && s.c(), n = vo(), _ && _.c(), i = V0();
    },
    m(l, r) {
      s && s.m(l, r), Sn(l, n, r), _ && _.m(l, r), Sn(l, i, r), a = !0;
    },
    p(l, r) {
      r & /*typed_value*/
      64 && (t = Gn(
        /*cond*/
        l[21],
        "percentage"
      )), t ? s ? (s.p(l, r), r & /*typed_value*/
      64 && re(s, 1)) : (s = $s(l), s.c(), re(s, 1), s.m(n.parentNode, n)) : s && ($o(), Pe(s, 1, 1, () => {
        s = null;
      }), mo()), r & /*typed_value*/
      64 && (o = Gn(
        /*cond*/
        l[21],
        "if_prompt"
      )), o ? _ ? (_.p(l, r), r & /*typed_value*/
      64 && re(_, 1)) : (_ = vs(l), _.c(), re(_, 1), _.m(i.parentNode, i)) : _ && ($o(), Pe(_, 1, 1, () => {
        _ = null;
      }), mo());
    },
    i(l) {
      a || (re(s), re(_), a = !0);
    },
    o(l) {
      Pe(s), Pe(_), a = !1;
    },
    d(l) {
      l && (bn(n), bn(i)), s && s.d(l), _ && _.d(l);
    }
  };
}
function ws(e) {
  let t, n, o, i, a, s, _, l;
  function r(f) {
    e[18](f);
  }
  let u = {
    gradio: (
      /*mockGradio*/
      e[7]
    ),
    choices: (
      /*availableConditions*/
      e[8]
    ),
    label: "condition type",
    max_choices: "1",
    container: "false",
    interactive: (
      /*interactive*/
      e[3]
    )
  };
  return (
    /*toAddCondition*/
    e[5] !== void 0 && (u.value = /*toAddCondition*/
    e[5]), n = new pi({ props: u }), ji.push(() => Gi(n, "value", r)), {
      c() {
        t = ho("div"), Vi(n.$$.fragment), i = vo(), a = ho("button"), a.textContent = "+ Add Condition", vt(a, "class", "add-btn svelte-gfqmaf"), vt(t, "class", "row svelte-gfqmaf");
      },
      m(f, d) {
        Sn(f, t, d), Xi(n, t, null), wn(t, i), wn(t, a), s = !0, _ || (l = X0(
          a,
          "click",
          /*addCondition*/
          e[10]
        ), _ = !0);
      },
      p(f, d) {
        const c = {};
        d & /*mockGradio*/
        128 && (c.gradio = /*mockGradio*/
        f[7]), d & /*interactive*/
        8 && (c.interactive = /*interactive*/
        f[3]), !o && d & /*toAddCondition*/
        32 && (o = !0, c.value = /*toAddCondition*/
        f[5], Ui(() => o = !1)), n.$set(c);
      },
      i(f) {
        s || (re(n.$$.fragment, f), s = !0);
      },
      o(f) {
        Pe(n.$$.fragment, f), s = !1;
      },
      d(f) {
        f && bn(t), zi(n), _ = !1, l();
      }
    }
  );
}
function Q0(e) {
  let t, n, o, i, a, s = (
    /*label*/
    e[0] && hs(e)
  ), _ = ps(
    /*typed_value*/
    e[6]
  ), l = [];
  for (let f = 0; f < _.length; f += 1)
    l[f] = gs(ms(e, _, f));
  const r = (f) => Pe(l[f], 1, 1, () => {
    l[f] = null;
  });
  let u = (
    /*interactive*/
    e[3] && ws(e)
  );
  return {
    c() {
      t = ho("div"), s && s.c(), n = vo();
      for (let f = 0; f < l.length; f += 1)
        l[f].c();
      o = vo(), u && u.c(), vt(
        t,
        "id",
        /*elem_id*/
        e[1]
      ), vt(t, "class", i = "builder-container " + /*elem_classes*/
      e[2].join(" ") + " svelte-gfqmaf");
    },
    m(f, d) {
      Sn(f, t, d), s && s.m(t, null), wn(t, n);
      for (let c = 0; c < l.length; c += 1)
        l[c] && l[c].m(t, null);
      wn(t, o), u && u.m(t, null), a = !0;
    },
    p(f, [d]) {
      if (/*label*/
      f[0] ? s ? s.p(f, d) : (s = hs(f), s.c(), s.m(t, n)) : s && (s.d(1), s = null), d & /*safe_value, mockGradio, removeCondition, typed_value, isCondition*/
      720) {
        _ = ps(
          /*typed_value*/
          f[6]
        );
        let c;
        for (c = 0; c < _.length; c += 1) {
          const m = ms(f, _, c);
          l[c] ? (l[c].p(m, d), re(l[c], 1)) : (l[c] = gs(m), l[c].c(), re(l[c], 1), l[c].m(t, o));
        }
        for ($o(), c = _.length; c < l.length; c += 1)
          r(c);
        mo();
      }
      /*interactive*/
      f[3] ? u ? (u.p(f, d), d & /*interactive*/
      8 && re(u, 1)) : (u = ws(f), u.c(), re(u, 1), u.m(t, null)) : u && ($o(), Pe(u, 1, 1, () => {
        u = null;
      }), mo()), (!a || d & /*elem_id*/
      2) && vt(
        t,
        "id",
        /*elem_id*/
        f[1]
      ), (!a || d & /*elem_classes*/
      4 && i !== (i = "builder-container " + /*elem_classes*/
      f[2].join(" ") + " svelte-gfqmaf")) && vt(t, "class", i);
    },
    i(f) {
      if (!a) {
        for (let d = 0; d < _.length; d += 1)
          re(l[d]);
        re(u), a = !0;
      }
    },
    o(f) {
      l = l.filter(Boolean);
      for (let d = 0; d < l.length; d += 1)
        Pe(l[d]);
      Pe(u), a = !1;
    },
    d(f) {
      f && bn(t), s && s.d(), j0(l, f), u && u.d();
    }
  };
}
function Gn(e, t) {
  return typeof e == "object" && e !== null && "type" in e && e.type === t;
}
function Y0(e, t, n) {
  let { value: o = [] } = t, { label: i = "" } = t, { elem_id: a = "" } = t, { elem_classes: s = [] } = t, { interactive: _ = !0 } = t, { gradio: l } = t;
  const r = [["percentage", "percentage"], ["if_prompt", "if_prompt"]];
  let u = "percentage", f = o || [], d = f, c;
  function m() {
    n(4, f = [
      ...f,
      {
        type: "percentage",
        key: `${f.length}-percentage`,
        percent: 100,
        add: "",
        and_condition: [],
        or_condition: []
      }
    ]), n(11, o = f), l.dispatch("change");
  }
  function w() {
    n(4, f = [
      ...f,
      {
        type: "if_prompt",
        key: `${f.length}-if_prompt`,
        prompt_type: "positive",
        prompt: "",
        invert: !1,
        add: "",
        and_condition: [],
        or_condition: []
      }
    ]), n(11, o = f), l.dispatch("change");
  }
  function b(C) {
    f.splice(C, 1), n(4, f), n(11, o), n(11, o = f), l.dispatch("change");
  }
  function v() {
    u === "percentage" && m(), u === "if_prompt" && w();
  }
  const g = (C) => b(C);
  function p(C, T, P, E) {
    P[E] = C, n(6, d), n(4, f), n(11, o);
  }
  const h = (C) => b(C);
  function S(C, T, P, E) {
    P[E] = C, n(6, d), n(4, f), n(11, o);
  }
  const $ = (C, T, P) => P !== C && T.key !== "";
  function y(C) {
    u = C, n(5, u);
  }
  return e.$$set = (C) => {
    "value" in C && n(11, o = C.value), "label" in C && n(0, i = C.label), "elem_id" in C && n(1, a = C.elem_id), "elem_classes" in C && n(2, s = C.elem_classes), "interactive" in C && n(3, _ = C.interactive), "gradio" in C && n(12, l = C.gradio);
  }, e.$$.update = () => {
    e.$$.dirty & /*gradio*/
    4096 && n(7, c = {
      ...l,
      dispatch: (C) => {
        console.log(`Event dispatched: ${C}`);
      }
    }), e.$$.dirty & /*value*/
    2048 && n(4, f = o || []), e.$$.dirty & /*safe_value*/
    16 && n(6, d = f);
  }, [
    i,
    a,
    s,
    _,
    f,
    u,
    d,
    c,
    r,
    b,
    v,
    o,
    l,
    g,
    p,
    h,
    S,
    $,
    y
  ];
}
class A2e extends G0 {
  constructor(t) {
    super(), z0(this, t, Y0, Q0, Z0, {
      value: 11,
      label: 0,
      elem_id: 1,
      elem_classes: 2,
      interactive: 3,
      gradio: 12
    });
  }
}
export {
  A2e as default
};
